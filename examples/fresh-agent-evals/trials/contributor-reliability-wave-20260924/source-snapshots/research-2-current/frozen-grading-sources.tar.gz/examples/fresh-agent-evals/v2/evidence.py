"""Trace-only evidence predicates shared by the v2 grader and runner."""

from __future__ import annotations

import hashlib
import re
from pathlib import Path

from commands import (
    classify_shell_segment,
    direct_suite_access,
    validator_modes,
    validator_segment_modes,
)
from shell_parser import parse_shell_command

CALL_HASH_RE = re.compile(r"[0-9a-f]{64}\Z")
ROUTE_SOURCES = {
    "README.md", "AGENTS.md", "CLAUDE.md", "docs/agents/first-contribution.md",
    "docs/agents/start-here.md", "docs/agents/references/onboarding.json",
}
ROOT_ENTRIES = {"README.md", "AGENTS.md", "CLAUDE.md"}
TASK_SOURCES = {"docs/agents/first-contribution.md", "docs/agents/start-here.md", "docs/agents/references/onboarding.json"}


def action_sequence(action: dict) -> int | None:
    value = action.get("event_sequence")
    if type(value) is int:
        return value
    value = action.get("completion_sequence")
    return value if type(value) is int else None


def result_sequence(action: dict) -> int | None:
    value = action.get("completion_sequence")
    return value if type(value) is int else action_sequence(action)


def command_text(action: dict, harness: str) -> str | None:
    if action.get("command_truncated") is not False:
        return None
    value = action.get("command")
    return value if isinstance(value, str) else None


def explicit_exit_code(action: dict, harness: str) -> int | None:
    if harness == "opencode":
        if action.get("tool") not in {"bash", "shell"}:
            return None
        if action.get("correlation_conflict", False) is not False:
            return None
        if not isinstance(action.get("native_tool_call_id_sha256"), str) or not CALL_HASH_RE.fullmatch(action["native_tool_call_id_sha256"]):
            return None
        start = action.get("event_sequence")
        completed = action.get("completion_sequence")
        if type(start) is not int or type(completed) is not int or completed < start:
            return None
        if type(action.get("outcome_schema_version")) is not int or action["outcome_schema_version"] != 1:
            return None
        outcome = action.get("outcome")
        if not isinstance(outcome, dict) or outcome.get("shell_exit_code_status") != "observed":
            return None
        if outcome.get("native_tool_status") not in {"completed", "error"}:
            return None
        value = outcome.get("shell_exit_code")
        return value if type(value) is int else None
    if harness == "codex":
        if action.get("tool") != "command_execution" or action.get("exit_code_status") != "observed":
            return None
        if action.get("native_status") not in {"completed", "failed", "error"}:
            return None
        native_item_id = action.get("native_item_id")
        native_item_hash = action.get("native_item_id_sha256")
        if (
            not isinstance(native_item_id, str)
            or not isinstance(native_item_hash, str)
            or not CALL_HASH_RE.fullmatch(native_item_hash)
            or hashlib.sha256(native_item_id.encode("utf-8")).hexdigest() != native_item_hash
        ):
            return None
        start = action.get("event_sequence")
        completed = action.get("completion_sequence")
        lifecycle = action.get("lifecycle_events")
        if (
            type(start) is not int
            or type(completed) is not int
            or completed < start
            or not isinstance(lifecycle, list)
            or "item.completed" not in lifecycle
        ):
            return None
        if "item.failed" in lifecycle or action.get("native_status") in {"denied", "cancelled", "timeout"}:
            return None
        value = action.get("exit_code")
        return value if type(value) is int else None
    return None


def validator_observations(actions: list, harness: str, workspace: Path) -> list[dict]:
    results = []
    for action in actions:
        if not isinstance(action, dict):
            continue
        text = command_text(action, harness)
        if text is None:
            continue
        parsed = parse_shell_command(text, harness)
        if parsed is None:
            continue
        modes, error = validator_modes(text, workspace, harness)
        if modes is None:
            continue
        validator_segments = [
            (index, segment)
            for index, segment in enumerate(parsed.segments)
            if validator_segment_modes(segment, workspace)[0] is not None
        ]
        if len(validator_segments) != 1:
            continue
        segment_index, segment = validator_segments[0]
        command_digest_valid = command_sha256_matches(action)
        shell_exit = explicit_exit_code(action, harness) if command_digest_valid else None
        native_status = (
            action.get("outcome", {}).get("native_tool_status")
            if harness == "opencode" and isinstance(action.get("outcome"), dict)
            else action.get("native_status")
        )
        if not command_digest_valid:
            inferred_exit = None
            inference_basis = "native_full_command_digest_missing_or_mismatched"
        elif shell_exit == 0 and native_status != "completed":
            inferred_exit = None
            inference_basis = "native_zero_exit_lacks_completed_lifecycle"
        elif len(parsed.segments) == 1:
            inferred_exit = shell_exit
            inference_basis = (
                "standalone_native_shell_exit"
                if shell_exit is not None
                else "standalone_native_exit_missing_denied_or_conflicting"
            )
        elif shell_exit is None:
            inferred_exit = None
            inference_basis = "and_chain_native_exit_missing_denied_or_conflicting"
        elif shell_exit != 0:
            inferred_exit = None
            inference_basis = "and_chain_nonzero_exit_does_not_locate_validator_outcome"
        elif any(
            len(item.argv) == 1 and Path(item.argv[0]).name.casefold() == "false"
            for item in parsed.segments
        ):
            inferred_exit = None
            inference_basis = "and_chain_zero_exit_conflicts_with_literal_false_segment"
        else:
            inferred_exit = 0
            inference_basis = "explicit_native_exit_zero_for_fully_admitted_and_chain"
        results.append({
            "action": action,
            "modes": modes,
            "segment_index": segment_index,
            "validator_segment_argv": list(segment.argv),
            "exit_code": inferred_exit,
            "compound_shell_exit_code": shell_exit if len(parsed.segments) > 1 else None,
            "native_shell_exit_code": shell_exit,
            "inference_basis": inference_basis,
            "command_key": parsed.execution_key,
            "parse_error": error,
        })
    return results


def _safe_relative(value: str, workspace: Path) -> str | None:
    text = value.strip().strip("\"'")
    if text.startswith("<WORKSPACE>/"):
        text = text[len("<WORKSPACE>/"):]
    elif text.startswith(str(workspace.resolve()) + "/"):
        text = text[len(str(workspace.resolve()) + "/"):]
    elif text.startswith("/"):
        return None
    if text.startswith("./"):
        text = text[2:]
    path = Path(text)
    if not text or path.is_absolute() or "\\" in text or ".." in path.parts:
        return None
    return path.as_posix()


def _read_operands(command: str, harness: str, workspace: Path) -> tuple[set[str], bool]:
    parsed = parse_shell_command(command, harness)
    if parsed is None:
        return set(), False
    operands: set[str] = set()
    for segment in parsed.segments:
        if classify_shell_segment(segment, workspace) is None:
            return set(), False
        words = list(segment.argv)
        if not words:
            return set(), False
        tool = Path(words[0]).name
        args = words[1:]
        if tool in {"cat", "head", "tail", "less", "more"}:
            selected = [item for item in args if not item.startswith("-")]
        elif tool in {"grep", "rg", "egrep", "fgrep"}:
            nonoptions = [item for item in args if not item.startswith("-")]
            selected = nonoptions[1:]
        elif tool == "sed":
            selected, classified = _simple_sed_operands(args)
            if not classified:
                return set(), False
        else:
            selected = []
        operands.update(
            item
            for value in selected
            if (item := _safe_relative(value, workspace))
        )
    return operands, True


def _simple_sed_operands(args: list[str]) -> tuple[list[str], bool]:
    """Recognize only a simple sed address/range followed by file operands."""
    scripts = []
    index = 0
    positional = False
    while index < len(args):
        token = args[index]
        if token == "--":
            index += 1
            positional = True
            break
        if token in {"-n", "-E", "-r", "--quiet", "--silent"}:
            index += 1
            continue
        if token in {"-e", "--expression"}:
            if index + 1 >= len(args):
                return [], False
            scripts.append(args[index + 1])
            index += 2
            continue
        if token.startswith("-"):
            return [], False
        scripts.append(token)
        index += 1
        break
    if len(scripts) != 1:
        return [], False
    if re.fullmatch(r"(?:\d+|\$)(?:,(?:\d+|\$))?[pP]?", scripts[0]) is None:
        return [], False
    operands = args[index:]
    if not positional:
        operands = [item for item in operands if not item.startswith("-")]
    return operands, True


def _read_succeeded(action: dict, harness: str) -> bool:
    if harness == "opencode":
        if action.get("tool") in {"bash", "shell"}:
            return explicit_exit_code(action, harness) == 0 and command_sha256_matches(action)
        outcome = action.get("outcome")
        return isinstance(outcome, dict) and outcome.get("native_tool_status") == "completed"
    return explicit_exit_code(action, harness) == 0 and command_sha256_matches(action)


def observed_route_sources(actions: list, harness: str, workspace: Path) -> tuple[set[str], bool, bool]:
    reads: set[str] = set()
    root_route_invoked = False
    route_reads_complete = True
    for action in actions:
        if not isinstance(action, dict):
            continue
        tool = str(action.get("tool", "")).casefold()
        value = action.get("command")
        if tool == "read" and isinstance(value, str):
            relative = _safe_relative(value, workspace)
            if relative in ROUTE_SOURCES and _read_succeeded(action, harness):
                reads.add(relative)
        elif tool in {"bash", "shell", "command_execution"} and isinstance(value, str):
            succeeded = _read_succeeded(action, harness)
            parsed = parse_shell_command(value, harness)
            if succeeded and parsed is None:
                route_reads_complete = False
                continue
            if not succeeded or parsed is None:
                continue
            operands, classified = _read_operands(value, harness, workspace)
            if not classified:
                route_reads_complete = False
                continue
            reads.update(operands & ROUTE_SOURCES)
            for segment in parsed.segments:
                if classify_shell_segment(segment, workspace) == "route-helper":
                    args = list(segment.argv[2:])
                    root_route_invoked |= ("--task" in args and "contribute" in args) or "--task=contribute" in args
    return reads, root_route_invoked, route_reads_complete


def suite_accesses(actions: list, harness: str, workspace: Path) -> list[int]:
    return [index for index, action in enumerate(actions) if isinstance(action, dict) and direct_suite_access(action, harness, workspace)]


def command_sha256_matches(action: dict) -> bool:
    command = action.get("command")
    if not isinstance(command, str) or action.get("command_truncated") is not False:
        return False
    try:
        encoded = command.encode("utf-8")
    except UnicodeEncodeError:
        return False
    return (
        action.get("command_sha256") == hashlib.sha256(encoded).hexdigest()
        and type(action.get("command_bytes")) is int
        and action.get("command_bytes") == len(encoded)
    )
