"""Offline synthetic regressions for the paper-backed research evaluation."""

from __future__ import annotations

import hashlib
import json
import os
import shlex
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
EVALS_ROOT = HERE.parent
ROOT = HERE.parents[2]
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))
if str(EVALS_ROOT / "v2") not in sys.path:
    sys.path.insert(0, str(EVALS_ROOT / "v2"))

from callback_worker import _local_callback_source  # noqa: E402
from contract import FixtureContext  # noqa: E402
from research_grader import (  # noqa: E402
    CASE_ID,
    CODE_REL,
    REPORT_REL,
    RESULT_REL,
    _research_action_problems,
    _expected_machine_claims,
    _expected_eval_command,
    _native_command_evidence,
    grade_contribution,
)
from series import SeriesError, build_series, frozen_paths, verify_series, write_series_once  # noqa: E402
from synthetic_evaluator import (  # noqa: E402
    _RunAccumulator,
    canonical_json_equal,
    load_fixture,
)
from v2.paths import mkdir_chain_no_symlinks  # noqa: E402
from v2.evidence import command_sha256_matches, explicit_exit_code  # noqa: E402
from v2.native_events import normalize_codex  # noqa: E402
from v2.shell_parser import MAX_COMMAND_BYTES, parse_shell_command  # noqa: E402
from v2.snapshot import digest_map, file_map  # noqa: E402

REGRESSION_ONLY_CALLBACK = '''\
def challenger(ctx):
    yield next(ctx.stream_for(ctx.eligible_pairs[0]))
'''
MANIFEST_REL = "examples/fresh-agent-evals/research/series/selfcheck-series-c.json"


def _digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _access_action(tool: str, command: str) -> dict:
    raw = command.encode("utf-8")
    return {
        "tool": tool,
        "command": command,
        "command_sha256": _digest(raw),
        "command_bytes": len(raw),
        "command_truncated": False,
    }


def _complete_access_trace(actions: list, harness: str) -> dict:
    return {
        "actions": actions,
        "events_observed": max(1, len(actions)),
        "invalid_lines": 0,
        "trace_complete": True,
        "unclassified_tool_count" if harness == "opencode" else "unclassified_item_count": 0,
    }


def _json_bytes(payload: dict) -> bytes:
    return (json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode("utf-8")


def _codex_event_jsonl(events: list[dict], workspace: Path, repo: Path) -> dict:
    raw = b"".join(
        (json.dumps(event, separators=(",", ":"), ensure_ascii=False) + "\n").encode("utf-8")
        for event in events
    )
    return normalize_codex(raw, workspace, repo)


def _copy_closure(source: Path, target: Path) -> None:
    for relative in frozen_paths(source):
        origin = source / relative
        destination = target / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(origin, destination)


def _make_positive_fixture(root: Path, scratch: Path) -> tuple[Path, Path, dict, dict]:
    rubric = scratch / "rubric"
    rubric.mkdir()
    _copy_closure(root, rubric)
    manifest = build_series(rubric, "selfcheck-series-c")
    series_file = write_series_once(rubric, MANIFEST_REL, manifest)
    _loaded, manifest_digest = verify_series(rubric, MANIFEST_REL)

    workspace = scratch / "workspace-positive"
    shutil.copytree(rubric, workspace)
    (workspace / "trial-output").mkdir()
    initial = file_map(workspace)
    snapshot_digest = digest_map(initial)
    code_path = workspace / CODE_REL
    code_path.write_text(REGRESSION_ONLY_CALLBACK, encoding="utf-8")

    provenance_path = workspace / "examples/fresh-agent-evals/research/source-provenance.json"
    provenance = json.loads(provenance_path.read_text(encoding="utf-8"))
    excerpt_digest = _digest((workspace / provenance["source_excerpt_path"]).read_bytes())
    runner_path = workspace / "examples/fresh-agent-evals/research/runner.py"
    environment = dict(os.environ)
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    cli_result = subprocess.run(
        [
            sys.executable, str(runner_path), "--evaluate-development",
            "--implementation", CODE_REL,
            "--report-out", REPORT_REL,
            "--series-manifest", MANIFEST_REL,
            "--repo", str(workspace),
        ],
        cwd=workspace,
        env=environment,
        capture_output=True,
        text=True,
        timeout=120,
    )
    if cli_result.returncode != 0:
        raise RuntimeError("development evaluator CLI selfcheck failed")
    report_path = workspace / REPORT_REL
    dev_report = json.loads(report_path.read_text(encoding="utf-8"))
    report_digest = _digest(report_path.read_bytes())
    implementation_digest = _digest(code_path.read_bytes())
    result = {
        "schema_version": 1,
        "task_id": "paper-backed-coverage-challenger-v1",
        "source": {
            "source_excerpt_path": provenance["source_excerpt_path"],
            "source_excerpt_sha256": excerpt_digest,
            "title": provenance["title"],
            "authors": provenance["authors"],
            "year": provenance["year"],
            "identifier": provenance["identifier"],
            "url": provenance["url"],
            "paraphrase": "MAP-Elites maintains strong candidates across user-chosen descriptor cells, making the distribution visible rather than showing only a single best candidate.",
        },
        "research": {
            "mechanism_explanation": "The callback schedules fixture streams by feature and rotation pair; the evaluator keeps the supplied descriptor metadata separate from graph payload claims.",
            "hypothesis": "Under equal completed synthetic evaluator calls, the coverage-oriented schedule may reach a different number of eligible fixture cells than the synthetic uniform selector.",
            "falsifier": "The paired synthetic runs show no coverage difference or the callback exhausts before the target; neither outcome establishes live behavior.",
        },
        "machine_claims": _expected_machine_claims(
            series_path=MANIFEST_REL,
            series_id=manifest["series_id"],
            series_digest=manifest_digest,
            implementation_digest=implementation_digest,
            report_digest=report_digest,
            source_excerpt_digest=excerpt_digest,
        ),
        "human_review": {
            "summary": "Regression-only callback completed its development fixture execution.",
            "rationale": "This small selfcheck callback exercises the contract and grader; it is not a task starter or a research result.",
        },
    }
    result_path = workspace / RESULT_REL
    result_path.write_bytes(_json_bytes(result))

    trial = {
        "series_id": manifest["series_id"],
        "series_manifest_path": MANIFEST_REL,
        "series_manifest_sha256": manifest_digest,
        "case_id": CASE_ID,
        "snapshot_sha256": snapshot_digest,
        "initial_file_sha256": initial,
        "artifact_sha256": {
            CODE_REL: implementation_digest,
            REPORT_REL: report_digest,
            RESULT_REL: _digest(result_path.read_bytes()),
        },
    }
    return rubric, workspace, trial, dev_report


def _trial_with_current_artifacts(workspace: Path, trial: dict) -> dict:
    updated = dict(trial)
    updated["artifact_sha256"] = {
        relative: _digest((workspace / relative).read_bytes())
        for relative in (CODE_REL, REPORT_REL, RESULT_REL)
        if (workspace / relative).is_file() and not (workspace / relative).is_symlink()
    }
    return updated


def _check_accounting(failures: list[str], root: Path) -> None:
    fixture, _raw = load_fixture(root)
    fixture_input = fixture["inputs"][0]
    accumulator = _RunAccumulator(fixture_input, fixture["target_completed_evaluations_per_arm"])
    streams = fixture_input["candidate_streams"]
    pair_map = {item["pair_id"]: item for item in fixture_input["pairs"]}
    valid = next(
        record["payload"] for pair_id, records in streams.items() for record in records
        if pair_map[pair_id]["loaded"] is True and pair_map[pair_id]["eligible"] is True
        and record["depth"] is not None and record["depth"] <= 6
    )
    valid_transport = {"transport_status": "ok", "payload": valid}
    accumulator.add_transport(valid_transport)
    accumulator.add_transport(valid_transport)
    depth_payload = next(
        record["payload"] for records in streams.values() for record in records
        if record["depth"] is not None and record["depth"] > 6
    )
    accumulator.add_transport({"transport_status": "ok", "payload": depth_payload})
    excluded_pair_id = next(item["pair_id"] for item in fixture_input["pairs"] if item["loaded"] and not item["eligible"])
    excluded_payload = streams[excluded_pair_id][0]["payload"]
    accumulator.add_transport({"transport_status": "ok", "payload": excluded_payload})
    unloaded_pair_id = next(item["pair_id"] for item in fixture_input["pairs"] if not item["loaded"])
    unloaded_payload = streams[unloaded_pair_id][0]["payload"]
    accumulator.add_transport({"transport_status": "ok", "payload": unloaded_payload})
    unknown_payload = next(
        record["payload"] for records in streams.values() for record in records
        if record["synthetic_quality_pass"] is None
    )
    accumulator.add_transport({"transport_status": "ok", "payload": unknown_payload})
    accumulator.add_transport({"transport_status": "not_json_compatible"})
    summary = accumulator.snapshot()
    if accumulator.ledger.evaluations != 1 or summary["unique_valid_cell_count"] != 1:
        failures.append("only one trusted valid unique fixture payload counted as an evaluator completion")
    if summary["rejections"] != {
        "duplicate_identity": 1,
        "depth_over_six": 1,
        "excluded_pair": 1,
        "unloaded_pair": 1,
        "unknown_identity": 1,
        "invalid_payload": 1,
    }:
        failures.append("duplicate, depth, excluded, unloaded, unknown, or invalid attempts were not separated")


def _check_native_linkage(failures: list[str], workspace: Path, trusted_root: Path) -> None:
    series_path = MANIFEST_REL
    command = _expected_eval_command(series_path)
    excerpt_path = "examples/fresh-agent-evals/fixtures/challenger-research/trial-inputs/primary-source-excerpt.md"

    def file_write(relative: str, call_id: str, sequence: int) -> dict:
        raw = relative.encode("utf-8")
        return {
            "tool": "write",
            "command": relative,
            "command_sha256": _digest(raw),
            "command_bytes": len(raw),
            "command_truncated": False,
            "native_tool_call_id_sha256": _digest(call_id.encode("utf-8")),
            "event_sequence": sequence,
            "completion_sequence": sequence,
            "outcome_schema_version": 1,
            "outcome": {"native_tool_status": "completed"},
            "correlation_conflict": False,
        }

    def shell_action(
        call_id: str,
        sequence: int,
        shell_command: str,
        *,
        exit_code: int | None = 0,
        status: str = "completed",
        truncated: bool = False,
    ) -> dict:
        action = _access_action("bash", shell_command)
        action.update({
            "native_tool_call_id_sha256": _digest(call_id.encode("utf-8")),
            "event_sequence": sequence,
            "completion_sequence": sequence,
            "outcome_schema_version": 1,
            "outcome": {
                "native_tool_status": status,
                "shell_exit_code_status": "observed" if type(exit_code) is int else "missing",
                "shell_exit_code": exit_code,
            },
            "correlation_conflict": False,
        })
        if truncated:
            action["command_truncated"] = True
        return action

    def file_read(relative: str, call_id: str, sequence: int) -> dict:
        action = _access_action("read", f"<WORKSPACE>/{relative}")
        action.update({
            "native_tool_call_id_sha256": _digest(call_id.encode("utf-8")),
            "event_sequence": sequence,
            "completion_sequence": sequence,
            "outcome_schema_version": 1,
            "outcome": {
                "native_tool_status": "completed",
                "output_bytes": 0,
                "output_hash_status": "observed",
                "output_sha256": _digest(b""),
                "shell_exit_code_status": "not_applicable",
            },
            "correlation_conflict": False,
        })
        return action

    actions = [
        file_write(CODE_REL, "code-write", 42),
        shell_action("eval-call", 52, command),
        shell_action(
            "hash-before-result",
            55,
            f"sha256sum {excerpt_path} {series_path} {CODE_REL} {REPORT_REL}",
        ),
        file_read(REPORT_REL, "report-read", 56),
        shell_action(
            "shasum-before-result",
            57,
            f"shasum -a 256 {excerpt_path} {series_path} {CODE_REL} {REPORT_REL}",
        ),
        file_write(RESULT_REL, "result-write", 62),
        shell_action(
            "hash-after-result",
            66,
            f"sha256sum {excerpt_path} {series_path} {CODE_REL} {REPORT_REL}",
        ),
        file_read(RESULT_REL, "result-read", 67),
        shell_action(
            "shasum-after-result",
            68,
            f"shasum -a 256 {excerpt_path} {series_path} {CODE_REL} {REPORT_REL}",
        ),
    ]
    evidence, problems = _native_command_evidence(actions, "opencode", workspace, series_path)
    report_writes = evidence.get("write_sequences", {}).get(REPORT_REL)
    if problems or evidence.get("explicit_native_exit_code") != 0 or report_writes != [52]:
        failures.append(f"parsed command/lifecycle helper did not correlate the exact successful native command: {problems}")
    valid_access_problems = _research_action_problems(
        actions, "opencode", workspace, trusted_root,
        trace=_complete_access_trace(actions, "opencode"),
        series_manifest_path=series_path,
    )
    if valid_access_problems:
        failures.append(f"the bounded native-action audit rejected allowed pre/post-result hash reads: {valid_access_problems}")

    post_evaluation_edit = file_write(REPORT_REL, "report-post-evaluation-edit", 64)
    edited_actions = [*actions[:6], post_evaluation_edit, *actions[6:]]
    edited_evidence, edited_problems = _native_command_evidence(
        edited_actions, "opencode", workspace, series_path,
    )
    edited_access_problems = _research_action_problems(
        edited_actions, "opencode", workspace, trusted_root,
        trace=_complete_access_trace(edited_actions, "opencode"),
        series_manifest_path=series_path,
    )
    if (
        edited_evidence.get("write_sequences", {}).get(REPORT_REL) != [52, 64]
        or not any("comparison report was written again" in item for item in edited_problems)
        or not any("native file edit is outside" in item for item in edited_access_problems)
    ):
        failures.append("a completed post-evaluation report file edit was not rejected as a report write")

    missing_evaluator = [action for action in actions if action is not actions[1]]
    missing_evidence, missing_problems = _native_command_evidence(
        missing_evaluator, "opencode", workspace, series_path,
    )
    if not missing_problems or missing_evidence:
        failures.append("absent declared evaluator evidence was accepted")

    truncated_evaluator = [dict(action) for action in actions]
    truncated_evaluator[1]["command_truncated"] = True
    truncated_evidence, truncated_problems = _native_command_evidence(
        truncated_evaluator, "opencode", workspace, series_path,
    )
    truncated_access_problems = _research_action_problems(
        truncated_evaluator, "opencode", workspace, trusted_root,
        trace=_complete_access_trace(truncated_evaluator, "opencode"),
        series_manifest_path=series_path,
    )
    if (
        not truncated_problems
        or truncated_evidence
        or not any("unknown" in item for item in truncated_access_problems)
    ):
        failures.append("truncated evaluator evidence did not remain rejected or unknown")

    duplicate_evaluator = [
        *actions[:2], shell_action("duplicate-eval-call", 53, command), *actions[2:],
    ]
    duplicate_evidence, duplicate_problems = _native_command_evidence(
        duplicate_evaluator, "opencode", workspace, series_path,
    )
    if not duplicate_problems or duplicate_evidence:
        failures.append("duplicate exact development evaluators were accepted")

    nested = [{
        "tool": "bash",
        "command": "opencode run --model caller/model task",
        "command_truncated": False,
    }]
    if not _research_action_problems(
        nested, "opencode", workspace, trusted_root,
        trace=_complete_access_trace(nested, "opencode"),
        series_manifest_path=series_path,
    ):
        failures.append("nested native model launch escaped the parsed-action audit")

    missing_exit = [dict(action) for action in actions]
    missing_exit[1] = shell_action("eval-call", 52, command, exit_code=None)
    failed_evidence, failed_problems = _native_command_evidence(
        missing_exit, "opencode", workspace, series_path,
    )
    if not failed_problems or failed_evidence:
        failures.append("missing explicit native exit metadata was accepted as a command pass")

    incomplete_evaluator = [dict(action) for action in actions]
    incomplete_evaluator[1] = shell_action("eval-call", 52, command, status="running")
    incomplete_evidence, incomplete_problems = _native_command_evidence(
        incomplete_evaluator, "opencode", workspace, series_path,
    )
    if not incomplete_problems or incomplete_evidence:
        failures.append("incomplete native evaluator lifecycle was accepted")

    late_code = [actions[1], file_write(CODE_REL, "late-code-write", 53), *actions[2:]]
    _late_code_evidence, late_code_problems = _native_command_evidence(
        late_code, "opencode", workspace, series_path,
    )
    if not any("after the final callback implementation write" in item for item in late_code_problems):
        failures.append("development evaluator was accepted before the final callback write")

    early_result = [
        actions[0], file_write(RESULT_REL, "early-result-write", 51),
        *actions[1:5], *actions[6:],
    ]
    _early_result_evidence, early_result_problems = _native_command_evidence(
        early_result, "opencode", workspace, series_path,
    )
    if not any("written after the completed development evaluation" in item for item in early_result_problems):
        failures.append("typed result artifact was accepted before evaluator completion")

    mutating_shell = shell_action(
        "mutating-shell", 58, f"touch {REPORT_REL}",
    )
    mutating_actions = [*actions[:5], mutating_shell, *actions[5:]]
    mutating_access_problems = _research_action_problems(
        mutating_actions, "opencode", workspace, trusted_root,
        trace=_complete_access_trace(mutating_actions, "opencode"),
        series_manifest_path=series_path,
    )
    if not any("unknown" in item for item in mutating_access_problems):
        failures.append("unclassified mutating shell evidence was discarded instead of failing the access audit")


def _check_codex_command_evidence(failures: list[str], workspace: Path, trusted_root: Path) -> None:
    series_path = "examples/fresh-agent-evals/research/series/contributor-reliability-research-1.json"
    inner_command = _expected_eval_command(series_path)
    native_command = f"/bin/bash -lc {shlex.quote(inner_command)}"
    encoded_command = native_command.encode("utf-8")
    expected_command_sha256 = "446fca0721b1621c834b3f9391bcb90a7db869eed5506a0b96f2f75b4c3bcb44"

    def command_event(
        event_type: str,
        item_id: str,
        command: str | None,
        *,
        status: str,
        exit_code: int | None = None,
    ) -> dict:
        item = {"id": item_id, "type": "command_execution", "status": status}
        if command is not None:
            item["command"] = command
        if exit_code is not None:
            item["exit_code"] = exit_code
        return {"type": event_type, "item": item}

    def file_change_event(item_id: str, path: str) -> dict:
        return {
            "type": "item.completed",
            "item": {
                "id": item_id,
                "type": "file_change",
                "status": "completed",
                "changes": [{"path": path, "kind": "update"}],
            },
        }

    def audit(trace: dict, selected_series: str = series_path) -> list[str]:
        return _research_action_problems(
            trace["actions"], "codex", workspace, trusted_root,
            trace=trace, series_manifest_path=selected_series,
        )

    events = [
        {"type": "thread.started", "thread_id": "thread-reliability-research"},
        file_change_event("codex-code-write", CODE_REL),
        command_event(
            "item.completed", "codex-fixture-schema-read",
            f"/bin/bash -lc {shlex.quote('cat examples/fresh-agent-evals/research/fixture.schema.json')}",
            status="completed", exit_code=0,
        ),
        *[
            command_event(
                "item.completed", f"codex-prefill-{index}",
                f"/bin/bash -lc {shlex.quote('cat README.md')}",
                status="completed", exit_code=0,
            )
            for index in range(7)
        ],
        command_event("item.started", "item_5", native_command, status="in_progress"),
        command_event(
            "item.completed", "item_5", native_command,
            status="completed", exit_code=0,
        ),
        file_change_event("codex-result-write", RESULT_REL),
    ]
    trace = _codex_event_jsonl(events, workspace, trusted_root)
    evaluator_actions = [
        action for action in trace["actions"]
        if action.get("native_item_id") == "item_5"
    ]
    evaluator = evaluator_actions[0] if len(evaluator_actions) == 1 else {}
    evidence, evidence_problems = _native_command_evidence(
        trace["actions"], "codex", workspace, series_path,
    )
    access_problems = audit(trace)
    if (
        len(encoded_command) != 311
        or hashlib.sha256(encoded_command).hexdigest() != expected_command_sha256
        or trace.get("trace_complete") is not True
        or len(evaluator_actions) != 1
        or evaluator.get("command") != native_command
        or evaluator.get("command_truncated") is not False
        or evaluator.get("command_bytes") != 311
        or evaluator.get("command_sha256") != expected_command_sha256
        or evaluator.get("normalized_command") != inner_command
        or explicit_exit_code(evaluator, "codex") != 0
        or evaluator.get("event_sequence") != 10
        or evaluator.get("completion_sequence") != 11
        or evaluator.get("native_item_id_sha256") != "9462965f2002ffb6e5ebf84d633936910b584441932a9dee26f8497eb9d82c75"
        or evidence_problems
        or evidence.get("explicit_native_exit_code") != 0
        or evidence.get("command_sha256") != expected_command_sha256
        or evidence.get("command_bytes") != 311
        or evidence.get("write_sequences") != {
            CODE_REL: [1], REPORT_REL: [11], RESULT_REL: [12],
        }
        or access_problems
    ):
        failures.append(
            "Codex full 311-byte declared research command, native lifecycle, or allowlisted fixture.schema.json read was not evidenced"
        )

    truncated_actions = [dict(action) for action in trace["actions"]]
    truncated_evaluator = next(
        (action for action in truncated_actions if action.get("native_item_id") == "item_5"),
        None,
    )
    if truncated_evaluator is not None:
        truncated_evaluator["command"] = native_command[:300]
        truncated_evaluator["command_truncated"] = True
    truncated_trace = dict(trace, actions=truncated_actions)
    truncated_evidence, truncated_evidence_problems = _native_command_evidence(
        truncated_actions, "codex", workspace, series_path,
    )
    truncated_access_problems = audit(truncated_trace)
    if (
        truncated_evaluator is None
        or truncated_evidence
        or not truncated_evidence_problems
        or not any("unknown" in item for item in truncated_access_problems)
        or not any("reserved fixture or protected grader source" in item for item in truncated_access_problems)
    ):
        failures.append("truncated Codex preview or normalized inner command was trusted in place of full native text")

    mismatched_actions = [dict(action) for action in trace["actions"]]
    mismatched_evaluator = next(
        (action for action in mismatched_actions if action.get("native_item_id") == "item_5"),
        None,
    )
    if mismatched_evaluator is not None:
        mismatched_evaluator["command_sha256"] = "0" * 64
    mismatched_evidence, mismatched_problems = _native_command_evidence(
        mismatched_actions, "codex", workspace, series_path,
    )
    if mismatched_evaluator is None or mismatched_evidence or not mismatched_problems:
        failures.append("Codex declared evaluator evidence ignored a full-command digest mismatch")

    suffix_inner = inner_command + " && cat examples/fresh-agent-evals/research/research_grader.py"
    suffix_command = f"/bin/bash -lc {shlex.quote(suffix_inner)}"
    suffix_encoded = suffix_command.encode("utf-8")
    suffix_trace = _codex_event_jsonl([
        {"type": "thread.started", "thread_id": "thread-codex-reserved-suffix"},
        command_event(
            "item.started", "codex-reserved-suffix", suffix_command, status="in_progress",
        ),
        command_event(
            "item.completed", "codex-reserved-suffix", suffix_command,
            status="completed", exit_code=0,
        ),
    ], workspace, trusted_root)
    suffix_action = next(
        (action for action in suffix_trace["actions"] if action.get("native_item_id") == "codex-reserved-suffix"),
        {},
    )
    suffix_evidence, suffix_evidence_problems = _native_command_evidence(
        suffix_trace["actions"], "codex", workspace, series_path,
    )
    suffix_access_problems = audit(suffix_trace)
    parsed_suffix = parse_shell_command(suffix_command, "codex")
    if (
        not 300 < len(suffix_encoded) <= MAX_COMMAND_BYTES
        or suffix_action.get("command") != suffix_command
        or suffix_action.get("command_truncated") is not False
        or not command_sha256_matches(suffix_action)
        or parsed_suffix is None
        or len(parsed_suffix.segments) != 2
        or suffix_evidence
        or not suffix_evidence_problems
        or not any("reserved fixture or protected grader source" in item for item in suffix_access_problems)
    ):
        failures.append("full Codex command suffix containing a reserved grader read was not rejected")

    conflicting_trace = _codex_event_jsonl([
        {"type": "thread.started", "thread_id": "thread-codex-command-conflict"},
        command_event("item.started", "codex-conflicting-evaluator", native_command, status="in_progress"),
        command_event(
            "item.completed", "codex-conflicting-evaluator", native_command + " ",
            status="completed", exit_code=0,
        ),
    ], workspace, trusted_root)
    conflicting_action = conflicting_trace["actions"][0]
    if (
        conflicting_action.get("command") is not None
        or conflicting_action.get("command_sha256") is not None
        or conflicting_action.get("command_truncated") is not None
        or command_sha256_matches(conflicting_action)
        or not any("unknown" in item for item in audit(conflicting_trace))
    ):
        failures.append("conflicting Codex lifecycle command values were not left unknown")

    missing_trace = _codex_event_jsonl([
        {"type": "thread.started", "thread_id": "thread-codex-missing-command"},
        command_event(
            "item.completed", "codex-missing-command", None,
            status="completed", exit_code=0,
        ),
    ], workspace, trusted_root)
    missing_action = missing_trace["actions"][0]
    if (
        missing_action.get("command") is not None
        or missing_action.get("command_sha256") is not None
        or explicit_exit_code(missing_action, "codex") != 0
        or not any("unknown" in item for item in audit(missing_trace))
    ):
        failures.append("Codex command with an explicit exit but missing native text was trusted")

    redacted_secret = "sk-" + "A" * 24
    redacted_command = f"/bin/bash -lc {shlex.quote(f'cat {redacted_secret} README.md')}"
    redacted_trace = _codex_event_jsonl([
        {"type": "thread.started", "thread_id": "thread-codex-redacted-command"},
        command_event(
            "item.completed", "codex-redacted-command", redacted_command,
            status="completed", exit_code=0,
        ),
    ], workspace, trusted_root)
    redacted_action = redacted_trace["actions"][0]
    if (
        "<REDACTED" not in str(redacted_action.get("command"))
        or not command_sha256_matches(redacted_action)
        or parse_shell_command(redacted_action.get("command"), "codex") is not None
        or not any("unknown" in item for item in audit(redacted_trace))
    ):
        failures.append("redacted Codex command text was treated as executable evidence")

    oversized_inner = f"grep {shlex.quote('é' * (MAX_COMMAND_BYTES // 2 + 100))} README.md"
    oversized_command = f"/bin/bash -lc {shlex.quote(oversized_inner)}"
    oversized_bytes = oversized_command.encode("utf-8")
    oversized_trace = _codex_event_jsonl([
        {"type": "thread.started", "thread_id": "thread-codex-oversized-command"},
        command_event(
            "item.completed", "codex-oversized-command", oversized_command,
            status="completed", exit_code=0,
        ),
    ], workspace, trusted_root)
    oversized_action = oversized_trace["actions"][0]
    if (
        len(oversized_command) >= MAX_COMMAND_BYTES
        or len(oversized_bytes) <= MAX_COMMAND_BYTES
        or oversized_action.get("command") is not None
        or oversized_action.get("command_truncated") is not True
        or oversized_action.get("command_bytes") != len(oversized_bytes)
        or oversized_action.get("command_sha256") != _digest(oversized_bytes)
        or command_sha256_matches(oversized_action)
        or not any("unknown" in item for item in audit(oversized_trace))
    ):
        failures.append("oversized Codex command measured in UTF-8 bytes did not remain unknown")


def _check_research_access_audit(failures: list[str], workspace: Path, trusted_root: Path) -> None:
    series_path = MANIFEST_REL

    def problems(actions: list, harness: str = "opencode", *, trace: dict | None = None) -> list[str]:
        return _research_action_problems(
            actions,
            harness,
            workspace,
            trusted_root,
            trace=trace if trace is not None else _complete_access_trace(actions, harness),
            series_manifest_path=series_path,
        )

    useful_reads = (
        "examples/fresh-agent-evals/research/task.md",
        "examples/fresh-agent-evals/research/README.md",
        "examples/fresh-agent-evals/research/research-result.schema.json",
        "examples/fresh-agent-evals/research/callback-contract.md",
        "examples/fresh-agent-evals/fixtures/challenger-research/trial-inputs/primary-source-excerpt.md",
        series_path,
        CODE_REL,
        RESULT_REL,
    )
    for relative in useful_reads:
        action = _access_action("read", f"<WORKSPACE>/{relative}")
        if problems([action]):
            failures.append(f"documented native read was rejected: {relative}")
            break

    allowed_shell = [
        _access_action("bash", "cat examples/fresh-agent-evals/research/task.md"),
        _access_action(
            "bash",
            "sed -n '1,8p' examples/fresh-agent-evals/research/callback-contract.md",
        ),
        _access_action(
            "bash",
            "grep -n callback examples/fresh-agent-evals/fixtures/challenger-research/trial-inputs/primary-source-excerpt.md",
        ),
        _access_action(
            "bash",
            "rg callback examples/fresh-agent-evals/research/task.md",
        ),
        _access_action("bash", "cat trial-output/challenger.py"),
        _access_action("bash", f"sha256sum {series_path}"),
        _access_action(
            "bash",
            "shasum -a 256 examples/fresh-agent-evals/fixtures/challenger-research/trial-inputs/primary-source-excerpt.md",
        ),
    ]
    for action in allowed_shell:
        if problems([action]):
            failures.append("bounded documented shell read or hash command was rejected")
            break

    output_edits = [
        _access_action("write", CODE_REL),
        _access_action("write", RESULT_REL),
    ]
    if problems(output_edits):
        failures.append("native edits to the declared callback and research artifact were rejected")

    expected = _expected_eval_command(series_path)
    exact_opencode = _access_action("bash", expected)
    if problems([exact_opencode]):
        failures.append("exact selected-series development evaluator was rejected")
    exact_codex = _access_action("command_execution", f"bash -lc {shlex.quote(expected)}")
    if problems([exact_codex], "codex"):
        failures.append("exact selected-series Codex development evaluator was rejected")

    rejected_actions = [
        _access_action("read", "<WORKSPACE>/examples/fresh-agent-evals/research/fixture.json"),
        _access_action("read", "<WORKSPACE>/examples/fresh-agent-evals/research/research_grader.py"),
        _access_action("read", "<WORKSPACE>/examples/fresh-agent-evals/research/research_selfcheck.py"),
        _access_action("read", "<WORKSPACE>/examples/fresh-agent-evals/research/runner.py"),
        _access_action("bash", "cat examples/fresh-agent-evals/research/fixture.json"),
        _access_action("bash", "cat examples/fresh-agent-evals/research/fixture'.json'"),
        _access_action("bash", r"cat examples/fresh-agent-evals/research/fixtu\re.json"),
        _access_action("bash", "cat examples/fresh-agent-evals/research/research_grader.py"),
        _access_action("bash", "cat examples/fresh-agent-evals/research/research_selfcheck.py"),
        _access_action("bash", "python examples/fresh-agent-evals/research/research_grader.py"),
        _access_action("bash", "python examples/fresh-agent-evals/research/research_selfcheck.py"),
        _access_action("bash", "python examples/fresh-agent-evals/research/runner.py --selfcheck"),
        _access_action(
            "bash",
            "python3.12 -c \"open('examples/fresh-agent-evals/research/fixture.json').read()\"",
        ),
        _access_action(
            "bash",
            'sh -c "cat examples/fresh-agent-evals/research/fixture.json"',
        ),
        _access_action("bash", "node inspect.js"),
    ]
    for action in rejected_actions:
        if not problems([action]):
            failures.append(f"reserved or unsupported subject access was accepted: {action['command']}")
            break
    if not any("unknown" in item for item in problems([rejected_actions[-1]])):
        failures.append("unsupported shell executable did not leave the access audit unknown")

    missing_trace = _research_action_problems(
        [_access_action("read", "examples/fresh-agent-evals/research/task.md")],
        "opencode",
        workspace,
        trusted_root,
        series_manifest_path=series_path,
    )
    if not any("unknown" in item for item in missing_trace):
        failures.append("missing normalized access trace did not remain explicitly unknown")

    incomplete_trace = _complete_access_trace([], "opencode")
    incomplete_trace["trace_complete"] = False
    incomplete = problems([], trace=incomplete_trace)
    if not any("unknown" in item for item in incomplete):
        failures.append("incomplete native access trace did not remain explicitly unknown")

    truncated = _access_action("bash", "cat examples/fresh-agent-evals/research/task.md")
    truncated["command_truncated"] = True
    truncated_problems = problems([truncated])
    if not any("unknown" in item for item in truncated_problems):
        failures.append("truncated native shell command did not remain explicitly unknown")


def run_selfcheck(root: Path = ROOT) -> int:
    root = root.resolve()
    failures: list[str] = []
    check_names: list[str] = []

    for relative in (
        "research-result.schema.json", "comparison-report.schema.json", "fixture.schema.json",
        "series.schema.json", "trial-record.schema.json", "verdict.schema.json",
    ):
        try:
            json.loads((HERE / relative).read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            failures.append(f"typed schema JSON is invalid: {relative}")
    check_names.append("typed-schemas")

    fixture, _fixture_bytes = load_fixture(root)
    alpha = fixture["inputs"][0]
    context1 = FixtureContext(alpha, alpha["paired_seeds"][0])
    context2 = FixtureContext(alpha, alpha["paired_seeds"][0])
    pair = context1.eligible_pairs[0]
    first = list(context1.stream_for(pair))
    second = list(context2.stream_for(pair))
    if first != second:
        failures.append("fixture context streams are not deterministic for a paired seed")
    if not any(item["role"] == "reserved-heldout" for item in fixture["inputs"]):
        failures.append("reserved held-out fixture role is missing")
    check_names.append("fixture-contract-and-heldout")

    _check_accounting(failures, root)
    check_names.append("synthetic-ledger-accounting")

    try:
        _local_callback_source(HERE / "callback_worker.py")
        failures.append("callback worker source was incorrectly accepted as a subject contribution")
    except (ValueError, SyntaxError):
        pass
    with tempfile.TemporaryDirectory(prefix="research-selfcheck-code-") as temp:
        subject = Path(temp) / "challenger.py"
        subject.write_text("# plan only; no executable callback\n", encoding="utf-8")
        try:
            _local_callback_source(subject)
        except (ValueError, SyntaxError):
            pass
        else:
            failures.append("plan-only contribution passed callback source validation")
        subject.write_text(
            "from coverage_challenger import _make_challenger_template\n"
            "def challenger(ctx):\n    yield from _make_challenger_template()(ctx)\n",
            encoding="utf-8",
        )
        try:
            _local_callback_source(subject)
        except (ValueError, SyntaxError):
            pass
        else:
            failures.append("bundled campaign example import was accepted as an authored implementation")
    check_names.append("authored-callback-and-plan-negatives")

    scratch_parent = root / ".tmp"
    mkdir_chain_no_symlinks(scratch_parent)
    with tempfile.TemporaryDirectory(prefix="research-eval-selfcheck-", dir=scratch_parent) as temp:
        scratch = Path(temp)
        try:
            rubric, workspace, trial, expected_dev_report = _make_positive_fixture(root, scratch)
            manifest, manifest_digest = verify_series(rubric, MANIFEST_REL)
            if manifest_digest != trial["series_manifest_sha256"]:
                failures.append("series digest changed during the selfcheck fixture build")
            verdict = grade_contribution(
                rubric, workspace, trial, MANIFEST_REL,
                evidence_scope="synthetic-selfcheck",
            )
            if verdict.get("success") is not True or verdict.get("evidence_scope") != "synthetic-selfcheck":
                failures.append(f"valid synthetic contribution did not pass independent grading: {verdict.get('failure_reasons')}")
            independent_report = verdict.get("independent_report")
            if not isinstance(independent_report, dict) or independent_report.get("role_scope") != "development_plus_reserved_heldout":
                failures.append("independent report did not recompute development and reserved held-out inputs")
            if isinstance(independent_report, dict):
                if independent_report.get("run_count") != 6:
                    failures.append("independent grader did not execute multiple input/seed pairs")
                if independent_report.get("comparison_status") != "incomplete_comparison":
                    failures.append("a deliberately short regression callback did not retain its honest incomplete status")
                if independent_report.get("separate_genetic_campaign_target", {}).get("observed_completed_simulations") is not None:
                    failures.append("synthetic selfcheck invented an observed genetic baseline count")
            check_names.append("positive-independent-grade-and-heldout")

            mutations = []
            hardcoded = json.loads(json.dumps(expected_dev_report))
            hardcoded["runs"][0]["challenger"]["completed_evaluator_calls"] = 999
            hardcoded["runs"][0]["challenger"]["target_reached"] = True
            mutations.append(("forged-count", hardcoded))
            invalid_cell = json.loads(json.dumps(expected_dev_report))
            invalid_cell["runs"][0]["challenger"]["unique_valid_cells_reached"].append("forged_rotation|forged_feature")
            invalid_cell["runs"][0]["challenger"]["unique_valid_cell_count"] += 1
            mutations.append(("invalid-cell-claim", invalid_cell))
            depth_forgery = json.loads(json.dumps(expected_dev_report))
            depth_forgery["runs"][0]["challenger"]["rejections"]["depth_over_six"] = 0
            depth_forgery["runs"][0]["challenger"]["completed_evaluator_calls"] += 1
            mutations.append(("depth-over-six-forgery", depth_forgery))
            stale = json.loads(json.dumps(expected_dev_report))
            stale["implementation_sha256"] = "0" * 64
            mutations.append(("stale-report", stale))
            if any(canonical_json_equal(candidate, expected_dev_report) for _name, candidate in mutations):
                failures.append("a hardcoded count, invalid cell/depth, or stale report matched the independent report")
            check_names.extend(name for name, _candidate in mutations)

            # One full-grade tamper case updates its self-reported hash to prove
            # that integrity hashes alone cannot make a forged report pass.
            tampered = scratch / "workspace-tampered-report"
            shutil.copytree(workspace, tampered)
            tampered_report = json.loads((tampered / REPORT_REL).read_text(encoding="utf-8"))
            tampered_report["runs"][0]["challenger"]["completed_evaluator_calls"] = 999
            (tampered / REPORT_REL).write_bytes(_json_bytes(tampered_report))
            result_data = json.loads((tampered / RESULT_REL).read_text(encoding="utf-8"))
            result_data["machine_claims"]["comparison_report_sha256"] = _digest((tampered / REPORT_REL).read_bytes())
            (tampered / RESULT_REL).write_bytes(_json_bytes(result_data))
            failed_verdict = grade_contribution(
                rubric, tampered, _trial_with_current_artifacts(tampered, trial), MANIFEST_REL,
                evidence_scope="synthetic-selfcheck",
            )
            if failed_verdict.get("success") is not False or not any(
                "not independently reproducible" in item for item in failed_verdict.get("failure_reasons", [])
            ):
                failures.append("tampered report passed after its claimed SHA-256 was updated")
            check_names.append("tampered-report-fails-after-rehash")

            missing = scratch / "workspace-missing-code"
            shutil.copytree(workspace, missing)
            (missing / CODE_REL).unlink()
            missing_verdict = grade_contribution(
                rubric, missing, _trial_with_current_artifacts(missing, trial), MANIFEST_REL,
                evidence_scope="synthetic-selfcheck",
            )
            if missing_verdict.get("success") is not False:
                failures.append("missing callback implementation passed the contribution grader")
            check_names.append("missing-code-fails")

            changed_validator = scratch / "workspace-changed-validator"
            shutil.copytree(workspace, changed_validator)
            validator = changed_validator / ".github/scripts/validation/evals.py"
            validator.write_bytes(validator.read_bytes() + b"\n# selfcheck drift\n")
            changed_verdict = grade_contribution(
                rubric, changed_validator, _trial_with_current_artifacts(changed_validator, trial), MANIFEST_REL,
                evidence_scope="synthetic-selfcheck",
            )
            if changed_verdict.get("success") is not False:
                failures.append("changed validator source passed the frozen-series grader")
            check_names.append("changed-validator-fails")

            # A named series is immutable: a second create and any frozen-file
            # change are refused, while the temporary series itself is not kept.
            try:
                write_series_once(rubric, MANIFEST_REL, manifest)
            except SeriesError:
                pass
            else:
                failures.append("series freezer overwrote an existing manifest")
            drift = rubric / "examples/fresh-agent-evals/research/callback-contract.md"
            drift.write_bytes(drift.read_bytes() + b"\nfixture drift\n")
            try:
                verify_series(rubric, MANIFEST_REL)
            except SeriesError:
                pass
            else:
                failures.append("series verifier accepted frozen helper drift")
            check_names.append("series-no-overwrite-and-drift")

            _check_native_linkage(failures, workspace, rubric)
            check_names.extend([
                "native-command-outcome-linkage",
                "native-report-write-attribution-around-read-hashes",
                "native-post-evaluation-report-file-mutation-rejected",
                "native-evaluator-unique-completed-and-phased",
                "native-absent-truncated-and-mutating-evidence-fails-closed",
            ])
            _check_codex_command_evidence(failures, workspace, rubric)
            check_names.append("codex-full-bounded-command-evidence-and-access-audit")
            _check_research_access_audit(failures, workspace, rubric)
            check_names.append("research-subject-access-audit")
            if "examples/fresh-agent-evals/research/research_access.py" not in frozen_paths(root):
                failures.append("new research access helper is missing from future frozen-series discovery")
            check_names.append("research-access-helper-future-series-closure")
        except Exception as exc:  # noqa: BLE001 - report a short offline regression failure
            failures.append(f"selfcheck setup/execution failed: {type(exc).__name__}")

    result = {
        "suite": "paper-backed-coverage-research-v1",
        "status": "pass" if not failures else "fail",
        "synthetic_selfcheck": True,
        "native_calls": 0,
        "model_calls": 0,
        "checks": check_names,
        "failures": failures,
        "note": "Regression-only synthetic callbacks and reports are not native trials, API evidence, or performance measurements.",
    }
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(run_selfcheck())
