#!/usr/bin/env python3
"""Offline synthetic regressions; never launch a harness or model."""

from __future__ import annotations

import hashlib
import contextlib
import io
import json
import os
import re
import shlex
import shutil
import sys
import tempfile
import time
from pathlib import Path
from unittest import mock

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parents[1] / "opencode-lifecycle"))

import manifest  # noqa: E402
from commands import (  # noqa: E402
    command_semantic_key, direct_suite_access, is_completion_json_helper,
    validator_modes,
)
from comparison import ComparisonError, assert_same_prepared_input, assert_snapshot_pin  # noqa: E402
from evidence import (  # noqa: E402
    command_sha256_matches, explicit_exit_code, observed_route_sources,
    validator_observations,
)
from grader import (  # noqa: E402
    COMPLETION_REL, GradeError, _check_completion_claims, _direct_access_audit_complete,
    _find_action_by_declared_command, _setup_metrics,
    _forbidden_action_problems,
    grade_trial,
)
from native_events import normalize_codex, normalize_opencode  # noqa: E402
from opencode_profile import (  # noqa: E402
    DENIED as OPENCODE_DENIED,
    EXPECTED as OPENCODE_EXPECTED,
    PERMISSION as OPENCODE_PERMISSION,
    PROFILE_CONFIG as OPENCODE_PROFILE_CONFIG,
    effective_agent_matrix,
)
from paths import (  # noqa: E402
    PathSafetyError, exclusive_json, make_exclusive_directory,
    mkdir_chain_no_symlinks, raw_file_exclusive, safe_relative,
)
from processes import run_bounded  # noqa: E402
from schema import validate_completion  # noqa: E402
from semantic import canonical_primary_seed_source, fixture_correction_problem  # noqa: E402
from shell_parser import MAX_COMMAND_BYTES, parse_shell_command  # noqa: E402
from snapshot import copy_public_tree, prepare_snapshot  # noqa: E402


def _valid_completion(case_id: str, target: str, command: str) -> dict:
    return {
        "schema_version": 2,
        "case_id": case_id,
        "route": {
            "selected_task": "contribute",
            "offline_contribution_access": "not_required",
            "live_campaign_authorization": "explicit_user_authorization_required",
            "authoritative_sources": ["README.md", "docs/agents/first-contribution.md"],
        },
        "contribution": {"kind": "documentation_correction", "changed_paths": [target]},
        "validation": {
            "baseline": {"command": command, "modes": ["truthfulness"], "exit_code": 1, "result": "failed"},
            "final": {"command": command, "modes": ["truthfulness"], "exit_code": 0, "result": "passed"},
        },
        "human_review": {"summary": "A precise page correction.", "rationale": "Restored the documented contract."},
    }


def _event(tool: str, call_id: str, *, path: str | None = None, command: str | None = None,
           exit_code: int | None = None, status: str = "completed", stamp: float = 1_800_000_000.0) -> dict:
    input_data = {"filePath": path} if path is not None else {"command": command}
    state = {"status": status, "input": input_data, "timestamp": stamp}
    if exit_code is not None:
        state["metadata"] = {"exit": exit_code}
    return {"type": "tool_use", "timestamp": stamp,
            "part": {"type": "tool", "tool": tool, "callID": call_id, "state": state}}


def _shell_trace(script: str, harness: str, call_id: str, workspace: Path) -> tuple[dict, str]:
    if harness == "opencode":
        command = script
        trace = normalize_opencode(
            (json.dumps(_event("bash", call_id, command=command, exit_code=0)) + "\n").encode(),
            workspace, REPO,
        )
    else:
        command = f"/bin/bash -lc {shlex.quote(script)}"
        event = {
            "type": "item.completed",
            "item": {
                "id": call_id, "type": "command_execution", "command": command,
                "status": "completed", "exit_code": 0,
            },
        }
        trace = normalize_codex((json.dumps(event) + "\n").encode(), workspace, REPO)
    return trace, command


def _unclassified_counts_are_zero(trace: dict) -> bool:
    return all(trace.get(name) in (None, 0) for name in ("unclassified_item_count", "unclassified_tool_count"))


def _parser_regressions(failures: list[str]) -> None:
    valid = "/bin/bash -lc 'python .github/scripts/validate_agent_docs.py truthfulness'"
    modes, error = validator_modes(valid, Path("/tmp/v2-workspace"), "codex")
    if modes != ["truthfulness"] or error:
        failures.append("Codex exact bash -lc validator wrapper was not normalized")
    workspace = Path("/tmp/v2-workspace")
    if not direct_suite_access({"tool": "bash", "command": "cat oracle.json"}, "opencode", workspace):
        failures.append("direct oracle filename access was not audited")
    if direct_suite_access(
        {"tool": "bash", "command": "python .github/scripts/validate_agent_docs.py all"},
        "opencode", workspace,
    ):
        failures.append("legitimate full-validator execution was misclassified as direct suite access")

    joined_reserved_commands = (
        "cat o''racle.json",
        "pwd && cat o''racle.json",
        r"cat ora\cle.json",
        r"pwd && cat ora\cle.json",
    )
    for harness in ("opencode", "codex"):
        for index, script in enumerate(joined_reserved_commands):
            trace, command = _shell_trace(script, harness, f"joined-oracle-{harness}-{index}", workspace)
            action = trace["actions"][0]
            parsed = parse_shell_command(command, harness)
            expected_segments = 2 if "&&" in script else 1
            if (
                parsed is None
                or len(parsed.segments) != expected_segments
                or not any("oracle.json" in segment.argv for segment in parsed.segments)
                or not trace.get("trace_complete")
                or not _unclassified_counts_are_zero(trace)
                or action.get("command_truncated") is not False
                or action.get("command_bytes") != len(command.encode())
                or not command_sha256_matches(action)
                or not _direct_access_audit_complete(trace, trace["actions"], harness, workspace)
                or not direct_suite_access(action, harness, workspace)
            ):
                failures.append(
                    f"parsed reserved path hidden by shell quote concatenation/escape was not detected: {harness}: {script}"
                )

    joined_suite_commands = (
        "cat examples/fresh-agent-eva''ls/v2/commands.py",
        r"cat examples/fresh-agent-eva\ls/v2/commands.py",
        "pwd && cat examples/fresh-agent-eva''ls/v2/commands.py",
        r"pwd && cat examples/fresh-agent-eva\ls/v2/commands.py",
    )
    for harness in ("opencode", "codex"):
        for index, script in enumerate(joined_suite_commands):
            trace, command = _shell_trace(script, harness, f"joined-suite-{harness}-{index}", workspace)
            action = trace["actions"][0]
            parsed = parse_shell_command(command, harness)
            expected_segments = 2 if "&&" in script else 1
            if (
                parsed is None
                or len(parsed.segments) != expected_segments
                or not any("examples/fresh-agent-evals/v2/commands.py" in segment.argv for segment in parsed.segments)
                or not _direct_access_audit_complete(trace, trace["actions"], harness, workspace)
                or not direct_suite_access(action, harness, workspace)
            ):
                failures.append(
                    f"parsed suite path hidden by shell quote concatenation/escape was not detected: {harness}: {script}"
                )

    computed_reader = "awk 'BEGIN {p=\"ora\" \"cle.json\"; getline x < p; print x}'"
    for harness in ("opencode", "codex"):
        trace, command = _shell_trace(computed_reader, harness, f"computed-oracle-{harness}", workspace)
        action = trace["actions"][0]
        if (
            parse_shell_command(command, harness) is None
            or not trace.get("trace_complete")
            or not _unclassified_counts_are_zero(trace)
            or action.get("command_truncated") is not False
            or action.get("command_bytes") != len(command.encode())
            or not command_sha256_matches(action)
            or explicit_exit_code(action, harness) != 0
            or direct_suite_access(action, harness, workspace)
            or _direct_access_audit_complete(trace, trace["actions"], harness, workspace)
        ):
            failures.append(
                f"dynamically computed path in an unclassified interpreter did not leave audit unknown: {harness}"
            )

    for harness in ("opencode", "codex"):
        for index, (script, expected_segments) in enumerate((
            ("grep 'left && right; ||| literal' README.md", 1),
            ("grep 'left && right; ||| literal' README.md && pwd", 2),
            ("rg -- 'left && right; ||| literal' README.md", 1),
            ("rg -- 'left && right; ||| literal' README.md && pwd", 2),
        )):
            trace, command = _shell_trace(script, harness, f"quoted-operators-{harness}-{index}", workspace)
            parsed = parse_shell_command(command, harness)
            if (
                parsed is None
                or len(parsed.segments) != expected_segments
                or not trace.get("trace_complete")
                or not _direct_access_audit_complete(trace, trace["actions"], harness, workspace)
                or direct_suite_access(trace["actions"][0], harness, workspace)
            ):
                failures.append(f"quoted literal control operators were not preserved as harmless argv: {harness}")

    local_helpers = (
        "python -m json.tool trial-output/completion.json",
        "python3 -m json.tool trial-output/completion.json",
        "PYTHONDONTWRITEBYTECODE=1 python -m json.tool trial-output/completion.json",
        "git branch --show-current",
    )
    for index, helper in enumerate(local_helpers):
        trace = normalize_opencode(
            (json.dumps(_event("bash", f"local-helper-{index}", command=helper, exit_code=0)) + "\n").encode(),
            workspace, REPO,
        )
        if not _direct_access_audit_complete(trace, trace["actions"], "opencode", workspace):
            failures.append(f"exact harmless local helper was not admitted: {helper}")
        if _setup_metrics(trace["actions"], "opencode", workspace, True, 0)["unnecessary_setup_attempts"]["status"] != "observed_complete":
            failures.append(f"exact harmless local helper left setup observations unknown: {helper}")
        if validator_modes(helper, workspace, "opencode")[0] is not None:
            failures.append(f"local inspection helper was misclassified as repository validation: {helper}")
        if "json.tool" in helper:
            if not is_completion_json_helper(helper, "opencode"):
                failures.append("exact prefixed JSON-artifact read was not recognized for OpenCode")
            if not is_completion_json_helper(f'/bin/bash -lc "{helper}"', "codex"):
                failures.append("exact prefixed JSON-artifact read was not recognized through Codex bash -lc")
        codex_event = {
            "type": "item.completed",
            "item": {
                "id": f"codex-local-helper-{index}", "type": "command_execution",
                "command": f'/bin/bash -lc "{helper}"', "status": "completed", "exit_code": 0,
            },
        }
        codex_trace = normalize_codex((json.dumps(codex_event) + "\n").encode(), workspace, REPO)
        if not _direct_access_audit_complete(codex_trace, codex_trace["actions"], "codex", workspace):
            failures.append(f"exact Codex harmless local helper was not admitted: {helper}")

    unadmitted_helpers = (
        "python -m json.tool trial-output/other.json",
        "python -m json.tool trial-output/completion.json output.json",
        "python -m json.tool --sort-keys trial-output/completion.json",
        "python -m json.tool trial-output/completion.json > /dev/null",
        "PYTHONPATH=. python -m json.tool trial-output/completion.json",
        "PYTHONHOME=/tmp python -m json.tool trial-output/completion.json",
        "CUSTOM_FLAG=1 python -m json.tool trial-output/completion.json",
        "PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. python -m json.tool trial-output/completion.json",
        "env -i PYTHONDONTWRITEBYTECODE=1 python -m json.tool trial-output/completion.json",
        "python -c 'print(1)'",
        computed_reader,
        "less README.md",
        "more README.md",
        "rg --pre cat README.md",
        "rg --pre=cat README.md",
        "sort --compress-program=cat README.md",
        "sort --compress-prog=cat README.md",
        "git branch",
        "git branch --show-current --all",
        "git branch --delete old-branch",
        "git checkout other-branch",
        "git switch other-branch",
    )
    for index, helper in enumerate(unadmitted_helpers):
        trace = normalize_opencode(
            (json.dumps(_event("bash", f"unadmitted-helper-{index}", command=helper, exit_code=0)) + "\n").encode(),
            workspace, REPO,
        )
        if _direct_access_audit_complete(trace, trace["actions"], "opencode", workspace):
            failures.append(f"neighboring or mutating helper form was admitted: {helper}")
    for masked in (
        "/bin/bash -lc 'python .github/scripts/validate_agent_docs.py truthfulness; true'",
        "/bin/bash -lc 'python .github/scripts/validate_agent_docs.py truthfulness | true'",
        "/bin/bash -lc 'python .github/scripts/validate_agent_docs.py truthfulness'&&true",
        "python .github/scripts/validate_agent_docs.py truthfulness || true",
        "python .github/scripts/validate_agent_docs.py truthfulness | true",
        "python .github/scripts/validate_agent_docs.py truthfulness > /dev/null",
        "python .github/scripts/validate_agent_docs.py truthfulness & true",
        "python .github/scripts/validate_agent_docs.py truthfulness && $(true)",
        "python .github/scripts/validate_agent_docs.py truthfulness && bash -c true",
        "python .github/scripts/validate_agent_docs.py truthfulness && cat <REDACTED>",
        "python .github/scripts/validate_agent_docs.py truthfulness && 'unterminated",
    ):
        if validator_modes(masked, Path("/tmp/v2-workspace"), "codex")[0] is not None:
            failures.append("compound, piped, or masked validator command was accepted")

    direct_chain = (
        "PYTHONDONTWRITEBYTECODE=1 python .github/scripts/validate_agent_docs.py "
        "truthfulness links && git diff --check"
    )
    direct_modes, direct_error = validator_modes(direct_chain, workspace, "opencode")
    if direct_modes != ["truthfulness", "links"] or direct_error:
        failures.append("harmless OpenCode environment prefix and exact AND chain were not recognized")
    codex_chain = f"/bin/sh -lc '{direct_chain}'"
    codex_modes, codex_error = validator_modes(codex_chain, workspace, "codex")
    if codex_modes != ["truthfulness", "links"] or codex_error:
        failures.append("exact Codex sh -lc wrapper did not admit the bounded validator AND chain")
    if validator_modes(direct_chain, workspace, "codex")[0] != ["truthfulness", "links"]:
        failures.append("Codex completion declaration did not accept its full inner AND command")
    if validator_modes(
        "python -c 'print(\".github/scripts/validate_agent_docs.py truthfulness\")'",
        workspace, "opencode",
    )[0] is not None:
        failures.append("validator text inside an arbitrary Python script was substring-matched")

    quoted = parse_shell_command("grep 'left && right; ||| literal' README.md", "opencode")
    if quoted is None or len(quoted.segments) != 1 or quoted.segments[0].argv != (
        "grep", "left && right; ||| literal", "README.md",
    ):
        failures.append("quoted shell operators were split or lost their literal meaning")
    if validator_modes("eval 'python .github/scripts/validate_agent_docs.py truthfulness'", workspace, "opencode")[0] is not None:
        failures.append("eval or an unclassified nested command was admitted as validator execution")
    for malformed in (None, 1, {}, ["python", "validator"]):
        if validator_modes(malformed, workspace, "opencode")[0] is not None:
            failures.append("a malformed command type was admitted by validator recognition")
            break

    for hidden_access in (
        "python .github/scripts/validate_agent_docs.py truthfulness && cat oracle.json",
        "python -c 'open(\"examples/fresh-agent-evals/v2/oracle.json\")' && true",
    ):
        if not direct_suite_access({"tool": "bash", "command": hidden_access}, "opencode", workspace):
            failures.append("direct suite access hidden in a compound command was not audited")
    if validator_modes(
        "python .github/scripts/validate_agent_docs.py truthfulness && cat o''racle.json",
        workspace, "opencode",
    )[0] is not None:
        failures.append("validator recognizer accepted quote-joined direct suite access")

    opencode_chain_trace = normalize_opencode(
        (json.dumps(_event("bash", "opencode-chain", command=direct_chain, exit_code=0)) + "\n").encode(),
        workspace, REPO,
    )
    opencode_chain_action = opencode_chain_trace["actions"][0]
    opencode_chain_observations = validator_observations(
        [opencode_chain_action], "opencode", workspace,
    )
    if (
        not _direct_access_audit_complete(opencode_chain_trace, opencode_chain_trace["actions"], "opencode", workspace)
        or len(opencode_chain_observations) != 1
        or opencode_chain_observations[0]["exit_code"] != 0
        or opencode_chain_observations[0]["compound_shell_exit_code"] != 0
        or opencode_chain_observations[0]["inference_basis"] != "explicit_native_exit_zero_for_fully_admitted_and_chain"
        or not command_semantic_key(direct_chain, "opencode")
        or not command_sha256_matches(opencode_chain_action)
    ):
        failures.append("complete OpenCode chain did not preserve full command and inferred segment outcome provenance")

    codex_chain_event = {
        "type": "item.completed",
        "item": {
            "id": "codex-chain-1", "type": "command_execution",
            "command": codex_chain, "status": "completed", "exit_code": 0,
        },
    }
    codex_chain_trace = normalize_codex((json.dumps(codex_chain_event) + "\n").encode(), workspace, REPO)
    codex_chain_action = codex_chain_trace["actions"][0]
    codex_chain_observations = validator_observations([codex_chain_action], "codex", workspace)
    if (
        not _direct_access_audit_complete(codex_chain_trace, codex_chain_trace["actions"], "codex", workspace)
        or len(codex_chain_observations) != 1
        or codex_chain_observations[0]["exit_code"] != 0
        or codex_chain_observations[0]["compound_shell_exit_code"] != 0
        or codex_chain_action.get("command_sha256") is None
        or codex_chain_action.get("native_item_id") != "codex-chain-1"
        or codex_chain_action.get("completion_sequence") is None
        or not command_sha256_matches(codex_chain_action)
        or codex_chain_action.get("command_sha256") != hashlib.sha256(codex_chain.encode()).hexdigest()
        or codex_chain_action.get("command_bytes") != len(codex_chain.encode())
    ):
        failures.append("Codex wrapper lost full command digest, native lifecycle identity, or chain inference")

    def codex_lifecycle_trace(identifier: str, native_command: str) -> dict:
        command_item = {
            "id": identifier,
            "type": "command_execution",
            "command": native_command,
        }
        lifecycle = [
            {"type": "thread.started", "thread_id": "thread-long-command"},
            {"type": "item.started", "item": {**command_item, "status": "in_progress"}},
            {"type": "item.completed", "item": {**command_item, "status": "completed", "exit_code": 0}},
        ]
        raw = b"".join((json.dumps(event) + "\n").encode() for event in lifecycle)
        return normalize_codex(raw, workspace, REPO)

    long_codex_inner = " && ".join(["pwd"] * 50)
    long_codex_command = f"/bin/bash -lc {shlex.quote(long_codex_inner)}"
    long_codex_trace = codex_lifecycle_trace("codex-long-command", long_codex_command)
    long_codex_action = long_codex_trace["actions"][0]
    if (
        len(long_codex_command.encode("utf-8")) <= 300
        or len(long_codex_command.encode("utf-8")) > MAX_COMMAND_BYTES
        or long_codex_action.get("command") != long_codex_command
        or long_codex_action.get("command_truncated") is not False
        or long_codex_action.get("command_bytes") != len(long_codex_command.encode("utf-8"))
        or long_codex_action.get("command_sha256") != hashlib.sha256(long_codex_command.encode("utf-8")).hexdigest()
        or not command_sha256_matches(long_codex_action)
        or explicit_exit_code(long_codex_action, "codex") != 0
        or long_codex_action.get("event_sequence") != 1
        or long_codex_action.get("completion_sequence") != 2
        or long_codex_action.get("native_item_id") != "codex-long-command"
        or long_codex_action.get("normalized_command") != long_codex_inner
    ):
        failures.append("safely bounded Codex command over 300 bytes lost full UTF-8 text, digest, or lifecycle evidence")

    unicode_inner = f"grep {shlex.quote('é' * 160)} README.md"
    unicode_command = f"/bin/bash -lc {shlex.quote(unicode_inner)}"
    unicode_encoded = unicode_command.encode("utf-8")
    unicode_trace = codex_lifecycle_trace("codex-unicode-command", unicode_command)
    unicode_action = unicode_trace["actions"][0]
    if (
        len(unicode_command) >= MAX_COMMAND_BYTES
        or len(unicode_encoded) <= 300
        or len(unicode_encoded) > MAX_COMMAND_BYTES
        or unicode_action.get("command") != unicode_command
        or unicode_action.get("command_truncated") is not False
        or unicode_action.get("command_bytes") != len(unicode_encoded)
        or unicode_action.get("command_sha256") != hashlib.sha256(unicode_encoded).hexdigest()
        or not command_sha256_matches(unicode_action)
        or unicode_action.get("normalized_command") != unicode_inner
    ):
        failures.append("Codex command evidence used character length instead of bounded UTF-8 byte length")

    oversized_unicode_inner = f"grep {shlex.quote('é' * (MAX_COMMAND_BYTES // 2 + 100))} README.md"
    oversized_unicode_command = f"/bin/bash -lc {shlex.quote(oversized_unicode_inner)}"
    oversized_unicode_encoded = oversized_unicode_command.encode("utf-8")
    oversized_unicode_trace = codex_lifecycle_trace("codex-oversized-unicode", oversized_unicode_command)
    oversized_unicode_action = oversized_unicode_trace["actions"][0]
    if (
        len(oversized_unicode_command) >= MAX_COMMAND_BYTES
        or len(oversized_unicode_encoded) <= MAX_COMMAND_BYTES
        or oversized_unicode_action.get("command") is not None
        or oversized_unicode_action.get("command_truncated") is not True
        or oversized_unicode_action.get("command_bytes") != len(oversized_unicode_encoded)
        or oversized_unicode_action.get("command_sha256") != hashlib.sha256(oversized_unicode_encoded).hexdigest()
        or oversized_unicode_action.get("normalized_command") is not None
        or command_sha256_matches(oversized_unicode_action)
        or validator_observations([oversized_unicode_action], "codex", workspace)
    ):
        failures.append("over-bound Codex text measured in UTF-8 bytes was not left unknown")

    codex_ok = {
        "type": "item.completed",
        "item": {"id": "cmd-1", "type": "command_execution", "command": valid,
                 "status": "completed", "exit_code": 0},
    }
    normalized = normalize_codex((json.dumps(codex_ok) + "\n").encode(), Path("/tmp/v2-workspace"), REPO)
    action = normalized["actions"][0]
    if action.get("normalized_command") != "python .github/scripts/validate_agent_docs.py truthfulness":
        failures.append("Codex wrapper did not retain the exact inner standalone command")
    if action.get("command_sha256") is None or action.get("command_bytes") is None or action.get("native_item_id") != "cmd-1":
        failures.append("Codex normalization lost native item identity or full command digest/length")
    if explicit_exit_code(action, "codex") != 0:
        failures.append("Codex explicit command_execution.exit_code was not retained")

    sed_command = "sed -n '1,160p' README.md"
    opencode_sed = normalize_opencode(
        (json.dumps(_event("bash", "sed-read", command=sed_command, exit_code=0)) + "\n").encode(),
        Path("/tmp/v2-workspace"), REPO,
    )
    opencode_reads, _opencode_selector, opencode_read_complete = observed_route_sources(
        opencode_sed["actions"], "opencode", workspace
    )
    if "README.md" not in opencode_reads or not opencode_read_complete:
        failures.append("successful simple OpenCode sed range read was not recognized")
    if not _direct_access_audit_complete(opencode_sed, opencode_sed["actions"], "opencode", workspace):
        failures.append("valid OpenCode sed range command was not classified by the access audit")
    workspace_cat = normalize_opencode(
        (json.dumps(_event(
            "bash", "workspace-path-read",
            command=f"cat {workspace.resolve()}/README.md", exit_code=0,
        )) + "\n").encode(),
        workspace, REPO,
    )
    workspace_reads, _workspace_selector, workspace_read_complete = observed_route_sources(
        workspace_cat["actions"], "opencode", workspace,
    )
    if (
        "README.md" not in workspace_reads
        or not workspace_read_complete
        or not _direct_access_audit_complete(workspace_cat, workspace_cat["actions"], "opencode", workspace)
    ):
        failures.append("normalized <WORKSPACE> read path did not retain its safe workspace-relative meaning")
    failed_sed = normalize_opencode(
        (json.dumps(_event("bash", "sed-failed", command=sed_command, exit_code=1)) + "\n").encode(),
        Path("/tmp/v2-workspace"), REPO,
    )
    failed_reads, _failed_selector, _ = observed_route_sources(
        failed_sed["actions"], "opencode", Path("/tmp/v2-workspace")
    )
    if "README.md" in failed_reads:
        failures.append("nonzero OpenCode shell read was counted as completed route evidence")
    codex_sed_event = {
        "type": "item.completed",
        "item": {"id": "sed-1", "type": "command_execution",
                 "command": "/bin/bash -lc \"sed -n '1,160p' README.md\"",
                 "status": "completed", "exit_code": 0},
    }
    codex_sed = normalize_codex((json.dumps(codex_sed_event) + "\n").encode(), Path("/tmp/v2-workspace"), REPO)
    codex_reads, _codex_selector, codex_read_complete = observed_route_sources(
        codex_sed["actions"], "codex", workspace
    )
    if "README.md" not in codex_reads or not codex_read_complete:
        failures.append("successful simple Codex sed range read was not recognized")
    if not _direct_access_audit_complete(codex_sed, codex_sed["actions"], "codex", workspace):
        failures.append("valid Codex sed range command was not classified by the access audit")
    unknown_sed_event = {
        "type": "item.completed",
        "item": {"id": "sed-2", "type": "command_execution",
                 "command": "/bin/bash -lc \"sed -n '/title/p' README.md\"",
                 "status": "completed", "exit_code": 0},
    }
    unknown_sed = normalize_codex((json.dumps(unknown_sed_event) + "\n").encode(), Path("/tmp/v2-workspace"), REPO)
    unknown_reads, _unknown_selector, unknown_read_complete = observed_route_sources(
        unknown_sed["actions"], "codex", Path("/tmp/v2-workspace")
    )
    if "README.md" in unknown_reads or unknown_read_complete:
        failures.append("unsupported sed expression was fabricated as route-read evidence")
    if _direct_access_audit_complete(unknown_sed, unknown_sed["actions"], "codex", workspace):
        failures.append("unsupported sed expression yielded a complete direct-access audit")

    todo_event = {
        "type": "tool_use",
        "part": {"type": "tool", "tool": "todowrite", "callID": "todo-native",
                 "state": {"status": "completed", "input": {"todos": [{"content": "review"}]}}},
    }
    todo_actions = normalize_opencode((json.dumps(todo_event) + "\n").encode(), Path("/tmp/v2-workspace"), REPO)["actions"]
    if _forbidden_action_problems(todo_actions, "opencode"):
        failures.append("verified OpenCode todowrite planning event was treated as forbidden execution")

    inherited_override = {
        "permission": {"*": "allow", "task": "allow", "webfetch": "allow"},
        "agent": {"build": {"name": "build", "permission": dict(OPENCODE_PERMISSION)}},
    }
    effective = effective_agent_matrix(json.dumps(inherited_override))
    if effective != OPENCODE_EXPECTED:
        failures.append("named OpenCode build-agent deny rules did not override inherited global allows")
    explicit_fixture_denials = {"question", "plan_enter", "plan_exit"}
    top_level_permission = OPENCODE_PROFILE_CONFIG["permission"]
    build_permission = OPENCODE_PROFILE_CONFIG["agent"]["build"]["permission"]
    for name in sorted(explicit_fixture_denials):
        if name not in OPENCODE_DENIED or OPENCODE_PERMISSION.get(name) != "deny":
            failures.append(f"OpenCode fixture policy omitted explicit {name} denial")
        if top_level_permission.get(name) != "deny" or build_permission.get(name) != "deny":
            failures.append(f"OpenCode {name} denial was not shared by top-level and build-agent config")
        missing_override = dict(OPENCODE_PERMISSION)
        missing_override.pop(name, None)
        missing_matrix = effective_agent_matrix(json.dumps({
            "agent": {"build": {"permission": missing_override}},
        }))
        if missing_matrix == OPENCODE_EXPECTED:
            failures.append(f"OpenCode exact matrix check did not detect a missing {name} override")

    from runner import main as runner_main, requested_argument
    requested_model = requested_argument("openrouter/openai/gpt-6-luna", "model")
    requested_variant = requested_argument("max", "variant")
    requested_codex_model = requested_argument("gpt-6-astra", "model")
    requested_reasoning = requested_argument("medium", "reasoning")
    if (
        requested_model.get("value") != "openrouter/openai/gpt-6-luna"
        or requested_variant.get("value") != "max"
        or requested_codex_model.get("value") != "gpt-6-astra"
        or requested_reasoning.get("value") != "medium"
        or any(item.get("backend_served_value") != "not_observed" for item in (
            requested_model, requested_variant, requested_codex_model, requested_reasoning
        ))
    ):
        failures.append("sanitized requested model/variant/reasoning observations were not retained accurately")
    unsafe_selector = requested_argument("https://provider.invalid/?api_key=secret", "model")
    if unsafe_selector.get("status") != "unknown" or "value" in unsafe_selector or not isinstance(unsafe_selector.get("sha256"), str):
        failures.append("unsafe model selector was archived raw or omitted without an unknown reason/digest")
    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
        try:
            runner_main([
                "--harness", "codex", "--case", "first-finished-contribution-heldout",
                "--model", "synthetic-model", "--reasoning-effort", "medium",
            ])
        except SystemExit as exc:
            if exc.code != 2:
                failures.append("held-out case refusal used an unexpected exit code")
        else:
            failures.append("held-out case launched without explicit independent-check opt-in")

    missing = {"type": "item.completed", "item": {"id": "cmd-2", "type": "command_execution", "command": valid}}
    missing_action = normalize_codex((json.dumps(missing) + "\n").encode(), Path("/tmp/v2-workspace"), REPO)["actions"][0]
    if explicit_exit_code(missing_action, "codex") is not None:
        failures.append("Codex item.completed without exit_code was treated as exit zero")

    codex_file = {
        "type": "item.completed",
        "item": {"id": "file-1", "type": "file_change", "status": "completed",
                 "changes": [{"path": "/outside/private.md", "kind": "update"}]},
    }
    file_action = normalize_codex((json.dumps(codex_file) + "\n").encode(), Path("/tmp/v2-workspace"), REPO)["actions"][0]
    if file_action.get("path_status") != "outside_workspace" or file_action.get("path") is not None:
        failures.append("Codex file_change did not mark an outside path without retaining it")
    unverified_plan = {"type": "item.completed", "item": {"id": "plan-1", "type": "plan", "text": "local plan"}}
    plan_trace = normalize_codex((json.dumps(unverified_plan) + "\n").encode(), Path("/tmp/v2-workspace"), REPO)
    if plan_trace["trace_complete"] or plan_trace["actions"]:
        failures.append("unverified Codex planning payload was fabricated as a completed tool action")

    todo_item = {
        "id": "item_plan",
        "type": "todo_list",
        "items": [{"text": "Read the contributor route", "completed": True}],
    }
    todo_lifecycle_events = [{"type": "thread.started", "thread_id": "thread-plan"}]
    todo_lifecycle_events.extend(
        {"type": event_type, "item": dict(todo_item)}
        for event_type in ("item.started", "item.updated", "item.completed")
    )
    todo_trace = normalize_codex(
        b"".join((json.dumps(event) + "\n").encode() for event in todo_lifecycle_events),
        Path("/tmp/v2-workspace"), REPO,
    )
    metadata = todo_trace["planning_metadata"]
    if (
        not todo_trace["trace_complete"]
        or todo_trace["unclassified_item_count"] != 0
        or todo_trace["actions"]
        or [entry.get("lifecycle_event") for entry in metadata]
        != ["item.started", "item.updated", "item.completed"]
        or any(entry.get("classification") != "planning_metadata" for entry in metadata)
    ):
        failures.append("valid Codex todo_list lifecycle was not retained only as planning metadata")

    malformed_todo = {
        "type": "item.completed",
        "item": {
            **todo_item,
            "items": [{"text": "Read the contributor route", "completed": "true"}],
        },
    }
    malformed_todo_trace = normalize_codex(
        (json.dumps(malformed_todo) + "\n").encode(), Path("/tmp/v2-workspace"), REPO,
    )
    if (
        malformed_todo_trace["trace_complete"]
        or malformed_todo_trace["unclassified_item_count"] != 1
        or malformed_todo_trace["planning_metadata"]
        or malformed_todo_trace["actions"]
    ):
        failures.append("malformed Codex todo_list fields were not left unclassified")

    unknown_todo_lifecycle = {"type": "item.failed", "item": dict(todo_item)}
    unknown_todo_trace = normalize_codex(
        (json.dumps(unknown_todo_lifecycle) + "\n").encode(), Path("/tmp/v2-workspace"), REPO,
    )
    if unknown_todo_trace["trace_complete"] or unknown_todo_trace["unclassified_item_count"] != 1:
        failures.append("unsupported Codex todo_list lifecycle event was treated as known")

    unknown_execution_item = {
        "type": "item.completed",
        "item": {"id": "mcp-1", "type": "mcp_tool_call", "name": "browser", "arguments": {}},
    }
    unknown_execution_trace = normalize_codex(
        (json.dumps(unknown_execution_item) + "\n").encode(), Path("/tmp/v2-workspace"), REPO,
    )
    if unknown_execution_trace["trace_complete"] or unknown_execution_trace["unclassified_item_count"] != 1:
        failures.append("execution-capable unknown Codex item was not left unclassified")

    opencode_denied = normalize_opencode(
        (json.dumps(_event("bash", "denied-call", command="python .github/scripts/validate_agent_docs.py truthfulness",
                           exit_code=0, status="denied")) + "\n").encode(),
        Path("/tmp/v2-workspace"), REPO,
    )
    if explicit_exit_code(opencode_denied["actions"][0], "opencode") is not None:
        failures.append("denied OpenCode tool with exit metadata was treated as executed validation")
    opencode_missing = normalize_opencode(
        (json.dumps(_event("bash", "missing-call", command="python .github/scripts/validate_agent_docs.py truthfulness")) + "\n").encode(),
        Path("/tmp/v2-workspace"), REPO,
    )
    if explicit_exit_code(opencode_missing["actions"][0], "opencode") is not None:
        failures.append("OpenCode completed tool without state.metadata.exit was treated as success")
    success_text_event = _event(
        "bash", "success-text-only",
        command="python .github/scripts/validate_agent_docs.py truthfulness",
    )
    success_text_event["part"]["state"]["output"] = "all validators passed"
    success_text_action = normalize_opencode(
        (json.dumps(success_text_event) + "\n").encode(), Path("/tmp/v2-workspace"), REPO,
    )["actions"][0]
    success_text_observations = validator_observations(
        [success_text_action], "opencode", Path("/tmp/v2-workspace"),
    )
    if explicit_exit_code(success_text_action, "opencode") is not None or (
        success_text_observations and success_text_observations[0]["exit_code"] is not None
    ):
        failures.append("validator success text without native exit metadata was treated as execution proof")
    errored_zero = normalize_opencode(
        (json.dumps(_event(
            "bash", "error-zero-validator",
            command="python .github/scripts/validate_agent_docs.py truthfulness",
            exit_code=0, status="error",
        )) + "\n").encode(), Path("/tmp/v2-workspace"), REPO,
    )["actions"][0]
    errored_zero_observations = validator_observations(
        [errored_zero], "opencode", Path("/tmp/v2-workspace"),
    )
    if errored_zero_observations and errored_zero_observations[0]["exit_code"] is not None:
        failures.append("zero exit with a native error lifecycle was treated as a completed validator pass")
    complete_audit = normalize_opencode(
        (json.dumps(_event("bash", "audit-complete", command="pwd", exit_code=0)) + "\n").encode(),
        Path("/tmp/v2-workspace"), REPO,
    )
    if not _direct_access_audit_complete(complete_audit, complete_audit["actions"], "opencode", Path("/tmp/v2-workspace")):
        failures.append("complete, hashed native command evidence did not yield a complete access audit")
    long_command = "pwd " + "x" * 400
    truncated_audit = normalize_opencode(
        (json.dumps(_event("bash", "audit-truncated", command=long_command, exit_code=0)) + "\n").encode(),
        Path("/tmp/v2-workspace"), REPO,
    )
    if _direct_access_audit_complete(truncated_audit, truncated_audit["actions"], "opencode", Path("/tmp/v2-workspace")):
        failures.append("truncated native command payload was reported as a complete no-access audit")
    truncated_validator = normalize_opencode(
        (json.dumps(_event(
            "bash", "truncated-validator",
            command="python .github/scripts/validate_agent_docs.py truthfulness " + "x" * 400,
            exit_code=0,
        )) + "\n").encode(),
        Path("/tmp/v2-workspace"), REPO,
    )
    if validator_observations(truncated_validator["actions"], "opencode", Path("/tmp/v2-workspace")):
        failures.append("truncated validator command yielded an inferred outcome")
    truncated_codex = normalize_codex((json.dumps({
        "type": "item.completed",
        "item": {
            "id": "truncated-codex-validator", "type": "command_execution",
            "command": "/bin/bash -lc 'python .github/scripts/validate_agent_docs.py truthfulness " + "x" * MAX_COMMAND_BYTES + "'",
            "status": "completed", "exit_code": 0,
        },
    }) + "\n").encode(), Path("/tmp/v2-workspace"), REPO)
    if validator_observations(truncated_codex["actions"], "codex", Path("/tmp/v2-workspace")):
        failures.append("truncated Codex validator command yielded an inferred outcome")
    redacted_audit = normalize_opencode(
        (json.dumps(_event("bash", "audit-redacted", command="cat <REPO>/examples/fresh-agent-evals/v2/oracle.json", exit_code=0)) + "\n").encode(),
        Path("/tmp/v2-workspace"), REPO,
    )
    if _direct_access_audit_complete(redacted_audit, redacted_audit["actions"], "opencode", Path("/tmp/v2-workspace")):
        failures.append("redacted direct-access payload was reported as a complete no-access audit")
    if _direct_access_audit_complete({"trace_complete": False}, [], "opencode", Path("/tmp/v2-workspace")):
        failures.append("missing/unparseable trace was reported as a complete no-access audit")
    incomplete_metrics = _setup_metrics(
        [{"tool": "bash", "command": "python -c 'open(\\\"README.md\\\")'", "command_truncated": False}],
        "opencode", Path("/tmp/v2-workspace"), False, None,
    )
    if incomplete_metrics["unnecessary_setup_attempts"]["count"] is not None or incomplete_metrics["clarification_observations"]["count"] is not None:
        failures.append("incomplete tool extraction claimed complete low setup/clarification totals")


def _schema_and_path_regressions(failures: list[str]) -> None:
    case_id = "first-finished-contribution-primary"
    good = _valid_completion(case_id, "docs/example.md", "python .github/scripts/validate_agent_docs.py truthfulness")
    if validate_completion(good, case_id):
        failures.append("well-typed completion schema fixture was rejected")
    wrong_type = json.loads(json.dumps(good))
    wrong_type["validation"]["final"]["exit_code"] = True
    if not any("integer" in item for item in validate_completion(wrong_type, case_id)):
        failures.append("boolean exit code passed strict schema typing")
    wrong_enum = json.loads(json.dumps(good))
    wrong_enum["route"]["selected_task"] = "first contribution"
    if not validate_completion(wrong_enum, case_id):
        failures.append("free-form prose passed a canonical task enum")
    same_input = {
        "source_tree_sha256": "a" * 64,
        "snapshot_sha256": "b" * 64,
        "initial_file_sha256": {"README.md": "c" * 64},
    }
    pinned_codex = dict(same_input, expected_snapshot_sha256=same_input["snapshot_sha256"])
    try:
        assert_same_prepared_input(same_input, pinned_codex)
        assert_snapshot_pin(same_input, pinned_codex)
    except ComparisonError as exc:
        failures.append(f"identical prepared inputs were not comparable: {exc}")
    different_input = json.loads(json.dumps(same_input))
    different_input["snapshot_sha256"] = "d" * 64
    try:
        assert_same_prepared_input(same_input, different_input)
    except ComparisonError:
        pass
    else:
        failures.append("comparison accepted different prepared workspace snapshots")
    try:
        assert_snapshot_pin(same_input, dict(pinned_codex, expected_snapshot_sha256="e" * 64))
    except ComparisonError:
        pass
    else:
        failures.append("comparison accepted a Codex run without the prior OpenCode snapshot pin")
    malformed_paths = json.loads(json.dumps(good))
    malformed_paths["contribution"]["changed_paths"] = [7]
    if not validate_completion(malformed_paths, case_id):
        failures.append("non-string changed_paths value passed strict schema validation")
    malformed_route = json.loads(json.dumps(good))
    malformed_route["route"] = ["contribute"]
    if not validate_completion(malformed_route, case_id):
        failures.append("non-object route value passed strict schema validation")
    malformed_validation = json.loads(json.dumps(good))
    malformed_validation["validation"]["baseline"] = ["failed"]
    if not validate_completion(malformed_validation, case_id):
        failures.append("non-object nested validation value passed strict schema validation")

    with tempfile.TemporaryDirectory(prefix="of-v2-paths-") as temporary:
        root = Path(temporary)
        try:
            safe_relative("../escape")
            failures.append("parent traversal was accepted as a workspace-relative path")
        except PathSafetyError:
            pass
        parent = root / "runs"
        parent.mkdir()
        destination = parent / "exclusive"
        make_exclusive_directory(destination, parent)
        try:
            make_exclusive_directory(destination, parent)
            failures.append("existing run directory was replaced")
        except PathSafetyError:
            pass
        original = destination / "verdict.json"
        exclusive_json(original, {"verdict": "original"})
        before = original.read_bytes()
        try:
            exclusive_json(original, {"verdict": "regrade"})
            failures.append("original verdict evidence was overwritten")
        except PathSafetyError:
            pass
        if original.read_bytes() != before:
            failures.append("refused verdict overwrite changed original evidence bytes")
        outside = root / "outside"
        outside.mkdir()
        link = root / "linked"
        link.symlink_to(outside, target_is_directory=True)
        try:
            make_exclusive_directory(link / "child", link)
            failures.append("symlink escape was accepted for a trial directory")
        except PathSafetyError:
            pass


def _drift_regression(failures: list[str]) -> None:
    try:
        draft = manifest.build_manifest(REPO, "selfcheck-series")
        manifest._verify_frozen_files(REPO, draft)
    except manifest.ManifestError as exc:
        failures.append(f"named frozen rubric closure is not self-consistent: {exc}")
        return
    required_closure = {
        "examples/fresh-agent-evals/v2/shell_parser.py",
        "CONTRIBUTING.md",
        "docs/agents/references/compatibility.json",
        "docs/agents/research-opportunities.json",
        "docs/agents/start-here.md",
        "src/openforage/skills/agent_runtime_integration/references/harnesses.json",
        "src/openforage/skills/agent_runtime_integration/references/evidence/codex-native-marker-20260923.json",
        "src/openforage/skills/agent_runtime_integration/references/evidence/opencode-native-marker-20260922.json",
        "examples/background-agent/native-contribution-wave-20260924/codex-proof.json",
        "examples/background-agent/native-contribution-wave-20260924/opencode-proof.json",
        "scripts/onboarding/__init__.py",
        "scripts/onboarding/capabilities.py",
        "scripts/onboarding/entry_fragments.py",
    }
    if required_closure - draft["frozen_files"].keys():
        failures.append("new frozen manifest omitted a transitive parser/onboarding route dependency")
    target = REPO / "examples/fresh-agent-evals/v2/cases.json"
    original = manifest.file_sha256

    def changed(path: Path) -> str:
        return "0" * 64 if path.resolve() == target.resolve() else original(path)

    try:
        with mock.patch.object(manifest, "file_sha256", side_effect=changed):
            manifest._verify_frozen_files(REPO, draft)
    except manifest.ManifestError:
        return
    failures.append("rubric drift was not refused by the frozen manifest")


def _process_regressions(failures: list[str]) -> None:
    from runner import _child_environment

    child_env = _child_environment()
    python_path = shutil.which("python", path=child_env.get("PATH"))
    if python_path is None:
        failures.append("runner interpreter is absent from the child PATH")
    else:
        probe = run_bounded(
            [python_path, "-B", "-c",
             "import json,os,sys;print(json.dumps({'executable':os.path.abspath(sys.executable),'prefix':sys.prefix,'bytecode':os.environ.get('PYTHONDONTWRITEBYTECODE')}))"],
            cwd=REPO, env=child_env, timeout=10,
        )
        try:
            identity = json.loads(probe.stdout.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            identity = {}
        if (
            probe.returncode != 0 or probe.timed_out or probe.process_group_remaining
            or identity.get("prefix") != sys.prefix
            or identity.get("executable") != os.path.abspath(sys.executable)
            or identity.get("bytecode") != "1"
        ):
            failures.append("child python did not preserve the invoked interpreter/sys.prefix and bytecode policy")

    success = run_bounded([sys.executable, "-c", "pass"], cwd=REPO, timeout=5)
    if success.returncode != 0 or success.timed_out or success.process_group_remaining:
        failures.append("bounded subprocess success did not report an empty owned process group")
    spawn_child = (
        "import subprocess,sys,time; "
        "subprocess.Popen([sys.executable,'-c','import time;time.sleep(30)']); "
        "time.sleep(30)"
    )
    timed = run_bounded([sys.executable, "-c", spawn_child], cwd=REPO, timeout=0.2)
    if not timed.timed_out or timed.process_group_remaining:
        failures.append("timeout cleanup did not terminate and accurately report the owned process group")


def _synthetic_events(
    target: str, stamp: float, baseline_mode: str = "truthfulness",
    final_command: str | None = None,
) -> list[dict]:
    baseline_command = f"python .github/scripts/validate_agent_docs.py {baseline_mode}"
    final_command = final_command or "python .github/scripts/validate_agent_docs.py truthfulness"
    events = [{"type": "session", "sessionID": "synthetic-session-id", "timestamp": stamp - 1}]
    events.extend([
        _event("read", "read-root", path="README.md", stamp=stamp),
        _event("read", "read-guide", path="docs/agents/first-contribution.md", stamp=stamp + 0.1),
        _event("bash", "baseline-check", command=baseline_command, exit_code=1, stamp=stamp + 0.2),
        _event("edit", "write-page", path=target, stamp=stamp + 0.3),
        _event("bash", "final-check", command=final_command, exit_code=0, stamp=stamp + 0.4),
        _event("write", "write-completion", path="trial-output/completion.json", stamp=stamp + 0.5),
    ])
    return events


def _forgery_regressions(failures: list[str]) -> None:
    case_id = "first-finished-contribution-primary"
    command = "python .github/scripts/validate_agent_docs.py truthfulness"
    claim = {"command": command, "modes": ["truthfulness"], "exit_code": 0, "result": "passed"}
    if _find_action_by_declared_command(claim, [], "opencode", Path("/tmp/v2-workspace"), 0) is not None:
        failures.append("self-reported JSON success without a native action passed anti-forgery check")

    denied = normalize_opencode(
        (json.dumps(_event("bash", "denied-validator", command=command, exit_code=0, status="denied")) + "\n").encode(),
        Path("/tmp/v2-workspace"), REPO,
    )["actions"]
    if _find_action_by_declared_command(claim, denied, "opencode", Path("/tmp/v2-workspace"), 0) is not None:
        failures.append("refused validator tool with a fake exit field passed anti-forgery check")

    masked_event = _event("bash", "masked-validator", command=command + "; true", exit_code=0)
    masked_actions = normalize_opencode((json.dumps(masked_event) + "\n").encode(), Path("/tmp/v2-workspace"), REPO)["actions"]
    if _find_action_by_declared_command(claim, masked_actions, "opencode", Path("/tmp/v2-workspace"), 0) is not None:
        failures.append("masked `; true` validator tool result passed anti-forgery check")

    fake = _valid_completion(case_id, "docs/example.md", command)
    try:
        with tempfile.TemporaryDirectory(prefix="of-v2-forgery-") as temporary:
            workspace = Path(temporary)
            output = workspace / "trial-output"
            output.mkdir()
            (output / "completion.json").write_text(json.dumps(fake), encoding="utf-8")
            initial = {"README.md": "0" * 64}
            result = _check_completion_claims(REPO, workspace, case_id, [], "opencode", initial)
            if not result["failures"]:
                failures.append("fake log/self-report without tools or diff passed completion checks")
    except OSError as exc:
        failures.append(f"anti-forgery synthetic setup failed: {type(exc).__name__}")


def _phase_claim_result(completion: dict, target: str, *, before_doc=(), between_doc_writes=(),
                        after_doc=(), after_completion=(), doc_write_count: int = 1) -> dict:
    events = [
        _event("read", "phase-root-read", path="README.md"),
        _event("read", "phase-route-read", path="docs/agents/first-contribution.md"),
    ]

    def append_checks(checks):
        for call_id, command, exit_code, status in checks:
            events.append(_event("bash", call_id, command=command, exit_code=exit_code, status=status))

    append_checks(before_doc)
    for index in range(doc_write_count):
        events.append(_event("edit", f"phase-doc-write-{index}", path=target))
        if index + 1 < doc_write_count:
            append_checks(between_doc_writes)
    append_checks(after_doc)
    events.append(_event("write", "phase-completion-write", path=COMPLETION_REL))
    append_checks(after_completion)

    with tempfile.TemporaryDirectory(prefix="of-v2-phase-claims-") as temporary:
        workspace = Path(temporary)
        output = workspace / "trial-output"
        output.mkdir()
        (output / "completion.json").write_text(json.dumps(completion), encoding="utf-8")
        raw = b"".join((json.dumps(event, separators=(",", ":")) + "\n").encode() for event in events)
        normalized = normalize_opencode(raw, workspace, REPO)
        return _check_completion_claims(
            REPO, workspace, "first-finished-contribution-primary",
            normalized["actions"], "opencode", {},
        )


def _validation_phase_regressions(failures: list[str]) -> None:
    case_id = "first-finished-contribution-primary"
    oracle = json.loads((REPO / "examples/fresh-agent-evals/v2/oracle.json").read_text(encoding="utf-8"))
    target = oracle["cases"][case_id]["fixture"]["path"]
    command = "python .github/scripts/validate_agent_docs.py truthfulness"

    def completion(baseline_code: int = 1, final_code: int = 0) -> dict:
        value = _valid_completion(case_id, target, command)
        value["validation"]["baseline"] = {
            "command": command, "modes": ["truthfulness"],
            "exit_code": baseline_code, "result": "failed" if baseline_code != 0 else "passed",
        }
        value["validation"]["final"] = {
            "command": command, "modes": ["truthfulness"],
            "exit_code": final_code, "result": "passed" if final_code == 0 else "failed",
        }
        return value

    repeated = _phase_claim_result(
        completion(), target,
        before_doc=[
            ("baseline-earlier", command, 0, "completed"),
            ("baseline-boundary", command, 1, "completed"),
        ],
        after_doc=[
            ("final-earlier", command, 1, "completed"),
            ("final-boundary", command, 0, "completed"),
        ],
        after_completion=[("optional-post-completion-recheck", command, 1, "completed")],
    )
    if repeated["failures"]:
        failures.append("same-command repeated phase checks did not correlate at observed boundaries: " + "; ".join(repeated["failures"]))
    elif (
        repeated["baseline_action"].get("native_tool_call_id_sha256") != hashlib.sha256(b"baseline-boundary").hexdigest()
        or repeated["final_action"].get("native_tool_call_id_sha256") != hashlib.sha256(b"final-boundary").hexdigest()
    ):
        failures.append("phase correlation did not select the latest exact result before each artifact boundary")

    and_command = (
        "PYTHONDONTWRITEBYTECODE=1 python .github/scripts/validate_agent_docs.py "
        "truthfulness links && git diff --check"
    )
    and_completion = completion()
    and_completion["validation"]["final"] = {
        "command": and_command, "modes": ["truthfulness", "links"],
        "exit_code": 0, "result": "passed",
    }
    successful_chain = _phase_claim_result(
        and_completion, target,
        before_doc=[("and-baseline", command, 1, "completed")],
        after_doc=[("and-final", and_command, 0, "completed")],
    )
    chain_observations = validator_observations(
        [successful_chain.get("final_action")], "opencode", Path("/tmp/v2-workspace"),
    ) if successful_chain.get("final_action") is not None else []
    if (
        successful_chain["failures"]
        or successful_chain.get("final_action") is None
        or len(chain_observations) != 1
        or chain_observations[0].get("exit_code") != 0
        or chain_observations[0].get("compound_shell_exit_code") != 0
        or chain_observations[0].get("inference_basis") != "explicit_native_exit_zero_for_fully_admitted_and_chain"
    ):
        failures.append("explicit native exit zero did not prove the validator segment passed in the admitted AND chain")

    for chain_index, chain_command in enumerate((
        "false && python .github/scripts/validate_agent_docs.py truthfulness",
        "python .github/scripts/validate_agent_docs.py truthfulness && false",
    )):
        chain_baseline = completion()
        chain_baseline["validation"]["baseline"] = {
            "command": chain_command, "modes": ["truthfulness"],
            "exit_code": 1, "result": "failed",
        }
        unknown_chain = _phase_claim_result(
            chain_baseline, target,
            before_doc=[(f"ambiguous-chain-{chain_index}", chain_command, 1, "completed")],
            after_doc=[(f"ambiguous-final-{chain_index}", command, 0, "completed")],
        )
        if unknown_chain.get("baseline_action") is not None or not any(
            "compound-shell nonzero exit does not identify" in reason
            for reason in unknown_chain["failures"]
        ):
            failures.append("nonzero AND-chain exit was incorrectly attributed to its validator segment")

    false_chain_command = "python .github/scripts/validate_agent_docs.py truthfulness && false"
    false_chain_completion = completion()
    false_chain_completion["validation"]["final"] = {
        "command": false_chain_command, "modes": ["truthfulness"],
        "exit_code": 0, "result": "passed",
    }
    impossible_zero_chain = _phase_claim_result(
        false_chain_completion, target,
        before_doc=[("false-chain-baseline", command, 1, "completed")],
        after_doc=[("false-chain-zero", false_chain_command, 0, "completed")],
    )
    if impossible_zero_chain.get("final_action") is not None or not any(
        "conflicts with a literal false" in reason for reason in impossible_zero_chain["failures"]
    ):
        failures.append("zero shell exit contradicted by a literal false segment was accepted as validator success")

    wrong_original = _phase_claim_result(
        completion(), target,
        before_doc=[("original-baseline", command, 1, "completed")],
        after_doc=[("different-full-command", and_command, 0, "completed")],
    )
    if wrong_original.get("final_action") is not None:
        failures.append("validator segment from a different full original command satisfied the claim")

    codex_baseline_command = "python .github/scripts/validate_agent_docs.py all"
    codex_final_command = (
        "PYTHONDONTWRITEBYTECODE=1 python .github/scripts/validate_agent_docs.py "
        "truthfulness links && git diff --check"
    )
    codex_completion = _valid_completion(case_id, target, codex_final_command)
    codex_completion["validation"]["final"] = {
        "command": codex_final_command, "modes": ["truthfulness", "links"],
        "exit_code": 0, "result": "passed",
    }
    codex_completion["validation"]["baseline"] = {
        "command": codex_baseline_command, "modes": ["all"], "exit_code": 1, "result": "failed",
    }

    def codex_command(item_id: str, command_text: str, exit_code: int) -> dict:
        return {
            "type": "item.completed",
            "item": {
                "id": item_id, "type": "command_execution",
                "command": f"/bin/bash -lc '{command_text}'",
                "status": "failed" if exit_code else "completed", "exit_code": exit_code,
            },
        }

    codex_events = [
        {"type": "thread.started", "thread_id": "phase-codex-session"},
        codex_command("read-root", "cat README.md", 0),
        codex_command("read-route", "cat docs/agents/first-contribution.md", 0),
        codex_command("codex-baseline-before-write", codex_baseline_command, 1),
        {
            "type": "item.completed",
            "item": {
                "id": "codex-page-write", "type": "file_change", "status": "completed",
                "changes": [{"path": target, "kind": "update"}],
            },
        },
        codex_command("codex-same-command-after-write", codex_baseline_command, 1),
        codex_command("codex-final-after-write", codex_final_command, 0),
        {
            "type": "item.completed",
            "item": {
                "id": "codex-completion-write", "type": "file_change", "status": "completed",
                "changes": [{"path": COMPLETION_REL, "kind": "add"}],
            },
        },
    ]
    with tempfile.TemporaryDirectory(prefix="of-v2-codex-phase-") as temporary:
        workspace = Path(temporary)
        output = workspace / "trial-output"
        output.mkdir()
        (output / "completion.json").write_text(json.dumps(codex_completion), encoding="utf-8")
        raw = b"".join((json.dumps(event, separators=(",", ":")) + "\n").encode() for event in codex_events)
        codex_trace = normalize_codex(raw, workspace, REPO)
        codex_result = _check_completion_claims(
            REPO, workspace, case_id, codex_trace["actions"], "codex", {},
        )
    if codex_result["failures"]:
        failures.append("Codex same-command pre/post-edit evidence did not correlate by phase: " + "; ".join(codex_result["failures"]))
    elif codex_result["baseline_action"].get("native_item_id_sha256") != hashlib.sha256(b"codex-baseline-before-write").hexdigest():
        failures.append("Codex baseline correlation selected the post-edit duplicate command")

    latest_nonzero = _phase_claim_result(
        completion(), target,
        before_doc=[("baseline-valid", command, 1, "completed")],
        after_doc=[
            ("final-valid", command, 0, "completed"),
            ("final-boundary-nonzero", command, 1, "completed"),
        ],
    )
    if latest_nonzero["final_action"] is not None or not any(
        "latest exact command result" in reason for reason in latest_nonzero["failures"]
    ):
        failures.append("a passing final claim selected an earlier zero exit instead of the latest nonzero boundary result")

    denied = _phase_claim_result(
        completion(), target,
        before_doc=[("denied-baseline", command, 1, "completed")],
        after_doc=[
            ("final-before-denial", command, 0, "completed"),
            ("final-denied", command, 0, "denied"),
        ],
    )
    if denied["final_action"] is not None or not any(
        "denied" in reason or "unobserved exit" in reason for reason in denied["failures"]
    ):
        failures.append("a denied latest validator result was treated as a completed final pass")

    missing = _phase_claim_result(
        completion(), target,
        before_doc=[("missing-baseline", command, 1, "completed")],
        after_doc=[("final-missing-exit", command, None, "completed")],
    )
    if missing["final_action"] is not None or not any(
        "missing" in reason or "unobserved exit" in reason for reason in missing["failures"]
    ):
        failures.append("a validator result with no explicit exit code was accepted")

    no_baseline = _phase_claim_result(
        completion(), target,
        after_doc=[("baseline-after-edit", command, 1, "completed"), ("final-after-edit", command, 0, "completed")],
    )
    if no_baseline["baseline_action"] is not None or not any(
        "baseline" in reason and "causal phase" in reason for reason in no_baseline["failures"]
    ):
        failures.append("a post-edit validator result was accepted as the baseline")

    no_final_after_last_write = _phase_claim_result(
        completion(), target,
        before_doc=[("baseline-before-edit", command, 1, "completed")],
        between_doc_writes=[("final-before-last-edit", command, 0, "completed")],
        doc_write_count=2,
    )
    if no_final_after_last_write["final_action"] is not None or not any(
        "final" in reason and "causal phase" in reason for reason in no_final_after_last_write["failures"]
    ):
        failures.append("a validator result before the last correction write was accepted as final")

    distinct_baseline = "python .github/scripts/validate_agent_docs.py all"
    distinct_final = command
    distinct = _valid_completion(case_id, target, distinct_final)
    distinct["validation"]["baseline"] = {
        "command": distinct_baseline, "modes": ["all"], "exit_code": 1, "result": "failed",
    }
    no_final = _phase_claim_result(
        distinct, target,
        before_doc=[
            ("baseline-before-edit", distinct_baseline, 1, "completed"),
            ("final-too-early", distinct_final, 0, "completed"),
        ],
    )
    if no_final["baseline_action"] is None or no_final["final_action"] is not None:
        failures.append("a final validator result recorded before the correction write was accepted")

    conflicting = {
        "tool": "bash", "command": command,
        "command_bytes": len(command.encode()),
        "command_sha256": hashlib.sha256(command.encode()).hexdigest(),
        "command_truncated": False,
        "event_sequence": 3, "completion_sequence": 2,
        "native_tool_call_id_sha256": "a" * 64,
        "outcome": {
            "native_tool_status": "completed", "shell_exit_code_status": "observed",
            "shell_exit_code": 1,
        },
    }
    conflict_failures: list[str] = []
    from grader import _check_validation_claim
    selected = _check_validation_claim(
        "baseline", completion()["validation"]["baseline"], "failed", [conflicting],
        "opencode", Path("/tmp/v2-workspace"), {"truthfulness"}, conflict_failures,
        lower_exclusive=None, upper_exclusive=5,
    )
    if selected is not None or not conflict_failures:
        failures.append("conflicting native invocation/result ordering was accepted")

    duplicate_identities = [
        {
            **conflicting,
            "event_sequence": sequence,
            "completion_sequence": sequence,
        }
        for sequence in (3, 4)
    ]
    identity_failures: list[str] = []
    selected = _check_validation_claim(
        "baseline", completion()["validation"]["baseline"], "failed", duplicate_identities,
        "opencode", Path("/tmp/v2-workspace"), {"truthfulness"}, identity_failures,
        lower_exclusive=None, upper_exclusive=5,
    )
    if selected is not None or not identity_failures:
        failures.append("reused native command identity was accepted as two ordered validator results")


def _heldout_semantic_regressions(failures: list[str]) -> None:
    case_id = "first-finished-contribution-heldout"
    oracle = json.loads((REPO / "examples/fresh-agent-evals/v2/oracle.json").read_text(encoding="utf-8"))
    fixture = oracle["cases"][case_id]["fixture"]
    source_path = REPO / fixture["path"]
    clean = source_path.read_text(encoding="utf-8")
    with tempfile.TemporaryDirectory(prefix="of-v2-heldout-contract-") as temporary:
        workspace = Path(temporary)
        target = workspace / fixture["path"]
        target.parent.mkdir(parents=True)
        target.write_text(clean, encoding="utf-8")
        compat = workspace / "docs/agents/references/compatibility.json"
        compat.parent.mkdir(parents=True, exist_ok=True)
        compat.write_bytes((REPO / "docs/agents/references/compatibility.json").read_bytes())
        fragment = fixture["find"]
        alternate_fragment = fragment.replace("references/compatibility.json", "./references/compatibility.json")
        target.write_text(clean.replace(fragment, alternate_fragment, 1), encoding="utf-8")
        if fixture_correction_problem(REPO, workspace, case_id):
            failures.append("held-out semantic checker rejected an equivalent local compatibility link")
        target.write_text(clean.replace(fragment, "", 1), encoding="utf-8")
        if fixture_correction_problem(REPO, workspace, case_id) is None:
            failures.append("held-out semantic checker accepted deletion of the cited link context")


def _full_synthetic_grade(failures: list[str]) -> None:
    case_id = "first-finished-contribution-primary"
    with tempfile.TemporaryDirectory(prefix="of-v2-workspace-") as temporary:
        scratch = Path(temporary)
        oracle_path = REPO / "examples/fresh-agent-evals/v2/oracle.json"
        oracle_data = json.loads(oracle_path.read_text(encoding="utf-8"))
        fixture = oracle_data["cases"][case_id]["fixture"]
        synthetic_repo = scratch / "clean-source"
        synthetic_repo.mkdir()
        copy_public_tree(REPO, synthetic_repo)
        copied_target = synthetic_repo / fixture["path"]
        copied_text = copied_target.read_text(encoding="utf-8")
        if copied_text.count(fixture["find"]) != 1:
            canonical = canonical_primary_seed_source(copied_text, fixture)
            if canonical is None:
                failures.append("selfcheck could not construct a clean source view of the primary fixture")
                return
            copied_target.write_text(canonical, encoding="utf-8")
        env = dict(os.environ)
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        series_rel = "examples/fresh-agent-evals/v2/series/selfcheck-series.json"
        freeze_command = [
            sys.executable, str(synthetic_repo / "examples/fresh-agent-evals/v2/freeze.py"),
            "--create", "--series-id", "selfcheck-series", "--output", series_rel,
            "--repo", str(synthetic_repo),
        ]
        frozen = run_bounded(freeze_command, cwd=synthetic_repo, env=env, timeout=30)
        series_path = synthetic_repo / series_rel
        if frozen.returncode != 0 or frozen.timed_out or frozen.process_group_remaining or not series_path.is_file():
            failures.append("new named series could not be frozen through the public CLI")
            return
        series_hash = manifest.file_sha256(series_path)
        checked = run_bounded(
            [sys.executable, str(synthetic_repo / "examples/fresh-agent-evals/v2/freeze.py"),
             "--check", "--series-manifest", series_rel, "--repo", str(synthetic_repo)],
            cwd=synthetic_repo, env=env, timeout=30,
        )
        if checked.returncode != 0 or checked.timed_out or checked.process_group_remaining:
            failures.append("new named series did not pass the explicit selected-manifest check")
        refused = run_bounded(freeze_command, cwd=synthetic_repo, env=env, timeout=30)
        if refused.returncode == 0 or manifest.file_sha256(series_path) != series_hash:
            failures.append("freeze CLI overwrote an existing named-series manifest")
        parent = scratch / "workspaces"
        parent.mkdir()
        workspace = parent / "subject"
        try:
            prepared = prepare_snapshot(synthetic_repo, case_id, workspace, env)
        except Exception as exc:  # regression harness reports a concise error, never masks it
            failures.append(f"isolated snapshot selfcheck failed: {type(exc).__name__}")
            return
        if not prepared["workspace_git_root_verified"] or prepared["root_route_files_visible"] != ["README.md", "AGENTS.md", "CLAUDE.md"]:
            failures.append("snapshot did not preserve root route files and an isolated nearest Git root")

        baseline = run_bounded(
            [sys.executable, str(workspace / ".github/scripts/validate_agent_docs.py"),
             "truthfulness", "--root", str(workspace)],
            cwd=workspace, env=env, timeout=120,
        )
        if baseline.returncode in {None, 0} or baseline.timed_out:
            failures.append("primary fixture did not trigger a real baseline validator failure")

        oracle = json.loads((synthetic_repo / "examples/fresh-agent-evals/v2/oracle.json").read_text(encoding="utf-8"))
        target = oracle["cases"][case_id]["fixture"]["path"]
        clean_bytes = (synthetic_repo / target).read_bytes()
        clean_text = clean_bytes.decode("utf-8")
        fixture_find = oracle["cases"][case_id]["fixture"]["find"]
        alternate = "openforage.register( invite_code='<CODE>' )"
        if clean_text.count(fixture_find) != 1:
            failures.append("primary semantic selfcheck could not locate the seeded registration call")
            return
        corrected = clean_text.replace(fixture_find, alternate, 1)
        corrected = corrected.replace(
            "```\n\nThe library handles data sync",
            "```\n\nThis example keeps the documented initial-registration argument explicit.\n\nThe library handles data sync",
            1,
        )
        (workspace / target).write_text(corrected, encoding="utf-8")
        final_command = (
            "PYTHONDONTWRITEBYTECODE=1 python .github/scripts/validate_agent_docs.py "
            "truthfulness && git diff --check"
        )
        completion = _valid_completion(case_id, target, final_command)
        completion["validation"]["baseline"] = {
            "command": "python .github/scripts/validate_agent_docs.py all",
            "modes": ["all"], "exit_code": 1, "result": "failed",
        }
        completion["human_review"] = {
            "summary": "A concise, accurate correction.",
            "rationale": "I followed the documented route and kept the registration example semantics intact.",
        }
        completion_path = workspace / "trial-output/completion.json"
        completion_path.write_text(json.dumps(completion, indent=2) + "\n", encoding="utf-8")
        if validate_completion(completion, case_id):
            failures.append("synthetic completed contribution does not conform to the disclosed schema")

        stamp = time.time()
        raw = b"".join(
            (json.dumps(event, separators=(",", ":")) + "\n").encode()
            for event in _synthetic_events(target, stamp, "all", final_command)
        )
        normalized = normalize_opencode(raw, workspace, synthetic_repo)
        claim_check = _check_completion_claims(synthetic_repo, workspace, case_id, normalized["actions"], "opencode", prepared["initial_files"])
        if claim_check["failures"]:
            failures.append("valid alternate human-review prose or native evidence was rejected")

        runs_parent = synthetic_repo / ".tmp/native-contribution-wave/runs"
        mkdir_chain_no_symlinks(runs_parent)
        with tempfile.TemporaryDirectory(prefix="synthetic-", dir=runs_parent) as evidence_dir:
            evidence_dir = Path(evidence_dir)
            raw_path = evidence_dir / "raw-stdout.jsonl"
            raw_file_exclusive(raw_path, raw)
            trial = {
                "record_version": 2,
                "series_id": "selfcheck-series",
                "series_manifest_sha256": series_hash,
                "series_manifest_path": series_rel,
                "case_id": case_id,
                "harness": "opencode",
                "execution_mode": "fresh-native-run",
                "fresh_native_invocation": True,
                "workspace_identity": hashlib.sha256(str(workspace).encode()).hexdigest(),
                "source_tree_sha256": prepared["source_tree_sha256"],
                "snapshot_sha256": prepared["snapshot_sha256"],
                "initial_file_sha256": prepared["initial_files"],
                "clean_fixture_source_sha256": prepared["clean_fixture_source_sha256"],
                "seeded_fixture_sha256": prepared["seeded_fixture_sha256"],
                "started_epoch": stamp - 2,
                "harness_exit_code": 0,
                "harness_timed_out": False,
                "process_group_remaining": False,
                "session_id_sha256": normalized["session_id_sha256"],
                "clean_source_preflight": {
                    "modes": ["truthfulness", "links"],
                    "command_signature": "validate_agent_docs.py truthfulness links --root <source-checkout>",
                    "status": "pass", "exit_code": 0, "timed_out": False,
                    "process_group_remaining": False,
                },
                "seed_validator_preflight": {
                    "mode": "truthfulness", "status": "observed_failure", "exit_code": 1,
                    "command_signature": "validate_agent_docs.py truthfulness --root <prepared-workspace>",
                    "timed_out": False, "process_group_remaining": False,
                },
                "child_profile": {
                    "effective_matrix_verified": True,
                    "project_runtime_trees_absent_after_native_run": True,
                },
                "observed_actions": normalized["actions"],
                "raw_events_path": raw_path.relative_to(synthetic_repo).as_posix(),
                "raw_events_sha256": hashlib.sha256(raw).hexdigest(),
                "raw_events_bytes": len(raw),
            }
            verdict = grade_trial(synthetic_repo, workspace, trial, synthetic=True)
            if verdict["success"] is not True or verdict["evidence_scope"] != "synthetic-regression-only":
                failures.append("synthetic end-to-end contribution grade failed or was mislabeled: " + "; ".join(verdict.get("failure_reasons", [])[:3]))
            final_provenance = verdict.get("validation", {}).get("final_outcome_provenance", {})
            if (
                final_provenance.get("native_shell_exit_code") != 0
                or final_provenance.get("compound_shell_exit_code") != 0
                or final_provenance.get("validator_segment_exit_code") != 0
                or final_provenance.get("inference_basis") != "explicit_native_exit_zero_for_fully_admitted_and_chain"
                or not isinstance(final_provenance.get("native_command_sha256"), str)
                or not isinstance(final_provenance.get("native_action_identity_sha256"), str)
            ):
                failures.append("full synthetic grade omitted explicit native-chain outcome provenance")
            if verdict.get("human_review", {}).get("automated_quality_assessment") != "not_performed":
                failures.append("human-review prose was treated as an automated quality claim")
            invalid = re.sub(r"(?ms)^```python\n.*?^```[ \t]*(?:\n|$)", "", corrected, count=1)
            (workspace / target).write_text(invalid, encoding="utf-8")
            invalid_verdict = grade_trial(synthetic_repo, workspace, trial, run_independent=False, synthetic=True)
            if invalid_verdict.get("success") is True or not any(
                "fixture-specific documentation correction failed" in reason
                for reason in invalid_verdict.get("failure_reasons", [])
            ):
                failures.append("removing the source example did not fail the semantic correction contract")
            if invalid_verdict.get("metrics", {}).get("time_to_first_verified_completed_contribution", {}).get("status") != "unknown":
                failures.append("failed completion was reported with a verified contribution time")
            (workspace / target).write_text(corrected, encoding="utf-8")
            completion_path.write_text(json.dumps(completion, indent=2) + "\n", encoding="utf-8")
            malformed_records = [
                b"{not-json",
                json.dumps([]).encode(),
                json.dumps({**completion, "route": ["contribute"]}).encode(),
                json.dumps({**completion, "contribution": ["documentation_correction"]}).encode(),
                json.dumps({**completion, "contribution": {"kind": "documentation_correction", "changed_paths": [7]}}).encode(),
                json.dumps({**completion, "validation": ["failed", "passed"]}).encode(),
                json.dumps({**completion, "validation": {"baseline": [], "final": completion["validation"]["final"]}}).encode(),
                json.dumps({**completion, "human_review": ["summary", "rationale"]}).encode(),
                json.dumps({**completion, "human_review": {"summary": True, "rationale": "text"}}).encode(),
                json.dumps({**completion, "route": {**completion["route"], "selected_task": "maintenance"}}).encode(),
            ]
            for malformed_index, malformed in enumerate(malformed_records):
                completion_path.write_bytes(malformed)
                try:
                    malformed_verdict = grade_trial(
                        synthetic_repo, workspace, trial, run_independent=False, synthetic=True,
                    )
                except Exception as exc:  # malformed artifacts must remain reportable failures
                    failures.append(f"malformed completion fixture {malformed_index} escaped failed-verdict handling: {type(exc).__name__}")
                    continue
                if malformed_verdict.get("success") is True or not malformed_verdict.get("failure_reasons"):
                    failures.append("malformed completion did not produce a preserved failed verdict")
            completion_path.unlink()
            try:
                missing_verdict = grade_trial(
                    synthetic_repo, workspace, trial, run_independent=False, synthetic=True,
                )
                if missing_verdict.get("success") is True or not missing_verdict.get("failure_reasons"):
                    failures.append("missing completion.json did not produce a preserved failed verdict")
            except Exception as exc:
                failures.append(f"missing completion escaped failed-verdict handling: {type(exc).__name__}")
            completion_path.write_text(json.dumps(completion, indent=2) + "\n", encoding="utf-8")

            validator_file = workspace / ".github/scripts/validation/common.py"
            validator_bytes = validator_file.read_bytes()
            try:
                validator_file.write_bytes(validator_bytes + b"\n# harmless C4 marker\n")
                with (
                    mock.patch("grader._run_independent_validation") as independent_mock,
                    mock.patch("grader.run_bounded") as bounded_mock,
                ):
                    drift_verdict = grade_trial(synthetic_repo, workspace, trial, synthetic=True)
                if independent_mock.called or bounded_mock.called:
                    failures.append("independent validator executed after its dependency closure changed")
                if drift_verdict.get("success") is True or drift_verdict.get("validation", {}).get("independent_final", {}).get("executed") is not False:
                    failures.append("validator dependency drift was not refused before independent execution")
            finally:
                validator_file.write_bytes(validator_bytes)


def selfcheck() -> int:
    """Run synthetic schema, anti-forgery, drift, parser, path, and isolation checks."""
    failures: list[str] = []
    _parser_regressions(failures)
    _schema_and_path_regressions(failures)
    _forgery_regressions(failures)
    _validation_phase_regressions(failures)
    _heldout_semantic_regressions(failures)
    _process_regressions(failures)
    _drift_regression(failures)
    _full_synthetic_grade(failures)
    cases = json.loads((REPO / "examples/fresh-agent-evals/v2/cases.json").read_text(encoding="utf-8"))
    heldout = [case for case in cases["cases"] if case.get("role") == "held-out"]
    if len(heldout) != 1 or heldout[0].get("case_id") != "first-finished-contribution-heldout":
        failures.append("the distinct held-out case is absent or not uniquely reserved")
    for failure in failures:
        print(f"FAIL: v2 selfcheck: {failure}")
    if failures:
        print(f"\n{len(failures)} v2 selfcheck failure(s)")
        return 1
    print("note: v2 selfcheck used synthetic native-event fixtures and one offline independent-validator run; no harness/model was launched")
    print("note: synthetic passes are regression evidence only, not real native trial results")
    print("ok")
    return 0


if __name__ == "__main__":
    raise SystemExit(selfcheck())
