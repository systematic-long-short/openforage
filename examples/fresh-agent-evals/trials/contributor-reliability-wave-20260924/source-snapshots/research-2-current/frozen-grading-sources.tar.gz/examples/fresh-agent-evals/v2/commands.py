"""Bounded shell-command recognition for v2 evidence and access auditing."""

from __future__ import annotations

import re
from pathlib import Path

from schema import VALIDATOR_MODES
from shell_parser import (
    ParsedShellCommand,
    ShellSegment,
    parse_shell_command,
    unwrap_codex_script,
)

PYTHON_RE = re.compile(r"python(?:3(?:\.\d+)?)?\Z")
V2_PATH_RE = re.compile(r"(?:^|[/\\\s])examples/fresh-agent-evals(?:/|\b)")
RESERVED_NAMES = {
    "cases.json", "oracle.json", "answer.json", "answers.json", "grader.py",
    "grade.py", "manifest.py", "series.json",
}
RESERVED_NAME_RE = re.compile(
    r"(?:^|[/\\\s'\"])(?:cases\.json|oracle\.json|answers?\.json|grader\.py|grade\.py|manifest\.py|series\.json)(?:$|[/\\\s'\"])"
)
READ_ONLY_TOOLS = {
    "cat", "head", "tail", "sed", "grep", "rg",
    "egrep", "fgrep", "wc", "sort", "uniq", "tr", "cut", "nl",
}
READ_ONLY_GIT = {"status", "diff", "show", "log", "rev-parse", "ls-files"}
_SED_ADDRESS_RE = re.compile(r"(?:\d+|\$)(?:,(?:\d+|\$))?[pP]?\Z")


def unwrap_codex_shell(command: str) -> tuple[str | None, str]:
    """Unwrap only an exact Codex ``bash|sh -lc SCRIPT`` command."""
    return unwrap_codex_script(command)


def normalize_command(command: str, harness: str) -> tuple[str | None, str]:
    """Return the inner script only when the bounded shell grammar parses it."""
    parsed = parse_shell_command(command, harness)
    if parsed is None:
        return None, "command is malformed, redacted, or outside the bounded shell grammar"
    return parsed.script.strip(), parsed.wrapper


def command_semantic_key(command: str, harness: str) -> tuple | None:
    """Return complete inner execution identity for claim/native matching.

    Codex completion fields historically record the inner command; native
    actions are separately required to carry the exact shell wrapper.
    """
    parsed = parse_shell_command(command, harness, allow_unwrapped_codex=True)
    return parsed.execution_key if parsed is not None else None


def command_segments(command: str, harness: str) -> tuple[ShellSegment, ...] | None:
    """Return every segment only for a complete, non-truncated shell parse."""
    parsed = parse_shell_command(command, harness)
    return parsed.segments if parsed is not None else None


def _validator_segment_modes(
    segment: ShellSegment, workspace: Path,
) -> tuple[list[str] | None, str | None]:
    words = list(segment.argv)
    if len(words) < 3 or not PYTHON_RE.fullmatch(Path(words[0]).name):
        return None, "segment is not a Python repository-validator invocation"
    if words[1].removeprefix("./") != ".github/scripts/validate_agent_docs.py":
        return None, "segment does not name the repository validator"
    modes: list[str] = []
    index = 2
    seen_options: set[str] = set()
    while index < len(words):
        token = words[index]
        if token in {"--root", "--record-dir"}:
            if token in seen_options:
                return None, "validator option is duplicated"
            seen_options.add(token)
            index += 1
            if index >= len(words):
                return None, "validator option is missing its value"
            value = words[index]
            if token == "--root" and value not in {".", "./"}:
                return None, "validator root must be workspace-relative; absolute paths are not archived"
            if token == "--record-dir" and (
                value.startswith(("/", "<WORKSPACE>")) or ".." in Path(value).parts
            ):
                return None, "validator record directory escapes the workspace"
        elif token.startswith("-"):
            return None, "validator command contains an unsupported option"
        elif token in VALIDATOR_MODES:
            if token in modes:
                return None, "validator mode is duplicated"
            modes.append(token)
        else:
            return None, "validator command contains an unknown argument"
        index += 1
    if not modes:
        return None, "validator command selects no validation mode"
    if "all" in modes and len(modes) != 1:
        return None, "all cannot be combined with individual validator modes"
    return modes, None


def validator_segment_modes(
    segment: ShellSegment, workspace: Path,
) -> tuple[list[str] | None, str | None]:
    """Recognize one complete validator argv segment, never a text substring."""
    return _validator_segment_modes(segment, workspace)


def _python_helper_kind(segment: ShellSegment) -> str | None:
    words = list(segment.argv)
    if not words or not PYTHON_RE.fullmatch(Path(words[0]).name):
        return None
    if len(words) == 4 and words[1:3] == ["-m", "json.tool"] and words[3] == "trial-output/completion.json":
        return "completion-json"
    if len(words) >= 2 and words[1].removeprefix("./") == "scripts/start_here.py":
        return "route-helper"
    if words[1:] in (["--version"], ["--help"]):
        return "python-probe"
    return None


def is_completion_json_segment(segment: ShellSegment) -> bool:
    return _python_helper_kind(segment) == "completion-json"


def is_current_branch_segment(segment: ShellSegment) -> bool:
    return list(segment.argv) == ["git", "branch", "--show-current"]


def _simple_sed_operands(args: list[str]) -> tuple[list[str], bool]:
    """Recognize only a simple sed address/range followed by file operands."""
    scripts: list[str] = []
    index = 0
    positional = False
    while index < len(args):
        token = args[index]
        if token == "--":
            index += 1
            positional = True
            break
        if token in {"-n", "-E", "-r", "--quiet", "--silent"}:
            index += 1
            continue
        if token in {"-e", "--expression"}:
            if index + 1 >= len(args):
                return [], False
            scripts.append(args[index + 1])
            index += 2
            continue
        if token.startswith("-"):
            return [], False
        scripts.append(token)
        index += 1
        break
    if len(scripts) != 1 or _SED_ADDRESS_RE.fullmatch(scripts[0]) is None:
        return [], False
    operands = args[index:]
    if not positional:
        operands = [item for item in operands if not item.startswith("-")]
    return operands, True


def classify_shell_segment(segment: ShellSegment, workspace: Path) -> str | None:
    """Classify one segment from the explicitly admitted local command set."""
    validator_modes, _error = _validator_segment_modes(segment, workspace)
    if validator_modes is not None:
        return "validator"

    helper_kind = _python_helper_kind(segment)
    if helper_kind is not None:
        return helper_kind

    words = list(segment.argv)
    if not words:
        return None
    tool = Path(words[0]).name.casefold()
    args = words[1:]
    if is_current_branch_segment(segment):
        return "branch-observation"
    if tool == "git" and args and args[0] in READ_ONLY_GIT:
        return "git-read-only"
    if tool == "pwd" and args in ([], ["-P"], ["-L"]):
        return "inspection"
    if tool == "sed":
        _operands, classified = _simple_sed_operands(args)
        return "inspection" if classified else None
    if tool in READ_ONLY_TOOLS:
        if tool == "rg" and _uses_executable_reader_option(args, "--pre"):
            return None
        if tool == "sort" and _uses_executable_reader_option(args, "--compress-program"):
            return None
        return "inspection"
    if tool in {"true", "false"} and not args:
        return "no-op"
    if tool == "ls":
        return "inspection"
    return None


def _mentions_suite_material(value: str) -> bool:
    return bool(V2_PATH_RE.search(value) or RESERVED_NAME_RE.search(value))


def _mentions_suite_argument(value: str) -> bool:
    """Match suite names in one shell word after quote/escape normalization."""
    return _mentions_suite_material(value) or Path(value.strip()).name in RESERVED_NAMES


def _segment_mentions_suite_material(segment: ShellSegment) -> bool:
    return _mentions_suite_material(segment.source) or any(
        _mentions_suite_argument(word) for word in segment.argv
    )


def _uses_executable_reader_option(args: list[str], option: str) -> bool:
    """Reject an executable-program option, including long-option prefixes."""
    for argument in args:
        if argument == "--":
            break
        name = argument.split("=", 1)[0]
        if name == option or (len(name) > 2 and name.startswith("--") and option.startswith(name)):
            return True
    return False


def validator_modes(
    command: str, workspace: Path, harness: str,
) -> tuple[list[str] | None, str | None]:
    """Recognize one validator segment in a fully admitted direct/AND command."""
    parsed = parse_shell_command(command, harness, allow_unwrapped_codex=True)
    if parsed is None:
        return None, "command is not a complete bounded shell invocation"
    validators = []
    for index, segment in enumerate(parsed.segments):
        modes, _error = _validator_segment_modes(segment, workspace)
        if modes is not None:
            validators.append((index, modes))
    if len(validators) != 1:
        return None, "command does not contain exactly one complete validator segment"
    for index, segment in enumerate(parsed.segments):
        if _segment_mentions_suite_material(segment):
            return None, "command directly references evaluation-suite material"
        if classify_shell_segment(segment, workspace) is None:
            return None, "AND chain contains an unclassified command segment"
        if index != validators[0][0] and _validator_segment_modes(segment, workspace)[0] is not None:
            return None, "AND chain contains an additional validator segment"
    return validators[0][1], None


def is_relevant_modes(modes: list[str] | None) -> bool:
    return isinstance(modes, list) and ("all" in modes or "truthfulness" in modes)


def is_completion_json_helper(command: str, harness: str) -> bool:
    """Recognize the exact, standalone local JSON-artifact inspection command."""
    parsed = parse_shell_command(command, harness)
    return parsed is not None and len(parsed.segments) == 1 and is_completion_json_segment(parsed.segments[0])


def is_current_branch_observation(command: str, harness: str) -> bool:
    """Recognize only the exact read-only current-branch query."""
    parsed = parse_shell_command(command, harness)
    return parsed is not None and len(parsed.segments) == 1 and is_current_branch_segment(parsed.segments[0])


def _broad_suite_search_segment(segment: ShellSegment) -> bool:
    words = list(segment.argv)
    if not words:
        return False
    tool = Path(words[0]).name
    args = words[1:]
    recursive = tool == "rg" or tool in {"grep", "egrep", "fgrep"} and any(
        option in args for option in ("-r", "-R", "--recursive")
    ) or tool == "ls" and any(option in args for option in ("-R", "--recursive"))
    if not recursive and tool != "find":
        return False
    positional = [item for item in args if not item.startswith("-")]
    if tool in {"rg", "grep", "egrep", "fgrep"}:
        scopes = positional[1:]
    elif tool == "find":
        scopes = positional[:1] or ["."]
    else:
        scopes = positional or ["."]
    return not scopes or any(
        scope in {".", "./", "examples", "./examples"}
        or scope.startswith("examples/fresh-agent-evals")
        for scope in scopes
    )


def _broad_suite_search(command: str, harness: str) -> bool:
    parsed = parse_shell_command(command, harness)
    return parsed is not None and any(
        _broad_suite_search_segment(segment) for segment in parsed.segments
    )


def direct_suite_access(action: dict, harness: str, workspace: Path) -> bool:
    """Flag case/oracle/grader paths or recursive suite searches in any segment."""
    tool = action.get("tool")
    command = action.get("command")
    path = action.get("path")
    if tool in {"bash", "shell", "command_execution"} and isinstance(command, str):
        parsed = parse_shell_command(command, harness)
        if parsed is not None:
            for segment in parsed.segments:
                if _segment_mentions_suite_material(segment) or _broad_suite_search_segment(segment):
                    return True

    candidates = [item for item in (command, path, action.get("file_path")) if isinstance(item, str)]
    for value in candidates:
        if _mentions_suite_argument(value):
            return True
    return False
