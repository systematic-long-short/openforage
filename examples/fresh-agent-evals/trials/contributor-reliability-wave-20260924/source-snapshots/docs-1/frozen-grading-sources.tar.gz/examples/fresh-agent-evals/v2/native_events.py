"""Allowlisted OpenCode/Codex event normalization for v2 trial evidence."""

from __future__ import annotations

import hashlib
import json
import re
import sys
import datetime as dt
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE.parents[1] / "opencode-lifecycle"))

from bridge_core import redact_secret_shapes  # noqa: E402
from tool_outcomes import normalize_tool_actions  # noqa: E402
from commands import normalize_command  # noqa: E402

PREVIEW_LIMIT = 300
NORMALIZED_COMMAND_LIMIT = 2048
STATUS_VALUES = {"completed", "failed", "error", "denied", "cancelled", "timeout", "running", "pending", "unknown"}
CODEX_TODO_LIST_LIFECYCLE = {"item.started", "item.updated", "item.completed"}
SECRET_SHAPE_RE = re.compile(r"(?i)(?:sk-[A-Za-z0-9_-]{20,}|ghp_[A-Za-z0-9]{36}|AKIA[0-9A-Z]{16})")


def _event_epoch(event: dict) -> float | None:
    raw = next((event[key] for key in ("timestamp", "time", "created", "at", "ts") if key in event), None)
    if isinstance(raw, bool) or raw is None:
        return None
    if isinstance(raw, (int, float)):
        value = float(raw)
        if value > 1e15:
            return value / 1e6
        if value > 1e12:
            return value / 1e3
        return value
    if isinstance(raw, str):
        try:
            return dt.datetime.fromisoformat(raw.strip().replace("Z", "+00:00")).timestamp()
        except ValueError:
            try:
                return float(raw)
            except ValueError:
                return None
    return None


def parse_jsonl(raw: bytes) -> tuple[list[dict], bool, int]:
    """Parse native JSONL while exposing whether any nonempty line was lost."""
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        text = raw.decode("utf-8", "replace")
        decode_complete = False
    else:
        decode_complete = True
    events: list[dict] = []
    invalid = 0
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        try:
            payload = json.loads(stripped)
        except ValueError:
            invalid += 1
            continue
        if isinstance(payload, dict):
            events.append(payload)
        elif isinstance(payload, list):
            events.extend(item for item in payload if isinstance(item, dict))
        else:
            invalid += 1
    return events, decode_complete and invalid == 0, invalid


def _safe_text(value: str, workspace: Path, repo: Path) -> str:
    text = redact_secret_shapes(value)
    text = SECRET_SHAPE_RE.sub("<REDACTED>", text)
    for original, replacement in (
        (str(workspace.resolve()), "<WORKSPACE>"),
        (str(repo.resolve()), "<REPO>"),
        (str(Path.home().resolve()), "<HOME>"),
    ):
        text = text.replace(original, replacement)
    return text


def _session_id(events: list[dict], harness: str) -> str | None:
    keys = {"codex": ("thread_id", "threadID"), "opencode": ("sessionID", "session_id", "sessionId")}[harness]
    for event in events:
        candidates = [event]
        if isinstance(event.get("item"), dict):
            candidates.append(event["item"])
        for value in candidates:
            for key in keys:
                if isinstance(value.get(key), str) and value[key]:
                    return value[key]
    return None


def normalize_opencode(raw: bytes, workspace: Path, repo: Path) -> dict:
    events, complete, invalid = parse_jsonl(raw)
    replacements = (
        (str(workspace.resolve()), "<WORKSPACE>"),
        (str(repo.resolve()), "<REPO>"),
        (str(Path.home().resolve()), "<HOME>"),
    )
    actions = normalize_tool_actions(
        events,
        replacements=replacements,
        redact=redact_secret_shapes,
    )
    questions = [action for action in actions if action.get("tool") == "question"]
    question_ids = [action.get("native_tool_call_id_sha256") for action in questions]
    clarification_count = (
        len(set(question_ids))
        if all(isinstance(value, str) for value in question_ids)
        and all(action.get("correlation_conflict") is not True for action in questions)
        else None
    )
    incomplete_tools = {"other", "task", "webfetch", "websearch", "python", "lsp", "skill"}
    unclassified_tools = sum(1 for action in actions if action.get("tool") in incomplete_tools)
    last_event_by_call = {}
    for sequence, event in enumerate(events):
        part = event.get("part") if isinstance(event, dict) else None
        call_id = part.get("callID") if isinstance(part, dict) else None
        if isinstance(call_id, str) and call_id:
            last_event_by_call[hashlib.sha256(call_id.encode("utf-8")).hexdigest()] = sequence
    for action in actions:
        sequence = action.get("event_sequence")
        call_hash = action.get("native_tool_call_id_sha256")
        action["completion_sequence"] = last_event_by_call.get(call_hash, sequence)
        if type(sequence) is int and sequence < len(events):
            action["event_timestamp_epoch"] = _event_epoch(events[sequence])
    return {
        "actions": actions,
        "events_observed": len(events),
        "invalid_lines": invalid,
        "unclassified_tool_count": unclassified_tools,
        "trace_complete": complete and bool(events) and unclassified_tools == 0,
        "clarification_observations": clarification_count,
        "session_id_sha256": hashlib.sha256(_session_id(events, "opencode").encode()).hexdigest()
        if _session_id(events, "opencode") else None,
    }


def _native_status(item: dict) -> str:
    value = item.get("status")
    if not isinstance(value, str):
        return "missing"
    normalized = value.casefold()
    return normalized if normalized in STATUS_VALUES else "unknown"


def _codex_id(item: dict) -> tuple[str | None, str | None]:
    value = item.get("id")
    if not isinstance(value, str) or not value:
        return None, None
    digest = hashlib.sha256(value.encode("utf-8")).hexdigest()
    safe = value if len(value) <= 160 and re.fullmatch(r"[A-Za-z0-9._:-]+", value) else None
    return safe, digest


def _valid_codex_todo_list(item: dict, event_type: str) -> bool:
    if event_type not in CODEX_TODO_LIST_LIFECYCLE or _codex_id(item)[1] is None:
        return False
    items = item.get("items")
    return isinstance(items, list) and all(
        isinstance(todo, dict)
        and isinstance(todo.get("text"), str)
        and type(todo.get("completed")) is bool
        for todo in items
    )


def _explicit_exit(item: dict) -> tuple[str, int | None]:
    if "exit_code" not in item:
        return "missing", None
    value = item.get("exit_code")
    if type(value) is not int:
        return "unknown", None
    return "observed", value


def _codex_file_changes(item: dict, event_type: str, sequence: int, workspace: Path) -> list[dict]:
    item_id, item_id_hash = _codex_id(item)
    status = _native_status(item)
    changes = item.get("changes")
    if not isinstance(changes, list):
        return [{
            "tool": "file_change", "native_item_id": item_id,
            "native_item_id_sha256": item_id_hash, "event_sequence": sequence,
            "event_timestamp_epoch": None,
            "lifecycle_event": event_type, "native_status": status,
            "exit_code_status": "not_applicable", "exit_code": None,
            "path": None, "path_status": "missing", "change_kind": "unknown",
        }]
    actions = []
    for index, change in enumerate(changes):
        if not isinstance(change, dict):
            continue
        raw_path = change.get("path")
        path = None
        path_status = "missing"
        if isinstance(raw_path, str):
            candidate = Path(raw_path)
            if "\\" in raw_path or ".." in candidate.parts:
                path_status = "outside_workspace"
            else:
                resolved = candidate.resolve() if candidate.is_absolute() else (workspace / candidate).resolve()
                if resolved.is_relative_to(workspace.resolve()):
                    path = resolved.relative_to(workspace.resolve()).as_posix()
                    path_status = "workspace_relative"
                else:
                    path_status = "outside_workspace"
        raw_kind = change.get("kind")
        kind = raw_kind.casefold() if isinstance(raw_kind, str) and raw_kind.casefold() in {
            "add", "create", "update", "modify", "delete", "remove"
        } else "unknown"
        actions.append({
            "tool": "file_change", "native_item_id": item_id,
            "native_item_id_sha256": item_id_hash, "event_sequence": sequence,
            "change_index": index, "lifecycle_event": event_type,
            "native_status": status, "path": path, "event_timestamp_epoch": None,
            "exit_code_status": "not_applicable", "exit_code": None,
            "path_status": path_status,
            "change_kind": kind,
        })
    return actions


def normalize_codex(raw: bytes, workspace: Path, repo: Path) -> dict:
    """Normalize Codex command/file items and non-executable todo metadata."""
    events, complete, invalid = parse_jsonl(raw)
    grouped: dict[tuple[str, str], dict] = {}
    order: list[tuple[str, str]] = []
    file_actions: list[dict] = []
    planning_metadata: list[dict] = []
    unclassified = 0
    clarification_ids: set[str] = set()
    clarifications_complete = True
    for sequence, event in enumerate(events):
        event_type = event.get("type")
        item = event.get("item")
        if not isinstance(item, dict) or not isinstance(event_type, str) or not event_type.startswith("item."):
            continue
        item_type = item.get("type")
        if not isinstance(item_type, str):
            unclassified += 1
            continue
        if item_type in {"question", "user_input"}:
            item_hash = _codex_id(item)[1]
            if item_hash is None:
                clarifications_complete = False
            else:
                clarification_ids.add(item_hash)
        if item_type == "todo_list":
            if _valid_codex_todo_list(item, event_type):
                _item_id, item_id_hash = _codex_id(item)
                planning_metadata.append({
                    "classification": "planning_metadata",
                    "native_item_id_sha256": item_id_hash,
                    "event_sequence": sequence,
                    "lifecycle_event": event_type,
                })
            else:
                unclassified += 1
            continue
        if item_type == "file_change":
            file_actions.extend(_codex_file_changes(item, event_type, sequence, workspace))
            continue
        if item_type != "command_execution":
            if item_type not in {"agent_message", "reasoning", "user_input", "question"}:
                unclassified += 1
            continue
        item_id, item_id_hash = _codex_id(item)
        key = (item_id or f"event-{sequence}", "command_execution")
        command = item.get("command")
        command = command if isinstance(command, str) else None
        action = grouped.get(key)
        if action is None:
            action = {
                "tool": "command_execution", "native_item_id": item_id,
                "native_item_id_sha256": item_id_hash,
                "event_sequence": sequence, "completion_sequence": None,
                "command_value": command, "command_conflict": False,
                "exit_code_status": "missing", "exit_code": None,
                "native_status": "missing", "lifecycle_events": [],
                "terminal_outcomes": [],
            }
            grouped[key] = action
            order.append(key)
        elif command is not None and action["command_value"] not in {None, command}:
            action["command_conflict"] = True
        elif command is not None:
            action["command_value"] = command
        action["lifecycle_events"].append(event_type)
        explicit_status = _native_status(item)
        if explicit_status != "missing":
            action["native_status"] = explicit_status
        if event_type in {"item.completed", "item.failed"}:
            action["completion_sequence"] = sequence
            exit_status, exit_code = _explicit_exit(item)
            action["terminal_outcomes"].append((event_type, exit_status, exit_code))

    actions = []
    for key in order:
        item = grouped[key]
        original = item.pop("command_value")
        safe = _safe_text(original, workspace, repo) if isinstance(original, str) else None
        if item.pop("command_conflict"):
            safe = None
        terminal_outcomes = item.pop("terminal_outcomes")
        if len(terminal_outcomes) == 1:
            _event_type, item["exit_code_status"], item["exit_code"] = terminal_outcomes[0]
        elif terminal_outcomes:
            item["exit_code_status"], item["exit_code"] = "unknown", None
        preview = safe[:PREVIEW_LIMIT] if safe is not None else None
        normalized, normalization = normalize_command(safe, "codex") if safe is not None else (None, "missing")
        encoded = safe.encode("utf-8") if safe is not None else b""
        item.update({
            "command": preview,
            "command_sha256": hashlib.sha256(encoded).hexdigest() if safe is not None else None,
            "command_bytes": len(encoded) if safe is not None else None,
            "command_truncated": len(encoded) > PREVIEW_LIMIT if safe is not None else None,
            "normalized_command": normalized if normalized is not None and len(normalized.encode()) <= NORMALIZED_COMMAND_LIMIT else None,
            "normalization": normalization,
        })
        item["lifecycle_events"] = sorted(set(item["lifecycle_events"]))
        sequence = item.get("event_sequence")
        if type(sequence) is int and sequence < len(events):
            item["event_timestamp_epoch"] = _event_epoch(events[sequence])
        actions.append(item)
    for action in file_actions:
        sequence = action.get("event_sequence")
        if type(sequence) is int and sequence < len(events):
            action["event_timestamp_epoch"] = _event_epoch(events[sequence])
    actions.extend(file_actions)
    session = _session_id(events, "codex")
    return {
        "actions": actions,
        "planning_metadata": planning_metadata,
        "events_observed": len(events),
        "invalid_lines": invalid,
        "unclassified_item_count": unclassified,
        "clarification_observations": len(clarification_ids) if clarifications_complete else None,
        "trace_complete": complete and bool(events) and unclassified == 0,
        "session_id_sha256": hashlib.sha256(session.encode()).hexdigest() if session else None,
    }
