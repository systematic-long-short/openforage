# Paper-backed research contribution evaluation

This optional fresh-agent fixture requires a completed, executable challenger
contribution: a locally authored Python callback, a typed research/result
artifact, and a machine report whose development claims are independently
recomputed by the grader. It is an instruction-isolated public fixture, not a
blind evaluation or an operating-system security boundary.

The native subject trace has a focused access audit. It permits the task,
research README and schemas, callback contract, cited excerpt and provenance,
the selected series manifest, authored outputs, bounded hashes of those paths,
native writes to the declared contribution files, and the exact development
evaluator command. Direct subject reads or shell inspection/execution of the
reserved `fixture.json`, `research_grader.py`, `research_selfcheck.py`, or
`v2/grader.py` fail; `runner.py` is invoked only by that exact development
command. The evaluator's trusted internal reads are not counted as subject file
actions. Other evaluator implementation source files are outside the subject
read allowlist. Unsupported or incomplete native traces remain unknown and
cannot establish reserved-input isolation. This is instruction-level evidence,
not an adversarial operating-system sandbox.

The synthetic evaluator compares the callback with a separately implemented
uniform selector over the fixture's eligible pairs. Both arms receive paired
seeds and the same completed-evaluator-call target. This reference is named
`synthetic_uniform_pair_selector_v1`; it is not OpenForage's `genetic`
algorithm, a measured library result, or evidence of live performance. The
separate `genetic` target remains 100,000 completed simulations and is
unmeasured here.

## Stable callback fixture interface

The contribution file is `trial-output/challenger.py` and must define a local
`def challenger(ctx)` generator that yields one graph payload per `yield`.
`ctx` is the explicitly test-only `FixtureContext` in `contract.py`, not an
OpenForage `SearchContext` or a library API. Its fields and method are:

- `seed`: paired deterministic fixture seed;
- `depth`: synthetic fixture depth cap, always 6;
- `scope`: synthetic `era_id` and `config_id` for this input;
- `eligible_pairs`: loaded, eligible `rotation|feature` identifiers in this
  fixture only;
- `excluded_pairs`: the fixture's excluded or unloaded identifiers;
- `pair_descriptors`: supplied fixture metadata, not candidate introspection;
- `stream_for(pair_id)`: the shared finite test stream for that pair, yielding
  synthetic JSON graph payloads. Calling it again returns the same stream
  cursor.

The fixture deliberately includes repeated graph identities, unknown payloads,
excluded/unloaded pairs, and graphs whose supplied synthetic depth exceeds 6.
The trusted evaluator maps exact canonical fixture payloads to descriptors; it
does not trust a callback's claimed feature, rotation, depth, or quality.
Only a unique, known, loaded, eligible payload at depth 1–6 that the evaluator
actually evaluates increments the completed-call counter. Proposal, duplicate,
invalid, excluded, unloaded, and over-depth attempts do not.

The paper attribution reuses the existing archived excerpt at
[`../fixtures/challenger-research/trial-inputs/primary-source-excerpt.md`](../fixtures/challenger-research/trial-inputs/primary-source-excerpt.md).
The short note in `source-provenance.json` is a paraphrase of Mouret and Clune's
MAP-Elites description, not a quotation or a superiority claim. Do not extend
the archived quotation.

## Offline use

Run from the checkout root. These commands make no harness/model calls and need
no package install, network, credentials, wallet, or live search:

```bash
PYTHONDONTWRITEBYTECODE=1 .venv-docs/bin/python examples/fresh-agent-evals/research/runner.py --selfcheck
```

After reviewing the task, templates, grader, fixtures, provenance, and helper
closure, freeze a new series exactly once. The output path must not already
exist; every run and grader rechecks the frozen digests:

```bash
PYTHONDONTWRITEBYTECODE=1 .venv-docs/bin/python examples/fresh-agent-evals/research/runner.py \
  --freeze --series-id <series-id> \
  --output examples/fresh-agent-evals/research/series/<series-id>.json
PYTHONDONTWRITEBYTECODE=1 .venv-docs/bin/python examples/fresh-agent-evals/research/runner.py \
  --check-freeze --series-manifest examples/fresh-agent-evals/research/series/<series-id>.json
```

The native action is explicit and should be run only by the parent after the
implementation session and any callback workers have exited. Supply a caller-
chosen model and harness selector; there is no model default. Run one harness
first, then pin the other to the first trial's `snapshot_sha256` if comparing
harness subjects:

```bash
PYTHONDONTWRITEBYTECODE=1 .venv-docs/bin/python examples/fresh-agent-evals/research/runner.py \
  --native-run --harness opencode --case paper-backed-coverage-challenger \
  --series-manifest examples/fresh-agent-evals/research/series/<series-id>.json \
  --model <provider/model> --variant <caller-selected-variant> --run-id opencode-research-1

PYTHONDONTWRITEBYTECODE=1 .venv-docs/bin/python examples/fresh-agent-evals/research/runner.py \
  --native-run --harness codex --case paper-backed-coverage-challenger \
  --series-manifest examples/fresh-agent-evals/research/series/<series-id>.json \
  --model <provider/model> --reasoning-effort <caller-selected-effort> \
  --expected-snapshot-sha256 <snapshot-sha256-from-first-trial> --run-id codex-research-1
```

The child first writes `trial-output/challenger.py`, then runs the exact
development-only evaluator command shown in its task prompt to create
`trial-output/comparison-report.json`, then writes
`trial-output/research-result.json` with source, implementation, report, and
series hashes. The grader checks that a completed native command with the
recorded full command digest and unique lifecycle identity occurred between
those writes; a self-reported command result is not evidence.

The development-only command, also usable for a local callback check after a
series is frozen, is:

```bash
PYTHONDONTWRITEBYTECODE=1 .venv-docs/bin/python examples/fresh-agent-evals/research/runner.py \
  --evaluate-development --implementation trial-output/challenger.py \
  --report-out trial-output/comparison-report.json \
  --series-manifest examples/fresh-agent-evals/research/series/<series-id>.json
```

For a retained native run, the runner independently executes the callback on
each development input/seed and a reserved held-out input/seed, then writes a
sanitized verdict with the full recomputed coverage/comparison report under
`.tmp/fresh-agent-research/runs/<series-id>/<run-id>/`. The held-out input is
not part of the development report and should not be used while developing a
native subject. All fixture material is public, so this remains instruction-
isolated rather than perfectly blind. Raw native streams remain in ignored
`.tmp` scratch; records, patches, hashes, and verdicts omit private host paths
and can be exported after review.

A retained run can be independently graded again without launching a harness.
The runner resolves its local throwaway workspace from the recorded `run_id`;
an explicit `--workspace` may be supplied if the workspace was moved:

```bash
PYTHONDONTWRITEBYTECODE=1 .venv-docs/bin/python examples/fresh-agent-evals/research/runner.py \
  --grade \
  --trial .tmp/fresh-agent-research/runs/<series-id>/<run-id>/trial.json \
  --series-manifest examples/fresh-agent-evals/research/series/<series-id>.json \
  --output .tmp/fresh-agent-research/runs/<series-id>/<run-id>/independent-regrade.json
```

The report labels every quality bit synthetic, scopes the eligible denominator
to the fixture, and leaves live performance, out-of-sample return correlation,
and server acceptance `null` with status `unknown`. If either arm exhausts
before the target, it reports `incomplete_comparison` with the observed counts;
it does not pad counts. Negative and inconclusive outcomes are valid, and no
challenger superiority is required. Construction coverage is not return
correlation.

An unavailable optional OpenCode or Codex runtime produces a clear
`unavailable` record rather than a guessed command result. The offline
`--selfcheck` remains available everywhere and never launches a harness.
