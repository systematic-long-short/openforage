"""Offline synthetic regressions for the paper-backed research evaluation."""

from __future__ import annotations

import hashlib
import json
import os
import shlex
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
EVALS_ROOT = HERE.parent
ROOT = HERE.parents[2]
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))
if str(EVALS_ROOT / "v2") not in sys.path:
    sys.path.insert(0, str(EVALS_ROOT / "v2"))

from callback_worker import _local_callback_source  # noqa: E402
from contract import FixtureContext  # noqa: E402
from research_grader import (  # noqa: E402
    CASE_ID,
    CODE_REL,
    REPORT_REL,
    RESULT_REL,
    _research_action_problems,
    _expected_machine_claims,
    _expected_eval_command,
    _native_command_evidence,
    grade_contribution,
)
from series import SeriesError, build_series, frozen_paths, verify_series, write_series_once  # noqa: E402
from synthetic_evaluator import (  # noqa: E402
    _RunAccumulator,
    canonical_json_equal,
    load_fixture,
)
from v2.paths import mkdir_chain_no_symlinks  # noqa: E402
from v2.snapshot import digest_map, file_map  # noqa: E402

REGRESSION_ONLY_CALLBACK = '''\
def challenger(ctx):
    yield next(ctx.stream_for(ctx.eligible_pairs[0]))
'''
MANIFEST_REL = "examples/fresh-agent-evals/research/series/selfcheck-series-c.json"


def _digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _access_action(tool: str, command: str) -> dict:
    raw = command.encode("utf-8")
    return {
        "tool": tool,
        "command": command,
        "command_sha256": _digest(raw),
        "command_bytes": len(raw),
        "command_truncated": False,
    }


def _complete_access_trace(actions: list, harness: str) -> dict:
    return {
        "actions": actions,
        "events_observed": max(1, len(actions)),
        "invalid_lines": 0,
        "trace_complete": True,
        "unclassified_tool_count" if harness == "opencode" else "unclassified_item_count": 0,
    }


def _json_bytes(payload: dict) -> bytes:
    return (json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode("utf-8")


def _copy_closure(source: Path, target: Path) -> None:
    for relative in frozen_paths(source):
        origin = source / relative
        destination = target / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(origin, destination)


def _make_positive_fixture(root: Path, scratch: Path) -> tuple[Path, Path, dict, dict]:
    rubric = scratch / "rubric"
    rubric.mkdir()
    _copy_closure(root, rubric)
    manifest = build_series(rubric, "selfcheck-series-c")
    series_file = write_series_once(rubric, MANIFEST_REL, manifest)
    _loaded, manifest_digest = verify_series(rubric, MANIFEST_REL)

    workspace = scratch / "workspace-positive"
    shutil.copytree(rubric, workspace)
    (workspace / "trial-output").mkdir()
    initial = file_map(workspace)
    snapshot_digest = digest_map(initial)
    code_path = workspace / CODE_REL
    code_path.write_text(REGRESSION_ONLY_CALLBACK, encoding="utf-8")

    provenance_path = workspace / "examples/fresh-agent-evals/research/source-provenance.json"
    provenance = json.loads(provenance_path.read_text(encoding="utf-8"))
    excerpt_digest = _digest((workspace / provenance["source_excerpt_path"]).read_bytes())
    runner_path = workspace / "examples/fresh-agent-evals/research/runner.py"
    environment = dict(os.environ)
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    cli_result = subprocess.run(
        [
            sys.executable, str(runner_path), "--evaluate-development",
            "--implementation", CODE_REL,
            "--report-out", REPORT_REL,
            "--series-manifest", MANIFEST_REL,
            "--repo", str(workspace),
        ],
        cwd=workspace,
        env=environment,
        capture_output=True,
        text=True,
        timeout=120,
    )
    if cli_result.returncode != 0:
        raise RuntimeError("development evaluator CLI selfcheck failed")
    report_path = workspace / REPORT_REL
    dev_report = json.loads(report_path.read_text(encoding="utf-8"))
    report_digest = _digest(report_path.read_bytes())
    implementation_digest = _digest(code_path.read_bytes())
    result = {
        "schema_version": 1,
        "task_id": "paper-backed-coverage-challenger-v1",
        "source": {
            "source_excerpt_path": provenance["source_excerpt_path"],
            "source_excerpt_sha256": excerpt_digest,
            "title": provenance["title"],
            "authors": provenance["authors"],
            "year": provenance["year"],
            "identifier": provenance["identifier"],
            "url": provenance["url"],
            "paraphrase": "MAP-Elites maintains strong candidates across user-chosen descriptor cells, making the distribution visible rather than showing only a single best candidate.",
        },
        "research": {
            "mechanism_explanation": "The callback schedules fixture streams by feature and rotation pair; the evaluator keeps the supplied descriptor metadata separate from graph payload claims.",
            "hypothesis": "Under equal completed synthetic evaluator calls, the coverage-oriented schedule may reach a different number of eligible fixture cells than the synthetic uniform selector.",
            "falsifier": "The paired synthetic runs show no coverage difference or the callback exhausts before the target; neither outcome establishes live behavior.",
        },
        "machine_claims": _expected_machine_claims(
            series_path=MANIFEST_REL,
            series_id=manifest["series_id"],
            series_digest=manifest_digest,
            implementation_digest=implementation_digest,
            report_digest=report_digest,
            source_excerpt_digest=excerpt_digest,
        ),
        "human_review": {
            "summary": "Regression-only callback completed its development fixture execution.",
            "rationale": "This small selfcheck callback exercises the contract and grader; it is not a task starter or a research result.",
        },
    }
    result_path = workspace / RESULT_REL
    result_path.write_bytes(_json_bytes(result))

    trial = {
        "series_id": manifest["series_id"],
        "series_manifest_path": MANIFEST_REL,
        "series_manifest_sha256": manifest_digest,
        "case_id": CASE_ID,
        "snapshot_sha256": snapshot_digest,
        "initial_file_sha256": initial,
        "artifact_sha256": {
            CODE_REL: implementation_digest,
            REPORT_REL: report_digest,
            RESULT_REL: _digest(result_path.read_bytes()),
        },
    }
    return rubric, workspace, trial, dev_report


def _trial_with_current_artifacts(workspace: Path, trial: dict) -> dict:
    updated = dict(trial)
    updated["artifact_sha256"] = {
        relative: _digest((workspace / relative).read_bytes())
        for relative in (CODE_REL, REPORT_REL, RESULT_REL)
        if (workspace / relative).is_file() and not (workspace / relative).is_symlink()
    }
    return updated


def _check_accounting(failures: list[str], root: Path) -> None:
    fixture, _raw = load_fixture(root)
    fixture_input = fixture["inputs"][0]
    accumulator = _RunAccumulator(fixture_input, fixture["target_completed_evaluations_per_arm"])
    streams = fixture_input["candidate_streams"]
    pair_map = {item["pair_id"]: item for item in fixture_input["pairs"]}
    valid = next(
        record["payload"] for pair_id, records in streams.items() for record in records
        if pair_map[pair_id]["loaded"] is True and pair_map[pair_id]["eligible"] is True
        and record["depth"] is not None and record["depth"] <= 6
    )
    valid_transport = {"transport_status": "ok", "payload": valid}
    accumulator.add_transport(valid_transport)
    accumulator.add_transport(valid_transport)
    depth_payload = next(
        record["payload"] for records in streams.values() for record in records
        if record["depth"] is not None and record["depth"] > 6
    )
    accumulator.add_transport({"transport_status": "ok", "payload": depth_payload})
    excluded_pair_id = next(item["pair_id"] for item in fixture_input["pairs"] if item["loaded"] and not item["eligible"])
    excluded_payload = streams[excluded_pair_id][0]["payload"]
    accumulator.add_transport({"transport_status": "ok", "payload": excluded_payload})
    unloaded_pair_id = next(item["pair_id"] for item in fixture_input["pairs"] if not item["loaded"])
    unloaded_payload = streams[unloaded_pair_id][0]["payload"]
    accumulator.add_transport({"transport_status": "ok", "payload": unloaded_payload})
    unknown_payload = next(
        record["payload"] for records in streams.values() for record in records
        if record["synthetic_quality_pass"] is None
    )
    accumulator.add_transport({"transport_status": "ok", "payload": unknown_payload})
    accumulator.add_transport({"transport_status": "not_json_compatible"})
    summary = accumulator.snapshot()
    if accumulator.ledger.evaluations != 1 or summary["unique_valid_cell_count"] != 1:
        failures.append("only one trusted valid unique fixture payload counted as an evaluator completion")
    if summary["rejections"] != {
        "duplicate_identity": 1,
        "depth_over_six": 1,
        "excluded_pair": 1,
        "unloaded_pair": 1,
        "unknown_identity": 1,
        "invalid_payload": 1,
    }:
        failures.append("duplicate, depth, excluded, unloaded, unknown, or invalid attempts were not separated")


def _check_native_linkage(failures: list[str], workspace: Path, trusted_root: Path) -> None:
    series_path = MANIFEST_REL
    command = (
        "PYTHONDONTWRITEBYTECODE=1 python examples/fresh-agent-evals/research/runner.py "
        "--evaluate-development --implementation trial-output/challenger.py "
        "--report-out trial-output/comparison-report.json "
        f"--series-manifest {series_path}"
    )
    digest = _digest(command.encode("utf-8"))

    def file_write(relative: str, call_id: str, sequence: int) -> dict:
        return {
            "tool": "write",
            "command": relative,
            "command_sha256": _digest(relative.encode("utf-8")),
            "command_bytes": len(relative.encode("utf-8")),
            "command_truncated": False,
            "native_tool_call_id_sha256": _digest(call_id.encode("utf-8")),
            "event_sequence": sequence,
            "completion_sequence": sequence,
            "outcome_schema_version": 1,
            "outcome": {"native_tool_status": "completed"},
            "correlation_conflict": False,
        }

    actions = [
        file_write(CODE_REL, "code-write", 2),
        {
            "tool": "bash",
            "command": command,
            "command_sha256": digest,
            "command_bytes": len(command.encode("utf-8")),
            "command_truncated": False,
            "native_tool_call_id_sha256": _digest(b"eval-call".decode("ascii").encode("utf-8")),
            "event_sequence": 10,
            "completion_sequence": 20,
            "outcome_schema_version": 1,
            "outcome": {"native_tool_status": "completed", "shell_exit_code_status": "observed", "shell_exit_code": 0},
            "correlation_conflict": False,
        },
        file_write(RESULT_REL, "result-write", 25),
    ]
    evidence, problems = _native_command_evidence(actions, "opencode", workspace, series_path)
    if problems or evidence.get("explicit_native_exit_code") != 0:
        failures.append(f"parsed command/lifecycle helper did not correlate the exact successful native command: {problems}")
    if _research_action_problems(
        actions, "opencode", workspace, trusted_root,
        trace=_complete_access_trace(actions, "opencode"),
        series_manifest_path=series_path,
    ):
        failures.append("the bounded native-action audit rejected its exact fixture command and local file writes")
    nested = [{
        "tool": "bash",
        "command": "opencode run --model caller/model task",
        "command_truncated": False,
    }]
    if not _research_action_problems(
        nested, "opencode", workspace, trusted_root,
        trace=_complete_access_trace(nested, "opencode"),
        series_manifest_path=series_path,
    ):
        failures.append("nested native model launch escaped the parsed-action audit")
    failed = [dict(action) for action in actions]
    failed[1] = dict(failed[1], outcome={"native_tool_status": "completed", "shell_exit_code_status": "missing", "shell_exit_code": None})
    failed_evidence, failed_problems = _native_command_evidence(failed, "opencode", workspace, series_path)
    if not failed_problems or failed_evidence:
        failures.append("missing explicit native exit metadata was accepted as a command pass")


def _check_research_access_audit(failures: list[str], workspace: Path, trusted_root: Path) -> None:
    series_path = MANIFEST_REL

    def problems(actions: list, harness: str = "opencode", *, trace: dict | None = None) -> list[str]:
        return _research_action_problems(
            actions,
            harness,
            workspace,
            trusted_root,
            trace=trace if trace is not None else _complete_access_trace(actions, harness),
            series_manifest_path=series_path,
        )

    useful_reads = (
        "examples/fresh-agent-evals/research/task.md",
        "examples/fresh-agent-evals/research/README.md",
        "examples/fresh-agent-evals/research/research-result.schema.json",
        "examples/fresh-agent-evals/research/callback-contract.md",
        "examples/fresh-agent-evals/fixtures/challenger-research/trial-inputs/primary-source-excerpt.md",
        series_path,
        CODE_REL,
        RESULT_REL,
    )
    for relative in useful_reads:
        action = _access_action("read", f"<WORKSPACE>/{relative}")
        if problems([action]):
            failures.append(f"documented native read was rejected: {relative}")
            break

    allowed_shell = [
        _access_action("bash", "cat examples/fresh-agent-evals/research/task.md"),
        _access_action(
            "bash",
            "sed -n '1,8p' examples/fresh-agent-evals/research/callback-contract.md",
        ),
        _access_action(
            "bash",
            "grep -n callback examples/fresh-agent-evals/fixtures/challenger-research/trial-inputs/primary-source-excerpt.md",
        ),
        _access_action(
            "bash",
            "rg callback examples/fresh-agent-evals/research/task.md",
        ),
        _access_action("bash", "cat trial-output/challenger.py"),
        _access_action("bash", f"sha256sum {series_path}"),
        _access_action(
            "bash",
            "shasum -a 256 examples/fresh-agent-evals/fixtures/challenger-research/trial-inputs/primary-source-excerpt.md",
        ),
    ]
    for action in allowed_shell:
        if problems([action]):
            failures.append("bounded documented shell read or hash command was rejected")
            break

    output_edits = [
        _access_action("write", CODE_REL),
        _access_action("write", RESULT_REL),
    ]
    if problems(output_edits):
        failures.append("native edits to the declared callback and research artifact were rejected")

    expected = _expected_eval_command(series_path)
    exact_opencode = _access_action("bash", expected)
    if problems([exact_opencode]):
        failures.append("exact selected-series development evaluator was rejected")
    exact_codex = _access_action("command_execution", f"bash -lc {shlex.quote(expected)}")
    if problems([exact_codex], "codex"):
        failures.append("exact selected-series Codex development evaluator was rejected")

    rejected_actions = [
        _access_action("read", "<WORKSPACE>/examples/fresh-agent-evals/research/fixture.json"),
        _access_action("read", "<WORKSPACE>/examples/fresh-agent-evals/research/research_grader.py"),
        _access_action("read", "<WORKSPACE>/examples/fresh-agent-evals/research/research_selfcheck.py"),
        _access_action("read", "<WORKSPACE>/examples/fresh-agent-evals/research/runner.py"),
        _access_action("bash", "cat examples/fresh-agent-evals/research/fixture.json"),
        _access_action("bash", "cat examples/fresh-agent-evals/research/fixture'.json'"),
        _access_action("bash", r"cat examples/fresh-agent-evals/research/fixtu\re.json"),
        _access_action("bash", "cat examples/fresh-agent-evals/research/research_grader.py"),
        _access_action("bash", "cat examples/fresh-agent-evals/research/research_selfcheck.py"),
        _access_action("bash", "python examples/fresh-agent-evals/research/research_grader.py"),
        _access_action("bash", "python examples/fresh-agent-evals/research/research_selfcheck.py"),
        _access_action("bash", "python examples/fresh-agent-evals/research/runner.py --selfcheck"),
        _access_action(
            "bash",
            "python3.12 -c \"open('examples/fresh-agent-evals/research/fixture.json').read()\"",
        ),
        _access_action(
            "bash",
            'sh -c "cat examples/fresh-agent-evals/research/fixture.json"',
        ),
        _access_action("bash", "node inspect.js"),
    ]
    for action in rejected_actions:
        if not problems([action]):
            failures.append(f"reserved or unsupported subject access was accepted: {action['command']}")
            break
    if not any("unknown" in item for item in problems([rejected_actions[-1]])):
        failures.append("unsupported shell executable did not leave the access audit unknown")

    missing_trace = _research_action_problems(
        [_access_action("read", "examples/fresh-agent-evals/research/task.md")],
        "opencode",
        workspace,
        trusted_root,
        series_manifest_path=series_path,
    )
    if not any("unknown" in item for item in missing_trace):
        failures.append("missing normalized access trace did not remain explicitly unknown")

    incomplete_trace = _complete_access_trace([], "opencode")
    incomplete_trace["trace_complete"] = False
    incomplete = problems([], trace=incomplete_trace)
    if not any("unknown" in item for item in incomplete):
        failures.append("incomplete native access trace did not remain explicitly unknown")

    truncated = _access_action("bash", "cat examples/fresh-agent-evals/research/task.md")
    truncated["command_truncated"] = True
    truncated_problems = problems([truncated])
    if not any("unknown" in item for item in truncated_problems):
        failures.append("truncated native shell command did not remain explicitly unknown")


def run_selfcheck(root: Path = ROOT) -> int:
    root = root.resolve()
    failures: list[str] = []
    check_names: list[str] = []

    for relative in (
        "research-result.schema.json", "comparison-report.schema.json", "fixture.schema.json",
        "series.schema.json", "trial-record.schema.json", "verdict.schema.json",
    ):
        try:
            json.loads((HERE / relative).read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            failures.append(f"typed schema JSON is invalid: {relative}")
    check_names.append("typed-schemas")

    fixture, _fixture_bytes = load_fixture(root)
    alpha = fixture["inputs"][0]
    context1 = FixtureContext(alpha, alpha["paired_seeds"][0])
    context2 = FixtureContext(alpha, alpha["paired_seeds"][0])
    pair = context1.eligible_pairs[0]
    first = list(context1.stream_for(pair))
    second = list(context2.stream_for(pair))
    if first != second:
        failures.append("fixture context streams are not deterministic for a paired seed")
    if not any(item["role"] == "reserved-heldout" for item in fixture["inputs"]):
        failures.append("reserved held-out fixture role is missing")
    check_names.append("fixture-contract-and-heldout")

    _check_accounting(failures, root)
    check_names.append("synthetic-ledger-accounting")

    try:
        _local_callback_source(HERE / "callback_worker.py")
        failures.append("callback worker source was incorrectly accepted as a subject contribution")
    except (ValueError, SyntaxError):
        pass
    with tempfile.TemporaryDirectory(prefix="research-selfcheck-code-") as temp:
        subject = Path(temp) / "challenger.py"
        subject.write_text("# plan only; no executable callback\n", encoding="utf-8")
        try:
            _local_callback_source(subject)
        except (ValueError, SyntaxError):
            pass
        else:
            failures.append("plan-only contribution passed callback source validation")
        subject.write_text(
            "from coverage_challenger import _make_challenger_template\n"
            "def challenger(ctx):\n    yield from _make_challenger_template()(ctx)\n",
            encoding="utf-8",
        )
        try:
            _local_callback_source(subject)
        except (ValueError, SyntaxError):
            pass
        else:
            failures.append("bundled campaign example import was accepted as an authored implementation")
    check_names.append("authored-callback-and-plan-negatives")

    scratch_parent = root / ".tmp"
    mkdir_chain_no_symlinks(scratch_parent)
    with tempfile.TemporaryDirectory(prefix="research-eval-selfcheck-", dir=scratch_parent) as temp:
        scratch = Path(temp)
        try:
            rubric, workspace, trial, expected_dev_report = _make_positive_fixture(root, scratch)
            manifest, manifest_digest = verify_series(rubric, MANIFEST_REL)
            if manifest_digest != trial["series_manifest_sha256"]:
                failures.append("series digest changed during the selfcheck fixture build")
            verdict = grade_contribution(
                rubric, workspace, trial, MANIFEST_REL,
                evidence_scope="synthetic-selfcheck",
            )
            if verdict.get("success") is not True or verdict.get("evidence_scope") != "synthetic-selfcheck":
                failures.append(f"valid synthetic contribution did not pass independent grading: {verdict.get('failure_reasons')}")
            independent_report = verdict.get("independent_report")
            if not isinstance(independent_report, dict) or independent_report.get("role_scope") != "development_plus_reserved_heldout":
                failures.append("independent report did not recompute development and reserved held-out inputs")
            if isinstance(independent_report, dict):
                if independent_report.get("run_count") != 6:
                    failures.append("independent grader did not execute multiple input/seed pairs")
                if independent_report.get("comparison_status") != "incomplete_comparison":
                    failures.append("a deliberately short regression callback did not retain its honest incomplete status")
                if independent_report.get("separate_genetic_campaign_target", {}).get("observed_completed_simulations") is not None:
                    failures.append("synthetic selfcheck invented an observed genetic baseline count")
            check_names.append("positive-independent-grade-and-heldout")

            mutations = []
            hardcoded = json.loads(json.dumps(expected_dev_report))
            hardcoded["runs"][0]["challenger"]["completed_evaluator_calls"] = 999
            hardcoded["runs"][0]["challenger"]["target_reached"] = True
            mutations.append(("forged-count", hardcoded))
            invalid_cell = json.loads(json.dumps(expected_dev_report))
            invalid_cell["runs"][0]["challenger"]["unique_valid_cells_reached"].append("forged_rotation|forged_feature")
            invalid_cell["runs"][0]["challenger"]["unique_valid_cell_count"] += 1
            mutations.append(("invalid-cell-claim", invalid_cell))
            depth_forgery = json.loads(json.dumps(expected_dev_report))
            depth_forgery["runs"][0]["challenger"]["rejections"]["depth_over_six"] = 0
            depth_forgery["runs"][0]["challenger"]["completed_evaluator_calls"] += 1
            mutations.append(("depth-over-six-forgery", depth_forgery))
            stale = json.loads(json.dumps(expected_dev_report))
            stale["implementation_sha256"] = "0" * 64
            mutations.append(("stale-report", stale))
            if any(canonical_json_equal(candidate, expected_dev_report) for _name, candidate in mutations):
                failures.append("a hardcoded count, invalid cell/depth, or stale report matched the independent report")
            check_names.extend(name for name, _candidate in mutations)

            # One full-grade tamper case updates its self-reported hash to prove
            # that integrity hashes alone cannot make a forged report pass.
            tampered = scratch / "workspace-tampered-report"
            shutil.copytree(workspace, tampered)
            tampered_report = json.loads((tampered / REPORT_REL).read_text(encoding="utf-8"))
            tampered_report["runs"][0]["challenger"]["completed_evaluator_calls"] = 999
            (tampered / REPORT_REL).write_bytes(_json_bytes(tampered_report))
            result_data = json.loads((tampered / RESULT_REL).read_text(encoding="utf-8"))
            result_data["machine_claims"]["comparison_report_sha256"] = _digest((tampered / REPORT_REL).read_bytes())
            (tampered / RESULT_REL).write_bytes(_json_bytes(result_data))
            failed_verdict = grade_contribution(
                rubric, tampered, _trial_with_current_artifacts(tampered, trial), MANIFEST_REL,
                evidence_scope="synthetic-selfcheck",
            )
            if failed_verdict.get("success") is not False or not any(
                "not independently reproducible" in item for item in failed_verdict.get("failure_reasons", [])
            ):
                failures.append("tampered report passed after its claimed SHA-256 was updated")
            check_names.append("tampered-report-fails-after-rehash")

            missing = scratch / "workspace-missing-code"
            shutil.copytree(workspace, missing)
            (missing / CODE_REL).unlink()
            missing_verdict = grade_contribution(
                rubric, missing, _trial_with_current_artifacts(missing, trial), MANIFEST_REL,
                evidence_scope="synthetic-selfcheck",
            )
            if missing_verdict.get("success") is not False:
                failures.append("missing callback implementation passed the contribution grader")
            check_names.append("missing-code-fails")

            changed_validator = scratch / "workspace-changed-validator"
            shutil.copytree(workspace, changed_validator)
            validator = changed_validator / ".github/scripts/validation/evals.py"
            validator.write_bytes(validator.read_bytes() + b"\n# selfcheck drift\n")
            changed_verdict = grade_contribution(
                rubric, changed_validator, _trial_with_current_artifacts(changed_validator, trial), MANIFEST_REL,
                evidence_scope="synthetic-selfcheck",
            )
            if changed_verdict.get("success") is not False:
                failures.append("changed validator source passed the frozen-series grader")
            check_names.append("changed-validator-fails")

            # A named series is immutable: a second create and any frozen-file
            # change are refused, while the temporary series itself is not kept.
            try:
                write_series_once(rubric, MANIFEST_REL, manifest)
            except SeriesError:
                pass
            else:
                failures.append("series freezer overwrote an existing manifest")
            drift = rubric / "examples/fresh-agent-evals/research/callback-contract.md"
            drift.write_bytes(drift.read_bytes() + b"\nfixture drift\n")
            try:
                verify_series(rubric, MANIFEST_REL)
            except SeriesError:
                pass
            else:
                failures.append("series verifier accepted frozen helper drift")
            check_names.append("series-no-overwrite-and-drift")

            _check_native_linkage(failures, workspace, rubric)
            check_names.append("native-command-outcome-linkage")
            _check_research_access_audit(failures, workspace, rubric)
            check_names.append("research-subject-access-audit")
            if "examples/fresh-agent-evals/research/research_access.py" not in frozen_paths(root):
                failures.append("new research access helper is missing from future frozen-series discovery")
            check_names.append("research-access-helper-future-series-closure")
        except Exception as exc:  # noqa: BLE001 - report a short offline regression failure
            failures.append(f"selfcheck setup/execution failed: {type(exc).__name__}")

    result = {
        "suite": "paper-backed-coverage-research-v1",
        "status": "pass" if not failures else "fail",
        "synthetic_selfcheck": True,
        "native_calls": 0,
        "model_calls": 0,
        "checks": check_names,
        "failures": failures,
        "note": "Regression-only synthetic callbacks and reports are not native trials, API evidence, or performance measurements.",
    }
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(run_selfcheck())
