"""Shared helpers for the packet validator and its focused check modules."""

from __future__ import annotations

import datetime as _dt
import re
from pathlib import Path

SKIP_DIRS = {
    ".git",
    "__pycache__",
    ".mypy_cache",
    ".pytest_cache",
    "node_modules",
    ".tmp",
    ".venv",
    ".venv-docs",
}
TEXT_SUFFIXES = {".md", ".json", ".jsonl", ".yml", ".yaml", ".py", ".toml", ".txt", ".cfg"}

CAMPAIGN_DIR = "examples/agent-campaign"
STATE_MACHINE_PATH = "docs/agents/references/campaign-state-machine.json"

PLACEHOLDER_RE = re.compile(r"^<.*>$", re.S)
EMBEDDED_PLACEHOLDER_RE = re.compile(r"<[A-Za-z][^<>\n]*>")
ISO_DATETIME_RE = re.compile(
    r"^\d{4}-\d{2}-\d{2}"
    r"(?:[T ]\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?(?:Z|[+-]\d{2}:?\d{2})?)?$"
)
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
PASSING_RESULT_RE = re.compile(r"^\s*(?:passed|pass)\b", re.IGNORECASE)
PASSING_OUTCOMES = {"passed", "pass"}
FAILURE_RESULT_RE = re.compile(
    r"^\s*(?:fail|failed|failure|error|blocked|not observed|unverified)\b",
    re.IGNORECASE,
)


class Report:
    """Collects human-readable validation notes and failures."""

    def __init__(self) -> None:
        self.errors: list[str] = []
        self.notes: list[str] = []

    def fail(self, message: str) -> None:
        self.errors.append(message)

    def note(self, message: str) -> None:
        self.notes.append(message)

    @property
    def ok(self) -> bool:
        return not self.errors

    def dump(self) -> int:
        for note in self.notes:
            print(f"note: {note}")
        for error in self.errors:
            print(f"FAIL: {error}")
        if self.errors:
            print(f"\n{len(self.errors)} failure(s)")
            return 1
        print("ok")
        return 0


def iter_files(root: Path, suffixes: set[str] | None = None):
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        if any(part in SKIP_DIRS for part in path.relative_to(root).parts):
            continue
        if suffixes is not None and path.suffix.lower() not in suffixes:
            continue
        yield path


def rel(root: Path, path: Path) -> str:
    return path.relative_to(root).as_posix()


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def load_json(report: Report, path: Path):
    """Load JSON, reporting failures without raising."""
    import json

    try:
        return json.loads(read_text(path))
    except json.JSONDecodeError as exc:
        report.fail(f"{path.name}: invalid JSON: {exc}")
        return None


def is_placeholder(value) -> bool:
    return isinstance(value, str) and bool(PLACEHOLDER_RE.match(value.strip()))


def has_embedded_placeholder(value) -> bool:
    return isinstance(value, str) and bool(EMBEDDED_PLACEHOLDER_RE.search(value))


def is_number(value) -> bool:
    """True for int/float values; bools are not numbers here."""
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def is_integer_number(value) -> bool:
    return is_number(value) and float(value).is_integer()


def is_positive_integer(value) -> bool:
    return is_integer_number(value) and value > 0


def passing_result_problem(item) -> str | None:
    """Return a diagnostic when evidence lacks an explicit passing result.

    A typed ``outcome`` of ``passed``/``pass`` or an ``observed_result`` that
    begins with ``passed``/``pass`` counts. Merely omitting a failure word
    does not.
    """
    if not isinstance(item, dict):
        return "evidence must be an object with a passing observed_result"
    outcome = item.get("outcome")
    if isinstance(outcome, str) and outcome.strip().lower() in PASSING_OUTCOMES:
        return None
    observed = item.get("observed_result")
    if isinstance(observed, str):
        stripped = observed.strip()
        if PASSING_RESULT_RE.match(stripped):
            return None
        if FAILURE_RESULT_RE.match(stripped):
            return f"records a failure result: {observed!r}"
        return (
            "requires an explicit passing outcome (for example "
            f"'passed: ...' or outcome='passed'); found {observed!r}"
        )
    return "requires an explicit passing outcome (for example 'passed: ...' or outcome='passed')"


def is_nonnegative_number(value) -> bool:
    return is_number(value) and value >= 0


def is_iso_datetime(value) -> bool:
    if not isinstance(value, str) or not ISO_DATETIME_RE.match(value.strip()):
        return False
    text = value.strip().replace("Z", "+00:00").replace(" ", "T")
    try:
        _dt.datetime.fromisoformat(text)
    except ValueError:
        return False
    return True


def is_calendar_date(value) -> bool:
    if not isinstance(value, str) or not DATE_RE.match(value.strip()):
        return False
    try:
        _dt.date.fromisoformat(value.strip())
    except ValueError:
        return False
    return True


def parsed_iso(value) -> _dt.datetime | None:
    if not is_iso_datetime(value):
        return None
    text = value.strip().replace("Z", "+00:00").replace(" ", "T")
    parsed = _dt.datetime.fromisoformat(text)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=_dt.timezone.utc)
    return parsed


def is_real_string(value, *, allow_unknown: bool = False) -> bool:
    """Non-empty string that is neither a placeholder nor a not-recorded marker."""
    if not isinstance(value, str) or not value.strip():
        return False
    stripped = value.strip()
    if is_placeholder(stripped) or has_embedded_placeholder(stripped):
        return False
    if not allow_unknown and stripped.lower() in {"unknown", "missing", "not_recorded", "n/a"}:
        return False
    return True


def scan_placeholders(report: Report, where: str, obj, skip: frozenset[str] = frozenset()) -> None:
    """Reject placeholders, including placeholders embedded inside strings."""
    if isinstance(obj, dict):
        for key, value in obj.items():
            if key in skip:
                continue
            scan_placeholders(report, f"{where}.{key}", value, skip)
    elif isinstance(obj, list):
        for index, value in enumerate(obj):
            scan_placeholders(report, f"{where}[{index}]", value, skip)
    elif is_placeholder(obj) or has_embedded_placeholder(obj):
        report.fail(f"{where}: unfilled placeholder {obj!r} in a non-template record")


def resolve_repo_artifact(root: Path, reference, extra_roots: tuple[Path, ...] = ()) -> Path | None:
    """Resolve a repo-relative artifact reference, rejecting escapes.

    Absolute paths, ``..`` traversal, and resolutions outside ``root`` are
    rejected. ``extra_roots`` are additional bases tried for convenience.
    """
    if not isinstance(reference, str) or not reference.strip():
        return None
    text = reference.strip()
    candidate_path = Path(text)
    if candidate_path.is_absolute() or any(part == ".." for part in candidate_path.parts):
        return None
    resolved_root = root.resolve()
    candidates = [base / candidate_path for base in (extra_roots + (root,))]
    for candidate in candidates:
        try:
            resolved = candidate.resolve()
        except OSError:
            continue
        if not resolved.is_relative_to(resolved_root):
            continue
        if resolved.is_file():
            return resolved
    return None


def load_structured_json(reference, root: Path) -> tuple[dict | None, str | None]:
    """Load a referenced JSON evidence object; return (data, problem)."""
    import json

    path = resolve_repo_artifact(root, reference) if is_real_string(reference) else None
    if path is None:
        return None, "must exist inside the repository"
    if path.suffix.lower() != ".json":
        return None, "must be a structured JSON artifact, not an unstructured document"
    try:
        data = json.loads(path.read_text(encoding="utf-8", errors="replace"))
    except (OSError, ValueError):
        return None, "must contain parseable JSON"
    if not isinstance(data, dict):
        return None, "must contain a JSON object"
    return data, None
