"""Relative link and internal anchor validation for Markdown files."""

from __future__ import annotations

import re
from pathlib import Path

from .common import iter_files, read_text, rel

LINK_PATTERN = re.compile(r"\[[^\]]*\]\(([^)\s]+)(?:\s+\"[^\"]*\")?\)")
HEADING_PATTERN = re.compile(r"^(#{1,6})\s+(.*?)\s*#*\s*$")
HTML_ANCHOR_PATTERN = re.compile(r"<a\s+(?:id|name)=[\"']([^\"']+)[\"']", re.IGNORECASE)


def github_slug(heading: str) -> str:
    """Approximate GitHub's heading anchor algorithm."""
    text = heading.strip()
    text = re.sub(r"`", "", text)
    text = re.sub(r"\[([^\]]*)\]\([^)]*\)", r"\1", text)
    text = re.sub(r"[*_~]", "", text)
    text = text.lower()
    text = re.sub(r"[^\w\s-]", "", text, flags=re.UNICODE)
    text = re.sub(r"\s+", "-", text)
    return text


def collect_anchors(path: Path) -> set[str]:
    anchors: set[str] = set()
    text = read_text(path)
    for line in text.splitlines():
        heading = HEADING_PATTERN.match(line)
        if heading:
            slug = github_slug(heading.group(2))
            if slug:
                anchors.add(slug)
        for explicit in HTML_ANCHOR_PATTERN.findall(line):
            anchors.add(explicit)
    return anchors


def check_links(report, root: Path) -> None:
    for path in iter_files(root, {".md"}):
        text = read_text(path)
        for line_no, line in enumerate(text.splitlines(), start=1):
            for match in LINK_PATTERN.finditer(line):
                raw = match.group(1)
                if raw.startswith(("http://", "https://", "mailto:", "tel:")):
                    continue
                target, _, fragment = raw.partition("#")
                target = target.split("?", 1)[0]
                fragment = fragment.split("?", 1)[0]
                if not target and not fragment:
                    continue
                if "<" in target or ">" in target or target.startswith("{"):
                    continue
                if raw.startswith("#"):
                    candidate = path
                elif target.startswith("/"):
                    candidate = root / target.lstrip("/")
                else:
                    candidate = (path.parent / target).resolve()
                if not candidate.exists():
                    report.fail(
                        f"{rel(root, path)}:{line_no}: relative link target missing: {raw}"
                    )
                    continue
                if fragment and candidate.suffix.lower() == ".md":
                    anchors = collect_anchors(candidate)
                    if fragment not in anchors:
                        report.fail(
                            f"{rel(root, path)}:{line_no}: internal anchor missing in "
                            f"{rel(root, candidate)}: {fragment}"
                        )
