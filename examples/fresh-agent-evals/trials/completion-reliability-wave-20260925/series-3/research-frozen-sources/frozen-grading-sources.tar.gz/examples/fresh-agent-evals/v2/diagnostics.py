"""Shared, redacted, actionable diagnostics for current fresh-agent verdicts."""

from __future__ import annotations

import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[1] / "opencode-lifecycle"))

from bridge_core import redact_secret_shapes  # noqa: E402

CATEGORIES = {
    "native_permission_denial",
    "unsupported_evidence_format",
    "artifact_schema_error",
    "protocol_violation",
    "research_comparison_outcome",
    "runtime_unavailability",
}
ACTION_ID_RE = re.compile(r"[0-9a-f]{64}\Z")
ABSOLUTE_PATH_RE = re.compile(r"(?<![A-Za-z0-9])/(?:[A-Za-z0-9._-]+/)*[A-Za-z0-9._-]+")
WINDOWS_PATH_RE = re.compile(r"(?i)(?<![A-Za-z0-9])[A-Z]:\\(?:[^\\\s\"']+\\?)+")
KNOWN_ARTIFACTS = {
    "trial-output/completion.json",
    "trial-output/challenger.py",
    "trial-output/comparison-report.json",
    "trial-output/research-result.json",
    "examples/fresh-agent-evals/research/source-provenance.json",
}

NEXT_STEPS = {
    "native_permission_denial": (
        "Continue with public inputs the native tool already permits; record the denied input as unavailable and proceed offline. "
        "Do not retry by changing permissions or switching to another access route."
    ),
    "unsupported_evidence_format": (
        "Use one bounded documented native action with complete arguments, identity, and explicit completion; if those fields are unavailable, leave the evidence unknown."
    ),
    "artifact_schema_error": (
        "Correct the named workspace-relative artifact to the disclosed schema, then rerun its documented local check and retain the exact result."
    ),
    "protocol_violation": (
        "Repeat the relevant step in a fresh isolated workspace using the documented entry route and preserve the required native action order."
    ),
    "research_comparison_outcome": (
        "Retain the observed synthetic result without a superiority claim. If justified, define a new bounded development-only comparison before drawing broader conclusions; keep live and out-of-sample claims unknown."
    ),
    "runtime_unavailability": (
        "Record the runtime as unavailable and continue with offline checks; a later parent may select an available explicitly configured native runtime."
    ),
}


def sanitize_text(value: object, *, repo: Path | None = None, workspace: Path | None = None) -> str:
    """Redact credentials and absolute host paths before publishing diagnostics."""
    text = redact_secret_shapes(str(value))
    for path, label in ((workspace, "<WORKSPACE>"), (repo, "<REPO>"), (Path.home(), "<HOME>")):
        if path is not None:
            try:
                text = text.replace(str(path.resolve()), label)
            except OSError:
                continue
    text = WINDOWS_PATH_RE.sub("<PRIVATE_PATH>", text)
    text = ABSOLUTE_PATH_RE.sub("<PRIVATE_PATH>", text)
    return text[:800]


def native_action_reference(action: dict, harness: str) -> dict:
    identity_key = "native_tool_call_id_sha256" if harness == "opencode" else "native_item_id_sha256"
    identity = action.get(identity_key)
    return {
        "event_sequence": action.get("event_sequence") if type(action.get("event_sequence")) is int else None,
        "completion_sequence": action.get("completion_sequence") if type(action.get("completion_sequence")) is int else None,
        "identity_kind": identity_key,
        "identity_sha256": identity if isinstance(identity, str) and ACTION_ID_RE.fullmatch(identity) else None,
        "tool": action.get("tool") if isinstance(action.get("tool"), str) else None,
    }


def _native_status(action: dict, harness: str) -> str | None:
    if harness == "opencode":
        outcome = action.get("outcome")
        return outcome.get("native_tool_status") if isinstance(outcome, dict) else None
    value = action.get("native_status")
    return value if isinstance(value, str) else None


def _classify_failure(reason: str) -> tuple[str, str]:
    lower = reason.casefold()
    if any(word in lower for word in ("runtime unavailable", "harness could not start", "installed native runtime", "runtime executable")):
        return "runtime.unavailable", "runtime_unavailability"
    if any(word in lower for word in (
        "schema", "artifact", "completion.json", "comparison report", "research result",
        "deliverable", "invalid json", "source provenance", "hash claim", "report is stale",
    )):
        return "artifact.schema_or_content_invalid", "artifact_schema_error"
    if any(word in lower for word in (
        "truncated", "unsupported evidence", "bounded shell", "normalized action",
        "trace is incomplete", "trace is unavailable", "evidence is unknown",
        "missing native", "native session", "digest is incomplete", "argument",
    )):
        return "native.evidence_unsupported", "unsupported_evidence_format"
    return "protocol.requirement_unmet", "protocol_violation"


def _artifact_path(reason: str, scope: str) -> str | None:
    for path in sorted(KNOWN_ARTIFACTS):
        if path in reason:
            return path
    lower = reason.casefold()
    if scope == "research":
        if "comparison report" in lower or "development report" in lower:
            return "trial-output/comparison-report.json"
        if "callback" in lower or "implementation" in lower:
            return "trial-output/challenger.py"
        if "source provenance" in lower or "source excerpt" in lower:
            return "examples/fresh-agent-evals/research/source-provenance.json"
        if "research artifact" in lower or "machine claim" in lower or "schema" in lower:
            return "trial-output/research-result.json"
    else:
        if any(word in lower for word in ("completion", "schema", "structured route fact", "authoritative_sources")):
            return "trial-output/completion.json"
    return None


def _artifact_hint(reason: str, scope: str, artifact_paths: tuple[str, ...]) -> str | None:
    for path in artifact_paths:
        if path in reason:
            return path
    lower = reason.casefold()
    if scope == "research":
        if "comparison" in lower or "report" in lower:
            return "trial-output/comparison-report.json" if "trial-output/comparison-report.json" in artifact_paths else _artifact_path(reason, scope)
        if "callback" in lower or "implementation" in lower:
            return "trial-output/challenger.py" if "trial-output/challenger.py" in artifact_paths else _artifact_path(reason, scope)
        if "source" in lower:
            return "examples/fresh-agent-evals/research/source-provenance.json" if "examples/fresh-agent-evals/research/source-provenance.json" in artifact_paths else _artifact_path(reason, scope)
        if "artifact" in lower or "schema" in lower:
            return "trial-output/research-result.json" if "trial-output/research-result.json" in artifact_paths else _artifact_path(reason, scope)
    elif "completion" in lower or "schema" in lower or "authoritative_sources" in lower:
        return "trial-output/completion.json" if "trial-output/completion.json" in artifact_paths else _artifact_path(reason, scope)
    if scope == "docs" and "documentation" in lower:
        candidates = [path for path in artifact_paths if path != "trial-output/completion.json"]
        return candidates[0] if len(candidates) == 1 else None
    return _artifact_path(reason, scope)


def _missing_evidence(category: str, reason: str) -> list[str]:
    lower = reason.casefold()
    if category == "native_permission_denial":
        return ["successful completion of the denied native operation"]
    if category == "runtime_unavailability":
        return ["evidence that the selected validator interpreter/process actually ran"]
    if category == "unsupported_evidence_format":
        return ["complete bounded arguments, native identity, and explicit terminal result"]
    if category == "artifact_schema_error":
        return ["a workspace-relative artifact matching the disclosed typed contract"]
    if "entrypoint" in lower or "route" in lower:
        return ["ordered native reads of root entries, task selector/readable packet, and task-specific route"]
    if "validation" in lower:
        return ["an exact native command/result identity in the required causal phase"]
    return ["the exact permitted action and event order required by the trial contract"]


def _established_action_reference(action: object, harness: str) -> dict | None:
    if not isinstance(action, dict) or harness not in {"opencode", "codex"}:
        return None
    reference = native_action_reference(action, harness)
    start = reference.get("event_sequence")
    completed = reference.get("completion_sequence")
    if (
        type(start) is not int
        or start < 0
        or type(completed) is not int
        or completed < start
        or not isinstance(reference.get("identity_sha256"), str)
        or not isinstance(reference.get("tool"), str)
    ):
        return None
    return reference


def _unique_causal_reference(value: object, harness: str) -> dict | None:
    candidates = value if isinstance(value, list) else [value]
    references = []
    for action in candidates:
        reference = _established_action_reference(action, harness)
        if reference is not None:
            references.append(reference)
    unique = {
        (
            item["event_sequence"], item["completion_sequence"],
            item["identity_kind"], item["identity_sha256"], item["tool"],
        ): item
        for item in references
    }
    return next(iter(unique.values())) if len(unique) == 1 else None


def _diagnostic(
    *,
    code: str,
    category: str,
    summary: str,
    observed: list[str],
    missing: list[str],
    next_step: str,
    native_action: dict | None = None,
    artifact_path: str | None = None,
    severity: str = "error",
    actionable: bool = True,
    repo: Path | None = None,
    workspace: Path | None = None,
) -> dict:
    return {
        "code": code,
        "category": category,
        "severity": severity,
        "actionable": actionable,
        "summary": sanitize_text(summary, repo=repo, workspace=workspace),
        "native_action": native_action,
        "artifact_path": artifact_path,
        "observed_evidence": [sanitize_text(item, repo=repo, workspace=workspace) for item in observed[:8]],
        "missing_evidence": [sanitize_text(item, repo=repo, workspace=workspace) for item in missing[:8]],
        "next_step": sanitize_text(next_step, repo=repo, workspace=workspace),
    }


def build_failure_diagnostics(
    failure_reasons: list[str],
    actions: list,
    harness: str,
    *,
    scope: str,
    artifact_paths: tuple[str, ...] = (),
    causal_actions: dict[str, object] | None = None,
    repo: Path | None = None,
    workspace: Path | None = None,
) -> list[dict]:
    """Map current grader failures to shared stable categories and safe steps."""
    result: list[dict] = []
    seen: set[tuple] = set()
    for reason in failure_reasons:
        reason_text = str(reason)
        code, category = _classify_failure(reason_text)
        cause = causal_actions.get(reason_text) if isinstance(causal_actions, dict) else None
        if isinstance(cause, dict) and _native_status(cause, harness) == "denied":
            code, category = "native.permission_denied", "native_permission_denial"
        action_ref = _unique_causal_reference(cause, harness)
        path = _artifact_hint(str(reason), scope, artifact_paths)
        summary = sanitize_text(reason_text, repo=repo, workspace=workspace)
        key = (code, summary, action_ref.get("identity_sha256") if action_ref else None, path)
        if key in seen:
            continue
        seen.add(key)
        missing = _missing_evidence(category, reason_text)
        if action_ref is None:
            missing.append("a uniquely identified causal native action with sequence and hashed identity")
        result.append(_diagnostic(
            code=code,
            category=category,
            summary=summary,
            observed=[summary],
            missing=missing,
            next_step=NEXT_STEPS[category],
            native_action=action_ref,
            artifact_path=path,
            repo=repo,
            workspace=workspace,
        ))

    if harness in {"opencode", "codex"}:
        for action in actions:
            if not isinstance(action, dict) or _native_status(action, harness) != "denied":
                continue
            reference = _established_action_reference(action, harness)
            if not any(
                item.get("category") == "native_permission_denial"
                and isinstance(item.get("native_action"), dict)
                and reference is not None
                and item["native_action"].get("identity_sha256") == reference.get("identity_sha256")
                for item in result
            ):
                missing = ["successful completion of the denied native operation"]
                if reference is None:
                    missing.append("a uniquely identified causal native action with sequence and hashed identity")
                result.append(_diagnostic(
                    code="native.permission_denied",
                    category="native_permission_denial",
                    summary="A native action was explicitly denied by the selected runtime.",
                    observed=[
                        f"native status=denied at event sequence {action.get('event_sequence')}",
                    ],
                    missing=missing,
                    next_step=NEXT_STEPS["native_permission_denial"],
                    native_action=reference,
                    severity="warning",
                    repo=repo,
                    workspace=workspace,
                ))
    return result


def runtime_unavailable_diagnostic(
    reason: str,
    *,
    native_action: dict | None = None,
    repo: Path | None = None,
) -> dict:
    summary = sanitize_text(reason, repo=repo)
    action_ref = _established_action_reference(native_action, "opencode") or _established_action_reference(
        native_action, "codex",
    )
    missing = ["an available runtime matching the explicitly selected adapter and version"]
    if action_ref is None:
        missing.append("a uniquely identified causal native action with sequence and hashed identity")
    return _diagnostic(
        code="runtime.unavailable",
        category="runtime_unavailability",
        summary=summary,
        observed=[summary],
        missing=missing,
        next_step=NEXT_STEPS["runtime_unavailability"],
        native_action=action_ref,
        severity="warning",
        repo=repo,
    )


def research_comparison_diagnostic(report: dict, *, repo: Path | None = None) -> dict | None:
    """Describe a synthetic comparison outcome without turning it into failure."""
    if not isinstance(report, dict) or report.get("comparison_status") not in {
        "complete_equal_calls", "incomplete_comparison",
    }:
        return None
    development = [item for item in report.get("runs", []) if isinstance(item, dict) and item.get("role") == "development"]
    paired = []
    for item in development[:8]:
        comparison = item.get("paired_comparison")
        if isinstance(comparison, dict):
            paired.append(
                f"development pair {item.get('input_id')}: "
                f"completed-call status={comparison.get('comparison_status')}; "
                f"synthetic unique-cell difference={comparison.get('unique_valid_cell_difference')}; "
                f"synthetic quality-pass difference={comparison.get('synthetic_quality_pass_difference')}"
            )
    status = report["comparison_status"]
    summary = f"Observed synthetic development comparison status: {status}."
    return _diagnostic(
        code="research.comparison_outcome",
        category="research_comparison_outcome",
        summary=summary,
        observed=[summary, *paired],
        missing=["live performance and out-of-sample return-correlation evidence remain unobserved"],
        next_step=NEXT_STEPS["research_comparison_outcome"],
        artifact_path="trial-output/comparison-report.json",
        severity="info",
        repo=repo,
    )


def compose_research_diagnostics(
    failure_reasons: list[str],
    actions: list,
    harness: str,
    report: dict | None,
    *,
    artifact_paths: tuple[str, ...] = (),
    causal_actions: dict[str, object] | None = None,
    repo: Path | None = None,
    workspace: Path | None = None,
) -> list[dict]:
    result = build_failure_diagnostics(
        failure_reasons, actions, harness,
        scope="research", artifact_paths=artifact_paths, causal_actions=causal_actions,
        repo=repo, workspace=workspace,
    )
    comparison = research_comparison_diagnostic(report, repo=repo)
    if comparison is not None:
        result.append(comparison)
    return result
