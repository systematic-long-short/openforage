"""Build complete instruction-visible source snapshots with one seeded defect."""

from __future__ import annotations

import hashlib
import os
import shutil
import sys
from pathlib import Path

sys.dont_write_bytecode = True
REPO_ROOT = Path(__file__).resolve().parents[3]
if str(REPO_ROOT / "scripts") not in sys.path:
    sys.path.insert(0, str(REPO_ROOT / "scripts"))

from onboarding.completion import SCRATCH_REL  # noqa: E402

from manifest import EXCLUDED_DIRS, EXCLUDED_FILES, ROOT_LOCAL_DIRS, source_tree_sha256
from paths import PathSafetyError, ensure_clean_ancestors, make_exclusive_directory, safe_relative
from processes import run_bounded
from schema import read_json


class SnapshotError(RuntimeError):
    """A fixture could not be prepared as a bounded, isolated source checkout."""


def file_map(root: Path, *, exclude_paths: tuple[str, ...] = ()) -> dict[str, str]:
    result = {}
    excluded = {SCRATCH_REL, *exclude_paths}
    for path in sorted(root.rglob("*")):
        relative_parts = path.relative_to(root).parts
        if path.is_symlink():
            raise SnapshotError("workspace file inventory contains a symlink")
        if ".git" in relative_parts or not path.is_file():
            continue
        relative = path.relative_to(root).as_posix()
        if relative in excluded:
            continue
        result[relative] = hashlib.sha256(path.read_bytes()).hexdigest()
    return result


def digest_map(files: dict[str, str]) -> str:
    digest = hashlib.sha256()
    for relative, value in sorted(files.items()):
        digest.update(relative.encode("utf-8"))
        digest.update(b"\0")
        digest.update(bytes.fromhex(value))
    return digest.hexdigest()


def copy_public_tree(source: Path, target: Path) -> None:
    for current, directories, filenames in os.walk(source, followlinks=False):
        current_path = Path(current)
        relative_dir = current_path.relative_to(source)
        directories[:] = [
            name for name in directories
            if name not in EXCLUDED_DIRS
            and not (relative_dir == Path(".") and name == "trial-output")
            and not (relative_dir == Path(".") and name in ROOT_LOCAL_DIRS)
        ]
        for name in directories:
            if (current_path / name).is_symlink():
                raise SnapshotError("source tree contains a symlink directory")
        destination_dir = target / relative_dir
        destination_dir.mkdir(parents=True, exist_ok=True)
        for name in filenames:
            original = current_path / name
            if original.is_symlink():
                raise SnapshotError("source tree contains a symlink file")
            if name in EXCLUDED_FILES or Path(name).suffix.casefold() in {".pem", ".p12", ".jks"}:
                continue
            shutil.copy2(original, destination_dir / name)


def _local_git_root(workspace: Path, runner_python_env: dict) -> bool:
    git = shutil.which("git")
    if not git:
        raise SnapshotError("git is required to isolate the nearest repository root")
    env = dict(runner_python_env)
    env.update({"GIT_CONFIG_GLOBAL": os.devnull, "GIT_CONFIG_SYSTEM": os.devnull, "GIT_CONFIG_NOSYSTEM": "1"})
    init = run_bounded([git, "-C", str(workspace), "init", "-q"], cwd=workspace, env=env, timeout=30)
    if init.returncode != 0 or init.timed_out or init.process_group_remaining:
        raise SnapshotError("local git init failed in the isolated workspace")
    probe = run_bounded([git, "-C", str(workspace), "rev-parse", "--show-toplevel"], cwd=workspace, env=env, timeout=15)
    if probe.returncode != 0 or probe.timed_out or probe.process_group_remaining:
        return False
    return Path(probe.stdout.decode("utf-8", "replace").strip()).resolve() == workspace.resolve()


def prepare_snapshot(repo: Path, case_id: str, workspace: Path, child_env: dict) -> dict:
    repo = repo.resolve()
    workspace = Path(os.path.abspath(workspace))
    if workspace == repo or workspace.is_relative_to(repo):
        raise PathSafetyError("workspace must be outside the public source checkout")
    make_exclusive_directory(workspace, workspace.parent)
    ensure_clean_ancestors(workspace)
    try:
        copy_public_tree(repo, workspace)
    except OSError as exc:
        raise SnapshotError("public source snapshot copy failed") from exc
    required = ("README.md", "AGENTS.md", "CLAUDE.md")
    if any(not (workspace / name).is_file() for name in required):
        raise SnapshotError("the root repository route files must remain visible in the workspace")
    if any((workspace / name).is_symlink() for name in required):
        raise SnapshotError("root repository route files may not be symlinks")

    oracle = read_json(repo / "examples/fresh-agent-evals/v2/oracle.json")
    entry = oracle.get("cases", {}).get(case_id)
    if not isinstance(entry, dict):
        raise SnapshotError("selected case has no frozen fixture definition")
    fixture = entry.get("fixture", {})
    relative = safe_relative(fixture.get("path", ""))
    target = workspace / relative
    if not target.is_file() or target.is_symlink():
        raise SnapshotError("fixture target is missing or unsafe")
    original = target.read_bytes()
    original_hash = hashlib.sha256(original).hexdigest()
    text = original.decode("utf-8")
    needle = fixture.get("find")
    replacement = fixture.get("replace")
    if not isinstance(needle, str) or not isinstance(replacement, str) or text.count(needle) != 1:
        raise SnapshotError("fixture must match exactly one source fragment")
    target.write_text(text.replace(needle, replacement, 1), encoding="utf-8")
    (workspace / "trial-output").mkdir()
    if not _local_git_root(workspace, child_env):
        raise SnapshotError("nearest Git root is not the prepared workspace")
    files = file_map(workspace)
    return {
        "case_id": case_id,
        "fixture_path": relative.as_posix(),
        "clean_fixture_source_sha256": original_hash,
        "seeded_fixture_sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
        "source_tree_sha256": source_tree_sha256(repo),
        "snapshot_sha256": digest_map(files),
        "snapshot_file_count": len(files),
        "workspace_git_root_verified": True,
        "root_route_files_visible": list(required),
        "ancestor_instructions_outside_workspace": False,
        "public_suite_is_instruction_isolated": True,
        "initial_files": files,
    }
