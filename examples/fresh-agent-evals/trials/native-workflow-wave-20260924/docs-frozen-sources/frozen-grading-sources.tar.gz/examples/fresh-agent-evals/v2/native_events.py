"""Allowlisted OpenCode/Codex event normalization for v2 trial evidence."""

from __future__ import annotations

import hashlib
import json
import re
import sys
import datetime as dt
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE.parents[1] / "opencode-lifecycle"))

from bridge_core import redact_secret_shapes  # noqa: E402
from native_arguments import (  # noqa: E402
    ARGUMENT_SCHEMA_VERSION,
    NATIVE_ARGUMENT_TOOLS,
    normalize_native_arguments,
)
from tool_outcomes import normalize_tool_actions  # noqa: E402
from commands import normalize_command  # noqa: E402
from shell_parser import MAX_COMMAND_BYTES  # noqa: E402

NORMALIZED_COMMAND_LIMIT = 2048
COMMAND_PREVIEW_LIMIT = 300
ABSOLUTE_PATH_RE = re.compile(r"(?<![A-Za-z0-9:/<>])/(?:[A-Za-z0-9._-]+/)*[A-Za-z0-9._-]+")
WINDOWS_ABSOLUTE_PATH_RE = re.compile(r"(?i)(?<![A-Za-z0-9])[A-Z]:\\(?:[^\\\s\"']+\\?)+")
ALLOWED_WRAPPER_PATH_RE = re.compile(r"(?<![A-Za-z0-9])/(?:bin|usr/bin)/(?:bash|sh)(?=\s+-lc(?:\s|$))")
PATCH_FILE_HEADER = re.compile(r"(?m)^\*\*\* (?:Add|Update|Delete) File: ([^\r\n]+)$")
STATUS_VALUES = {"completed", "failed", "error", "denied", "cancelled", "timeout", "running", "pending", "unknown"}
CODEX_TODO_LIST_LIFECYCLE = {"item.started", "item.updated", "item.completed"}
SECRET_SHAPE_RE = re.compile(r"(?i)(?:sk-[A-Za-z0-9_-]{20,}|ghp_[A-Za-z0-9]{36}|AKIA[0-9A-Z]{16})")
OPENCODE_TERMINAL_STATUSES = {
    "completed", "error", "failed", "denied", "permission_denied", "rejected",
    "blocked", "cancelled", "canceled", "timeout", "timed_out", "skipped",
}


def _event_epoch(event: dict) -> float | None:
    raw = next((event[key] for key in ("timestamp", "time", "created", "at", "ts") if key in event), None)
    if isinstance(raw, bool) or raw is None:
        return None
    if isinstance(raw, (int, float)):
        value = float(raw)
        if value > 1e15:
            return value / 1e6
        if value > 1e12:
            return value / 1e3
        return value
    if isinstance(raw, str):
        try:
            return dt.datetime.fromisoformat(raw.strip().replace("Z", "+00:00")).timestamp()
        except ValueError:
            try:
                return float(raw)
            except ValueError:
                return None
    return None


def parse_jsonl(raw: bytes) -> tuple[list[dict], bool, int]:
    """Parse native JSONL while exposing whether any nonempty line was lost."""
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        text = raw.decode("utf-8", "replace")
        decode_complete = False
    else:
        decode_complete = True
    events: list[dict] = []
    invalid = 0
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        try:
            payload = json.loads(stripped)
        except ValueError:
            invalid += 1
            continue
        if isinstance(payload, dict):
            events.append(payload)
        elif isinstance(payload, list):
            events.extend(item for item in payload if isinstance(item, dict))
        else:
            invalid += 1
    return events, decode_complete and invalid == 0, invalid


def _safe_text(value: str, workspace: Path, repo: Path) -> str:
    text = redact_secret_shapes(value)
    text = SECRET_SHAPE_RE.sub("<REDACTED>", text)
    for original, replacement in (
        (str(workspace.resolve()), "<WORKSPACE>"),
        (str(repo.resolve()), "<REPO>"),
        (str(Path.home().resolve()), "<HOME>"),
    ):
        text = text.replace(original, replacement)
    return text


def _session_id(events: list[dict], harness: str) -> str | None:
    keys = {"codex": ("thread_id", "threadID"), "opencode": ("sessionID", "session_id", "sessionId")}[harness]
    for event in events:
        candidates = [event]
        if isinstance(event.get("item"), dict):
            candidates.append(event["item"])
        for value in candidates:
            for key in keys:
                if isinstance(value.get(key), str) and value[key]:
                    return value[key]
    return None


def _opencode_input_groups(events: list[dict]) -> dict[str, dict]:
    """Index native tool inputs by call identity without copying them to output."""
    groups: dict[str, dict] = {}
    for sequence, event in enumerate(events):
        part = event.get("part") if isinstance(event, dict) else None
        if not isinstance(part, dict) or part.get("type") != "tool":
            continue
        raw_tool = part.get("tool")
        if not isinstance(raw_tool, str):
            continue
        raw_id = part.get("callID")
        key = (
            hashlib.sha256(raw_id.encode("utf-8")).hexdigest()
            if isinstance(raw_id, str) and raw_id
            else f"event:{sequence}"
        )
        group = groups.setdefault(key, {"tools": set(), "inputs": [], "invalid_input": False})
        group["tools"].add(raw_tool.casefold())
        state = part.get("state") if isinstance(part.get("state"), dict) else {}
        if "input" not in state:
            continue
        value = state.get("input")
        if not isinstance(value, dict):
            group["invalid_input"] = True
        else:
            group["inputs"].append((sequence, value))
    return groups


def _same_input_values(inputs: list[tuple[int, dict]]) -> bool:
    if not inputs:
        return False
    try:
        canonical = json.dumps(inputs[0][1], sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        return all(
            json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False) == canonical
            for _sequence, value in inputs[1:]
        )
    except (TypeError, ValueError, UnicodeEncodeError, RecursionError):
        return False


def _opencode_shell_text(raw_input: dict) -> tuple[str | None, str | None]:
    values = [raw_input[key] for key in ("command", "cmd") if key in raw_input]
    if not values:
        return None, "missing_command"
    if any(not isinstance(value, str) for value in values) or len(set(values)) != 1:
        return None, "conflicting_command_aliases"
    return values[0], None


def _replace_command_evidence(action: dict, raw_command: str | None, workspace: Path, repo: Path) -> None:
    if (
        raw_command is None
        or action.get("correlation_conflict") is True
        or action.get("native_tool_call_id_sha256") is None
    ):
        action.update({
            "command": None,
            "command_preview": None,
            "command_sha256": None,
            "command_bytes": None,
            "command_truncated": None,
        })
        return
    safe = _safe_text(raw_command, workspace, repo)
    try:
        encoded = safe.encode("utf-8")
    except UnicodeEncodeError:
        safe = ""
        encoded = b""
    if not safe:
        action.update({
            "command": None,
            "command_preview": None,
            "command_sha256": None,
            "command_bytes": None,
            "command_truncated": None,
        })
        return
    masked = ALLOWED_WRAPPER_PATH_RE.sub("", safe)
    if ABSOLUTE_PATH_RE.search(masked) or WINDOWS_ABSOLUTE_PATH_RE.search(safe):
        action.update({
            "command": None,
            "command_preview": None,
            "command_sha256": hashlib.sha256(encoded).hexdigest(),
            "command_bytes": len(encoded),
            "command_truncated": True,
            "command_redaction_status": "private_path",
        })
        return
    action["command_preview"] = safe[:COMMAND_PREVIEW_LIMIT]
    action["command"] = safe if len(encoded) <= MAX_COMMAND_BYTES else None
    action["command_sha256"] = hashlib.sha256(encoded).hexdigest()
    action["command_bytes"] = len(encoded)
    action["command_truncated"] = len(encoded) > MAX_COMMAND_BYTES
    action["command_redaction_status"] = "none"


def _file_action_path(tool: str, raw_input: dict | None) -> str | None:
    if not isinstance(raw_input, dict):
        return None
    if tool in {"edit", "write"}:
        candidates = [raw_input[key] for key in ("filePath", "file_path", "path") if key in raw_input]
        return candidates[0] if candidates and all(value == candidates[0] for value in candidates) and isinstance(candidates[0], str) else None
    if tool == "apply_patch":
        patch = raw_input.get("patchText")
        if not isinstance(patch, str):
            return None
        paths = PATCH_FILE_HEADER.findall(patch)
        return paths[0] if len(paths) == 1 else None
    return None


def _enrich_opencode_actions(actions: list[dict], events: list[dict], workspace: Path, repo: Path) -> None:
    groups = _opencode_input_groups(events)
    for action in actions:
        tool = action.get("tool")
        identity = action.get("native_tool_call_id_sha256")
        event_sequence = action.get("event_sequence")
        group_key = identity if isinstance(identity, str) else f"event:{event_sequence}"
        group = groups.get(group_key, {"tools": set(), "inputs": [], "invalid_input": False})
        inputs = group["inputs"]
        raw_input = inputs[0][1] if inputs and _same_input_values(inputs) else None
        input_sequence = inputs[0][0] if inputs and raw_input is not None else None
        native_status = action.get("outcome", {}).get("native_tool_status") if isinstance(action.get("outcome"), dict) else None

        if tool in {"bash", "shell"}:
            if group.get("tools") != {tool} or group.get("invalid_input") or raw_input is None:
                _replace_command_evidence(action, None, workspace, repo)
                continue
            command, problem = _opencode_shell_text(raw_input)
            _replace_command_evidence(action, command if problem is None else None, workspace, repo)
            continue

        if tool not in NATIVE_ARGUMENT_TOOLS:
            if tool in {"edit", "write", "apply_patch"}:
                if group.get("tools") != {tool} or group.get("invalid_input") or raw_input is None or action.get("correlation_conflict") is True:
                    _replace_command_evidence(action, None, workspace, repo)
                else:
                    _replace_command_evidence(action, _file_action_path(tool, raw_input), workspace, repo)
                continue
            preview = action.get("command")
            action["command_preview"] = preview if isinstance(preview, str) else None
            continue

        action.update({
            "native_arguments_schema_version": ARGUMENT_SCHEMA_VERSION,
            "native_arguments_status": "unknown",
            "native_arguments_problem": "missing_or_unsupported_arguments",
            "native_arguments": None,
            "native_arguments_sha256": None,
            "native_arguments_bytes": None,
            "native_arguments_event_sequence": input_sequence,
            "native_arguments_identity_sha256": identity,
            "native_arguments_completion_status": native_status,
        })
        if group.get("tools") != {tool}:
            action["native_arguments_problem"] = "conflicting_tool_identity"
            _replace_command_evidence(action, None, workspace, repo)
            continue
        if group.get("invalid_input") or raw_input is None:
            action["native_arguments_problem"] = "malformed_or_missing_input"
            _replace_command_evidence(action, None, workspace, repo)
            continue
        if not isinstance(identity, str) or action.get("correlation_conflict") is True:
            action["native_arguments_problem"] = "missing_or_conflicting_native_identity"
            _replace_command_evidence(action, None, workspace, repo)
            continue
        arguments, problem = normalize_native_arguments(tool, raw_input, workspace)
        if problem is not None or arguments is None:
            action["native_arguments_problem"] = problem or "malformed_arguments"
            _replace_command_evidence(action, None, workspace, repo)
            continue
        encoded = json.dumps(
            arguments, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
        ).encode("utf-8")
        action.update({
            "native_arguments_status": "observed",
            "native_arguments_problem": None,
            "native_arguments": arguments,
            "native_arguments_sha256": hashlib.sha256(encoded).hexdigest(),
            "native_arguments_bytes": len(encoded),
            "native_arguments_event_sequence": input_sequence,
            "native_arguments_identity_sha256": identity,
        })
        _replace_command_evidence(action, arguments["path"], workspace, repo)


def normalize_opencode(raw: bytes, workspace: Path, repo: Path) -> dict:
    events, complete, invalid = parse_jsonl(raw)
    replacements = (
        (str(workspace.resolve()), "<WORKSPACE>"),
        (str(repo.resolve()), "<REPO>"),
        (str(Path.home().resolve()), "<HOME>"),
    )
    actions = normalize_tool_actions(
        events,
        replacements=replacements,
        redact=redact_secret_shapes,
    )
    _enrich_opencode_actions(actions, events, workspace, repo)
    questions = [action for action in actions if action.get("tool") == "question"]
    question_ids = [action.get("native_tool_call_id_sha256") for action in questions]
    clarification_count = (
        len(set(question_ids))
        if all(isinstance(value, str) for value in question_ids)
        and all(action.get("correlation_conflict") is not True for action in questions)
        else None
    )
    incomplete_tools = {"other", "task", "webfetch", "websearch", "python", "lsp", "skill"}
    unclassified_tools = sum(1 for action in actions if action.get("tool") in incomplete_tools)
    terminal_event_by_call: dict[str, int] = {}
    terminal_event_by_sequence: dict[int, int] = {}
    for sequence, event in enumerate(events):
        part = event.get("part") if isinstance(event, dict) else None
        if not isinstance(part, dict):
            continue
        state = part.get("state") if isinstance(part.get("state"), dict) else {}
        status = state.get("status")
        if not isinstance(status, str) or status.casefold() not in OPENCODE_TERMINAL_STATUSES:
            continue
        call_id = part.get("callID")
        if isinstance(call_id, str) and call_id:
            terminal_event_by_call[hashlib.sha256(call_id.encode("utf-8")).hexdigest()] = sequence
        else:
            terminal_event_by_sequence[sequence] = sequence
    for action in actions:
        sequence = action.get("event_sequence")
        call_hash = action.get("native_tool_call_id_sha256")
        action["completion_sequence"] = (
            terminal_event_by_call.get(call_hash)
            if isinstance(call_hash, str)
            else terminal_event_by_sequence.get(sequence)
        )
        if action.get("native_arguments_schema_version") == ARGUMENT_SCHEMA_VERSION:
            action["native_arguments_completion_sequence"] = action["completion_sequence"]
        if type(sequence) is int and sequence < len(events):
            action["event_timestamp_epoch"] = _event_epoch(events[sequence])
    return {
        "actions": actions,
        "events_observed": len(events),
        "invalid_lines": invalid,
        "unclassified_tool_count": unclassified_tools,
        "trace_complete": complete and bool(events) and unclassified_tools == 0,
        "clarification_observations": clarification_count,
        "session_id_sha256": hashlib.sha256(_session_id(events, "opencode").encode()).hexdigest()
        if _session_id(events, "opencode") else None,
    }


def _native_status(item: dict) -> str:
    value = item.get("status")
    if not isinstance(value, str):
        return "missing"
    normalized = value.casefold()
    return normalized if normalized in STATUS_VALUES else "unknown"


def _codex_id(item: dict) -> tuple[str | None, str | None]:
    value = item.get("id")
    if not isinstance(value, str) or not value:
        return None, None
    digest = hashlib.sha256(value.encode("utf-8")).hexdigest()
    safe = value if len(value) <= 160 and re.fullmatch(r"[A-Za-z0-9._:-]+", value) else None
    return safe, digest


def _valid_codex_todo_list(item: dict, event_type: str) -> bool:
    if event_type not in CODEX_TODO_LIST_LIFECYCLE or _codex_id(item)[1] is None:
        return False
    items = item.get("items")
    return isinstance(items, list) and all(
        isinstance(todo, dict)
        and isinstance(todo.get("text"), str)
        and type(todo.get("completed")) is bool
        for todo in items
    )


def _explicit_exit(item: dict) -> tuple[str, int | None]:
    if "exit_code" not in item:
        return "missing", None
    value = item.get("exit_code")
    if type(value) is not int:
        return "unknown", None
    return "observed", value


def _codex_file_changes(item: dict, event_type: str, sequence: int, workspace: Path) -> list[dict]:
    item_id, item_id_hash = _codex_id(item)
    status = _native_status(item)
    changes = item.get("changes")
    if not isinstance(changes, list) or not changes:
        return [{
            "tool": "file_change", "native_item_id": item_id,
            "native_item_id_sha256": item_id_hash, "event_sequence": sequence,
            "completion_sequence": sequence if event_type in {"item.completed", "item.failed"} else None,
            "change_index": None,
            "event_timestamp_epoch": None,
            "lifecycle_event": event_type, "native_status": status,
            "lifecycle_events": [event_type],
            "exit_code_status": "not_applicable", "exit_code": None,
            "path": None, "path_status": "missing", "change_kind": "unknown",
        }]
    actions = []
    for index, change in enumerate(changes):
        if not isinstance(change, dict):
            actions.append({
                "tool": "file_change", "native_item_id": item_id,
                "native_item_id_sha256": item_id_hash, "event_sequence": sequence,
                "completion_sequence": sequence if event_type in {"item.completed", "item.failed"} else None,
                "change_index": index, "lifecycle_event": event_type,
                "lifecycle_events": [event_type], "native_status": status,
                "path": None, "event_timestamp_epoch": None,
                "exit_code_status": "not_applicable", "exit_code": None,
                "path_status": "missing", "change_kind": "unknown",
            })
            continue
        raw_path = change.get("path")
        path = None
        path_status = "missing"
        if isinstance(raw_path, str):
            candidate = Path(raw_path)
            if "\\" in raw_path or ".." in candidate.parts:
                path_status = "outside_workspace"
            else:
                resolved = candidate.resolve() if candidate.is_absolute() else (workspace / candidate).resolve()
                if resolved.is_relative_to(workspace.resolve()):
                    path = resolved.relative_to(workspace.resolve()).as_posix()
                    path_status = "workspace_relative"
                else:
                    path_status = "outside_workspace"
        raw_kind = change.get("kind")
        kind = raw_kind.casefold() if isinstance(raw_kind, str) and raw_kind.casefold() in {
            "add", "create", "update", "modify", "delete", "remove"
        } else "unknown"
        actions.append({
            "tool": "file_change", "native_item_id": item_id,
            "native_item_id_sha256": item_id_hash, "event_sequence": sequence,
            "completion_sequence": sequence if event_type in {"item.completed", "item.failed"} else None,
            "change_index": index, "lifecycle_event": event_type,
            "lifecycle_events": [event_type],
            "native_status": status, "path": path, "event_timestamp_epoch": None,
            "exit_code_status": "not_applicable", "exit_code": None,
            "path_status": path_status,
            "change_kind": kind,
        })
    return actions


def _file_change_signature(records: list[dict]) -> tuple:
    return tuple(sorted(
        (
            record.get("change_index"), record.get("path"),
            record.get("path_status"), record.get("change_kind"),
            record.get("native_status"),
        )
        for record in records
    ))


def _correlate_codex_file_changes(groups: dict[tuple[str, str], list[dict]]) -> list[dict]:
    """Collapse file-change lifecycle updates to one action per item/change index."""
    actions = []
    for snapshots in groups.values():
        snapshots.sort(key=lambda item: item["sequence"])
        first = snapshots[0]
        terminals = [
            item for item in snapshots
            if item["event_type"] in {"item.completed", "item.failed"}
        ]
        lifecycle_events = sorted({item["event_type"] for item in snapshots})
        signatures = {
            (item["event_type"], _file_change_signature(item["records"]))
            for item in terminals
        }
        ambiguous = len(signatures) > 1
        if terminals and not ambiguous:
            selected = min(terminals, key=lambda item: item["sequence"])
            records = selected["records"]
            terminal_sequence = selected["sequence"]
            terminal_event = selected["event_type"]
            native_status = selected["native_status"]
        elif terminals:
            selected = terminals[-1]
            indexed: dict[int | None, list[dict | None]] = {}
            for terminal in terminals:
                if terminal["records"]:
                    for record in terminal["records"]:
                        indexed.setdefault(record.get("change_index"), []).append(record)
                else:
                    indexed.setdefault(None, []).append(None)
            records = []
            for index, observations in sorted(
                indexed.items(), key=lambda item: (-1 if item[0] is None else item[0]),
            ):
                present = [item for item in observations if isinstance(item, dict)]
                complete_index = len(present) == len(terminals)
                signatures_for_index = {
                    (
                        item.get("path"), item.get("path_status"), item.get("change_kind"),
                        item.get("native_status"),
                    )
                    for item in present
                }
                same_path = complete_index and len(signatures_for_index) == 1
                base = present[0] if present else {
                    "tool": "file_change", "native_item_id": first["native_item_id"],
                    "native_item_id_sha256": first["native_item_id_sha256"],
                    "change_index": index, "path": None, "path_status": "missing",
                    "change_kind": "unknown", "native_status": "unknown",
                }
                records.append({
                    **base,
                    "path": base.get("path") if same_path else None,
                    "path_status": base.get("path_status") if same_path else "conflicting_lifecycle_path",
                    "native_status": "unknown",
                    "change_kind": base.get("change_kind") if same_path else "unknown",
                })
            if not records:
                records = [dict(selected["records"][0])] if selected["records"] else [{
                    "tool": "file_change", "native_item_id": first["native_item_id"],
                    "native_item_id_sha256": first["native_item_id_sha256"],
                    "change_index": None, "path": None, "path_status": "missing",
                    "change_kind": "unknown", "native_status": "unknown",
                }]
            terminal_sequence = None
            terminal_event = "ambiguous_terminal"
            native_status = "unknown"
        else:
            selected = snapshots[-1]
            records = selected["records"]
            terminal_sequence = None
            terminal_event = selected["event_type"]
            native_status = selected["native_status"]

        identity_missing = not isinstance(first.get("native_item_id_sha256"), str)
        for record in records:
            actions.append({
                **record,
                "event_sequence": first["sequence"],
                "completion_sequence": terminal_sequence,
                "lifecycle_event": terminal_event,
                "lifecycle_events": lifecycle_events,
                "native_status": native_status if ambiguous else record.get("native_status", native_status),
                "correlation_conflict": identity_missing or ambiguous,
                "lifecycle_conflict": ambiguous,
                "terminal_event_count": len(terminals),
            })
    return actions


def normalize_codex(raw: bytes, workspace: Path, repo: Path) -> dict:
    """Normalize Codex command/file items and non-executable todo metadata."""
    events, complete, invalid = parse_jsonl(raw)
    grouped: dict[tuple[str, str], dict] = {}
    order: list[tuple[str, str]] = []
    file_change_groups: dict[tuple[str, str], list[dict]] = {}
    planning_metadata: list[dict] = []
    unclassified = 0
    clarification_ids: set[str] = set()
    clarifications_complete = True
    for sequence, event in enumerate(events):
        event_type = event.get("type")
        item = event.get("item")
        if not isinstance(item, dict) or not isinstance(event_type, str) or not event_type.startswith("item."):
            continue
        item_type = item.get("type")
        if not isinstance(item_type, str):
            unclassified += 1
            continue
        if item_type in {"question", "user_input"}:
            item_hash = _codex_id(item)[1]
            if item_hash is None:
                clarifications_complete = False
            else:
                clarification_ids.add(item_hash)
        if item_type == "todo_list":
            if _valid_codex_todo_list(item, event_type):
                _item_id, item_id_hash = _codex_id(item)
                planning_metadata.append({
                    "classification": "planning_metadata",
                    "native_item_id_sha256": item_id_hash,
                    "event_sequence": sequence,
                    "lifecycle_event": event_type,
                })
            else:
                unclassified += 1
            continue
        if item_type == "file_change":
            item_id, item_id_hash = _codex_id(item)
            identity_key = item_id_hash if item_id_hash is not None else f"event-{sequence}"
            file_key = (identity_key, "file_change")
            file_change_groups.setdefault(file_key, []).append({
                "sequence": sequence,
                "event_type": event_type,
                "native_item_id": item_id,
                "native_item_id_sha256": item_id_hash,
                "native_status": _native_status(item),
                "records": _codex_file_changes(item, event_type, sequence, workspace),
            })
            continue
        if item_type != "command_execution":
            if item_type not in {"agent_message", "reasoning", "user_input", "question"}:
                unclassified += 1
            continue
        item_id, item_id_hash = _codex_id(item)
        key = (item_id or f"event-{sequence}", "command_execution")
        command = item.get("command")
        command = command if isinstance(command, str) else None
        action = grouped.get(key)
        if action is None:
            action = {
                "tool": "command_execution", "native_item_id": item_id,
                "native_item_id_sha256": item_id_hash,
                "event_sequence": sequence, "completion_sequence": None,
                "command_value": command, "command_conflict": False,
                "exit_code_status": "missing", "exit_code": None,
                "native_status": "missing", "lifecycle_events": [],
                "terminal_outcomes": [],
            }
            grouped[key] = action
            order.append(key)
        elif command is not None and action["command_value"] not in {None, command}:
            action["command_conflict"] = True
        elif command is not None:
            action["command_value"] = command
        action["lifecycle_events"].append(event_type)
        explicit_status = _native_status(item)
        if explicit_status != "missing":
            action["native_status"] = explicit_status
        if event_type in {"item.completed", "item.failed"}:
            action["completion_sequence"] = sequence
            exit_status, exit_code = _explicit_exit(item)
            action["terminal_outcomes"].append((event_type, exit_status, exit_code))

    actions = []
    for key in order:
        item = grouped[key]
        original = item.pop("command_value")
        safe = _safe_text(original, workspace, repo) if isinstance(original, str) else None
        if item.pop("command_conflict"):
            safe = None
        terminal_outcomes = item.pop("terminal_outcomes")
        if len(terminal_outcomes) == 1:
            _event_type, item["exit_code_status"], item["exit_code"] = terminal_outcomes[0]
        elif terminal_outcomes:
            item["exit_code_status"], item["exit_code"] = "unknown", None
        try:
            encoded = safe.encode("utf-8") if safe is not None else None
        except UnicodeEncodeError:
            safe = None
            encoded = None
        private_path = False
        if safe is not None:
            masked = ALLOWED_WRAPPER_PATH_RE.sub("", safe)
            private_path = bool(ABSOLUTE_PATH_RE.search(masked) or WINDOWS_ABSOLUTE_PATH_RE.search(safe))
        # The authoritative parser input is either the whole safe command or absent;
        # a preview and an inner-shell normalization never replace this evidence.
        command_truncated = (
            len(encoded) > MAX_COMMAND_BYTES or private_path if encoded is not None else None
        )
        bounded_command = safe if encoded is not None and command_truncated is False else None
        if bounded_command is not None:
            normalized, normalization = normalize_command(bounded_command, "codex")
        elif safe is None:
            normalized, normalization = None, "missing"
        elif private_path:
            normalized, normalization = None, "private-path-redacted"
        else:
            normalized, normalization = None, "command-exceeds-shared-byte-bound"
        item.update({
            "command": bounded_command,
            "command_preview": safe[:COMMAND_PREVIEW_LIMIT] if safe is not None and not private_path else None,
            "command_sha256": hashlib.sha256(encoded).hexdigest() if encoded is not None else None,
            "command_bytes": len(encoded) if encoded is not None else None,
            "command_truncated": command_truncated,
            "command_redaction_status": "private_path" if private_path else "none" if safe is not None else "unknown",
            "normalized_command": normalized
            if normalized is not None and len(normalized.encode("utf-8")) <= NORMALIZED_COMMAND_LIMIT
            else None,
            "normalization": normalization,
        })
        item["lifecycle_events"] = sorted(set(item["lifecycle_events"]))
        sequence = item.get("event_sequence")
        if type(sequence) is int and sequence < len(events):
            item["event_timestamp_epoch"] = _event_epoch(events[sequence])
        actions.append(item)
    file_actions = _correlate_codex_file_changes(file_change_groups)
    for action in file_actions:
        sequence = action.get("event_sequence")
        if type(sequence) is int and sequence < len(events):
            action["event_timestamp_epoch"] = _event_epoch(events[sequence])
        completion = action.get("completion_sequence")
        if type(completion) is int and completion < len(events):
            action["completion_timestamp_epoch"] = _event_epoch(events[completion])
    actions.extend(file_actions)
    session = _session_id(events, "codex")
    return {
        "actions": actions,
        "planning_metadata": planning_metadata,
        "events_observed": len(events),
        "invalid_lines": invalid,
        "unclassified_item_count": unclassified,
        "clarification_observations": len(clarification_ids) if clarifications_complete else None,
        "trace_complete": complete and bool(events) and unclassified == 0,
        "session_id_sha256": hashlib.sha256(session.encode()).hexdigest() if session else None,
    }
