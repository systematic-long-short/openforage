"""Trace-only evidence predicates shared by the v2 grader and runner."""

from __future__ import annotations

import hashlib
import re
from pathlib import Path

from commands import (
    classify_shell_segment,
    direct_suite_access,
    start_here_task,
    validator_modes,
    validator_segment_modes,
)
from native_arguments import (
    NATIVE_ARGUMENT_TOOLS,
    native_read_covers_source,
    validate_native_arguments,
)
from shell_parser import parse_shell_command

CALL_HASH_RE = re.compile(r"[0-9a-f]{64}\Z")
ROUTE_SOURCES = {
    "README.md", "AGENTS.md", "CLAUDE.md", "docs/agents/first-contribution.md",
    "docs/agents/start-here.md", "docs/agents/references/onboarding.json",
}
ROOT_ENTRIES = {"README.md", "AGENTS.md"}
TASK_SOURCES = {"docs/agents/first-contribution.md", "docs/agents/start-here.md", "docs/agents/references/onboarding.json"}


def action_sequence(action: dict) -> int | None:
    value = action.get("event_sequence")
    if type(value) is int:
        return value
    value = action.get("completion_sequence")
    return value if type(value) is int else None


def result_sequence(action: dict) -> int | None:
    value = action.get("completion_sequence")
    return value if type(value) is int else action_sequence(action)


def command_text(action: dict, harness: str) -> str | None:
    if action.get("command_truncated") is not False:
        return None
    value = action.get("command")
    return value if isinstance(value, str) else None


def explicit_exit_code(action: dict, harness: str) -> int | None:
    if harness == "opencode":
        if action.get("tool") not in {"bash", "shell"}:
            return None
        if action.get("correlation_conflict", False) is not False:
            return None
        if not isinstance(action.get("native_tool_call_id_sha256"), str) or not CALL_HASH_RE.fullmatch(action["native_tool_call_id_sha256"]):
            return None
        start = action.get("event_sequence")
        completed = action.get("completion_sequence")
        if type(start) is not int or type(completed) is not int or completed < start:
            return None
        if type(action.get("outcome_schema_version")) is not int or action["outcome_schema_version"] != 1:
            return None
        outcome = action.get("outcome")
        if not isinstance(outcome, dict) or outcome.get("shell_exit_code_status") != "observed":
            return None
        if outcome.get("native_tool_status") not in {"completed", "error"}:
            return None
        value = outcome.get("shell_exit_code")
        return value if type(value) is int else None
    if harness == "codex":
        if action.get("tool") != "command_execution" or action.get("exit_code_status") != "observed":
            return None
        if action.get("native_status") not in {"completed", "failed", "error"}:
            return None
        native_item_id = action.get("native_item_id")
        native_item_hash = action.get("native_item_id_sha256")
        if (
            not isinstance(native_item_id, str)
            or not isinstance(native_item_hash, str)
            or not CALL_HASH_RE.fullmatch(native_item_hash)
            or hashlib.sha256(native_item_id.encode("utf-8")).hexdigest() != native_item_hash
        ):
            return None
        start = action.get("event_sequence")
        completed = action.get("completion_sequence")
        lifecycle = action.get("lifecycle_events")
        if (
            type(start) is not int
            or type(completed) is not int
            or completed < start
            or not isinstance(lifecycle, list)
            or "item.completed" not in lifecycle
        ):
            return None
        if "item.failed" in lifecycle or action.get("native_status") in {"denied", "cancelled", "timeout"}:
            return None
        value = action.get("exit_code")
        return value if type(value) is int else None
    return None


def validator_observations(actions: list, harness: str, workspace: Path) -> list[dict]:
    results = []
    for action in actions:
        if not isinstance(action, dict):
            continue
        text = command_text(action, harness)
        if text is None:
            continue
        parsed = parse_shell_command(text, harness)
        if parsed is None:
            continue
        modes, error = validator_modes(text, workspace, harness)
        if modes is None:
            continue
        validator_segments = []
        for index, segment in enumerate(parsed.segments):
            segment_modes, _segment_error = validator_segment_modes(segment, workspace)
            if segment_modes is not None:
                validator_segments.append({
                    "index": index,
                    "argv": list(segment.argv),
                    "modes": segment_modes,
                })
        if not validator_segments:
            continue
        segment_modes = [mode for item in validator_segments for mode in item["modes"]]
        if segment_modes != modes:
            continue
        command_digest_valid = command_sha256_matches(action)
        shell_exit = explicit_exit_code(action, harness) if command_digest_valid else None
        native_status = (
            action.get("outcome", {}).get("native_tool_status")
            if harness == "opencode" and isinstance(action.get("outcome"), dict)
            else action.get("native_status")
        )
        if not command_digest_valid:
            inferred_exit = None
            inference_basis = "native_full_command_digest_missing_or_mismatched"
        elif shell_exit == 0 and native_status != "completed":
            inferred_exit = None
            inference_basis = "native_zero_exit_lacks_completed_lifecycle"
        elif len(parsed.segments) == 1 and shell_exit in {126, 127}:
            inferred_exit = None
            inference_basis = f"standalone_shell_launch_failure_{shell_exit}"
        elif len(parsed.segments) == 1:
            inferred_exit = shell_exit
            inference_basis = (
                "standalone_native_shell_exit"
                if shell_exit is not None
                else "standalone_native_exit_missing_denied_or_conflicting"
            )
        elif shell_exit is None:
            inferred_exit = None
            inference_basis = "and_chain_native_exit_missing_denied_or_conflicting"
        elif shell_exit != 0:
            inferred_exit = None
            inference_basis = "and_chain_nonzero_exit_does_not_locate_validator_outcome"
        elif any(
            len(item.argv) == 1 and Path(item.argv[0]).name.casefold() == "false"
            for item in parsed.segments
        ):
            inferred_exit = None
            inference_basis = "and_chain_zero_exit_conflicts_with_literal_false_segment"
        else:
            inferred_exit = 0
            inference_basis = "explicit_native_exit_zero_for_fully_admitted_and_chain"
        results.append({
            "action": action,
            "modes": modes,
            "segment_index": validator_segments[0]["index"],
            "validator_segment_indices": [item["index"] for item in validator_segments],
            "validator_segments": validator_segments,
            "validator_segment_argv": validator_segments[0]["argv"],
            "exit_code": inferred_exit,
            "compound_shell_exit_code": shell_exit if len(parsed.segments) > 1 else None,
            "native_shell_exit_code": shell_exit,
            "inference_basis": inference_basis,
            "command_key": parsed.execution_key,
            "parse_error": error,
        })
    return results


def _safe_relative(value: str, workspace: Path) -> str | None:
    text = value.strip().strip("\"'")
    if text.startswith("<WORKSPACE>/"):
        text = text[len("<WORKSPACE>/"):]
    elif text.startswith(str(workspace.resolve()) + "/"):
        text = text[len(str(workspace.resolve()) + "/"):]
    elif text.startswith("/"):
        return None
    if text.startswith("./"):
        text = text[2:]
    path = Path(text)
    if not text or path.is_absolute() or "\\" in text or ".." in path.parts:
        return None
    return path.as_posix()


def _segment_read_operands(segment, workspace: Path) -> tuple[list[str], str, bool]:
    words = list(segment.argv)
    if not words:
        return [], "", False
    tool = Path(words[0]).name.casefold()
    args = words[1:]
    if tool in {"cat", "head", "tail", "less", "more"}:
        selected = [item for item in args if not item.startswith("-")]
    elif tool in {"grep", "rg", "egrep", "fgrep"}:
        nonoptions = [item for item in args if not item.startswith("-")]
        selected = nonoptions[1:]
    elif tool == "sed":
        selected, classified = _simple_sed_operands(args)
        if not classified:
            return [], tool, False
    else:
        selected = []
    operands = []
    for value in selected:
        item = _safe_relative(value, workspace)
        if item is None:
            return [], tool, False
        operands.append(item)
    return operands, tool, True


def _read_operands(command: str, harness: str, workspace: Path) -> tuple[set[str], bool]:
    parsed = parse_shell_command(command, harness)
    if parsed is None:
        return set(), False
    operands: set[str] = set()
    for segment in parsed.segments:
        if classify_shell_segment(segment, workspace) is None:
            return set(), False
        selected, _tool, classified = _segment_read_operands(segment, workspace)
        if not classified:
            return set(), False
        operands.update(selected)
    return operands, True


def _shell_read_observations(
    command: str, harness: str, workspace: Path,
) -> list[tuple[str, str, int, int]]:
    """Return ordered path/kind/segment/operand records for admitted shell reads."""
    parsed = parse_shell_command(command, harness)
    if parsed is None:
        return []
    observations = []
    for segment_index, segment in enumerate(parsed.segments):
        if classify_shell_segment(segment, workspace) is None:
            return []
        operands, tool, classified = _segment_read_operands(segment, workspace)
        if not classified:
            return []
        if tool == "cat":
            kind = "shell_content_read"
        elif tool in {"grep", "rg", "egrep", "fgrep"}:
            kind = "shell_content_search"
        elif tool in {"head", "tail", "sed", "less", "more"}:
            kind = "shell_partial_content_read"
        else:
            continue
        observations.extend(
            (path, kind, segment_index, operand_index)
            for operand_index, path in enumerate(operands)
        )
    return observations


def _nonempty_regular_source(path: str, workspace: Path) -> bool:
    """Confirm a workspace-relative source exists and has at least one line."""
    try:
        if workspace.is_symlink():
            return False
        source = workspace
        for part in Path(path).parts:
            source = source / part
            if source.is_symlink():
                return False
        if not source.resolve(strict=True).is_relative_to(workspace.resolve()):
            return False
        if not source.is_file():
            return False
        payload = source.read_bytes()
    except (OSError, RuntimeError):
        return False
    return bool(payload.splitlines())


def _observed_nonempty_tool_output(action: dict) -> bool:
    outcome = action.get("outcome")
    if not isinstance(outcome, dict):
        return False
    output_bytes = outcome.get("output_bytes")
    output_hash = outcome.get("output_sha256")
    return (
        outcome.get("output_hash_status") == "observed"
        and type(output_bytes) is int
        and output_bytes > 0
        and isinstance(output_hash, str)
        and CALL_HASH_RE.fullmatch(output_hash) is not None
    )


def _usable_native_source_read(action: dict, arguments: dict, harness: str, workspace: Path) -> bool:
    return (
        action.get("tool") == "read"
        and _read_succeeded(action, harness, workspace)
        and _observed_nonempty_tool_output(action)
        and native_read_covers_source(arguments, workspace)
    )


def _simple_sed_operands(args: list[str]) -> tuple[list[str], bool]:
    """Recognize only a simple sed address/range followed by file operands."""
    scripts = []
    index = 0
    positional = False
    while index < len(args):
        token = args[index]
        if token == "--":
            index += 1
            positional = True
            break
        if token in {"-n", "-E", "-r", "--quiet", "--silent"}:
            index += 1
            continue
        if token in {"-e", "--expression"}:
            if index + 1 >= len(args):
                return [], False
            scripts.append(args[index + 1])
            index += 2
            continue
        if token.startswith("-"):
            return [], False
        scripts.append(token)
        index += 1
        break
    if len(scripts) != 1:
        return [], False
    if re.fullmatch(r"(?:\d+|\$)(?:,(?:\d+|\$))?[pP]?", scripts[0]) is None:
        return [], False
    operands = args[index:]
    if not positional:
        operands = [item for item in operands if not item.startswith("-")]
    return operands, True


def _read_succeeded(action: dict, harness: str, workspace: Path) -> bool:
    if harness == "opencode":
        if action.get("tool") in {"bash", "shell"}:
            return explicit_exit_code(action, harness) == 0 and command_sha256_matches(action)
        outcome = action.get("outcome")
        if action.get("tool") in {"read", "grep"}:
            arguments, problem = validate_native_arguments(action, workspace)
            return (
                problem is None
                and isinstance(arguments, dict)
                and isinstance(outcome, dict)
                and outcome.get("native_tool_status") == "completed"
                and command_sha256_matches(action)
            )
        return isinstance(outcome, dict) and outcome.get("native_tool_status") == "completed"
    return explicit_exit_code(action, harness) == 0 and command_sha256_matches(action)


def observed_route_sources(actions: list, harness: str, workspace: Path) -> tuple[set[str], bool, bool]:
    reads: set[str] = set()
    root_route_invoked = False
    route_reads_complete = True
    for action in actions:
        if not isinstance(action, dict):
            continue
        tool = str(action.get("tool", "")).casefold()
        value = action.get("command")
        if tool in NATIVE_ARGUMENT_TOOLS:
            arguments, problem = validate_native_arguments(action, workspace)
            if problem is not None or arguments is None:
                route_reads_complete = False
                continue
            if tool == "read" and _read_succeeded(action, harness, workspace):
                relative = arguments.get("path")
                if relative in ROUTE_SOURCES and _usable_native_source_read(
                    action, arguments, harness, workspace,
                ):
                    reads.add(relative)
                else:
                    route_reads_complete = False
        elif tool in {"bash", "shell", "command_execution"}:
            if not isinstance(value, str) or action.get("command_truncated") is not False:
                route_reads_complete = False
                continue
            succeeded = _read_succeeded(action, harness, workspace)
            parsed = parse_shell_command(value, harness)
            if succeeded and parsed is None:
                route_reads_complete = False
                continue
            if not succeeded or parsed is None:
                continue
            _operands, classified = _read_operands(value, harness, workspace)
            if not classified:
                route_reads_complete = False
                continue
            full_reads = {
                path for path, kind, _segment_index, _operand_index
                in _shell_read_observations(value, harness, workspace)
                if kind == "shell_content_read" and _nonempty_regular_source(path, workspace)
            }
            reads.update(full_reads & ROUTE_SOURCES)
            for segment in parsed.segments:
                if start_here_task(segment) == "contribute":
                    root_route_invoked = True
    return reads, root_route_invoked, route_reads_complete


def _native_action_reference(action: dict, harness: str) -> dict:
    identity_key = "native_tool_call_id_sha256" if harness == "opencode" else "native_item_id_sha256"
    identity = action.get(identity_key)
    return {
        "event_sequence": action_sequence(action),
        "completion_sequence": result_sequence(action),
        "identity_kind": identity_key,
        "identity_sha256": identity if isinstance(identity, str) and CALL_HASH_RE.fullmatch(identity) else None,
        "tool": action.get("tool"),
    }


def content_read_observations(actions: list, harness: str, workspace: Path) -> list[dict]:
    """List evidenced full-source reads and distinct searches; discovery is excluded."""
    observations: list[dict] = []
    for action in actions:
        if not isinstance(action, dict):
            continue
        tool = str(action.get("tool", "")).casefold()
        sequence = result_sequence(action)
        start_sequence = action_sequence(action)
        if type(sequence) is not int or type(start_sequence) is not int:
            continue
        if tool in {"read", "grep"}:
            arguments, problem = validate_native_arguments(action, workspace)
            if problem is None and isinstance(arguments, dict) and _read_succeeded(action, harness, workspace):
                relative = arguments.get("path")
                kind = None
                if tool == "read" and _usable_native_source_read(
                    action, arguments, harness, workspace,
                ):
                    kind = "native_content_read"
                elif tool == "grep":
                    kind = "native_content_search"
                if isinstance(relative, str) and relative != "." and kind is not None:
                    observations.append({
                        "path": relative,
                        "sequence": sequence,
                        "start_sequence": start_sequence,
                        "action": _native_action_reference(action, harness),
                        "kind": kind,
                        "segment_index": None,
                        "operand_index": None,
                    })
            continue
        if tool not in {"bash", "shell", "command_execution"}:
            continue
        command = action.get("command")
        if not isinstance(command, str) or not _read_succeeded(action, harness, workspace):
            continue
        parsed = parse_shell_command(command, harness)
        _operands, classified = _read_operands(command, harness, workspace)
        if parsed is None or not classified:
            continue
        for relative, kind, segment_index, operand_index in _shell_read_observations(
            command, harness, workspace,
        ):
            if kind == "shell_content_read" and not _nonempty_regular_source(relative, workspace):
                continue
            observations.append({
                "path": relative,
                "sequence": sequence,
                "start_sequence": start_sequence,
                "action": _native_action_reference(action, harness),
                "kind": kind,
                "segment_index": segment_index,
                "operand_index": operand_index,
            })
    return observations


def _route_action_identity(item: dict) -> tuple[str, str] | None:
    action = item.get("action")
    if not isinstance(action, dict):
        return None
    kind = action.get("identity_kind")
    identity = action.get("identity_sha256")
    if (
        not isinstance(kind, str)
        or not isinstance(identity, str)
        or CALL_HASH_RE.fullmatch(identity) is None
    ):
        return None
    return kind, identity


def _same_route_action(left: dict, right: dict) -> bool:
    left_identity = _route_action_identity(left)
    right_identity = _route_action_identity(right)
    if left_identity is None or left_identity != right_identity:
        return False
    left_action = left.get("action")
    right_action = right.get("action")
    assert isinstance(left_action, dict) and isinstance(right_action, dict)
    return (
        left_action.get("tool") == right_action.get("tool")
        and type(left_action.get("event_sequence")) is int
        and type(left_action.get("completion_sequence")) is int
        and left_action.get("event_sequence") == right_action.get("event_sequence")
        and left_action.get("completion_sequence") == right_action.get("completion_sequence")
    )


def _route_position(item: dict) -> tuple[int, int] | None:
    segment_index = item.get("segment_index")
    operand_index = item.get("operand_index")
    if type(segment_index) is not int or segment_index < 0:
        return None
    if operand_index is None:
        return segment_index, -1
    if type(operand_index) is not int or operand_index < 0:
        return None
    return segment_index, operand_index


def _strictly_precedes(left: dict, right: dict) -> bool | None:
    """Compare sub-actions in one native call or non-overlapping native calls.

    ``None`` means the trace does not establish an order. Positions are local
    to a native action and never create a new native identity or timestamp.
    """
    if _same_route_action(left, right):
        left_position = _route_position(left)
        right_position = _route_position(right)
        if left_position is None or right_position is None or left_position == right_position:
            return None
        return left_position < right_position

    left_start = left.get("start_sequence")
    left_end = left.get("sequence")
    right_start = right.get("start_sequence")
    right_end = right.get("sequence")
    if not all(type(value) is int for value in (left_start, left_end, right_start, right_end)):
        return None
    if left_end < right_start:
        return True
    if right_end < left_start:
        return False
    return None


def _earliest_ordered_item(items: list[dict]) -> dict | None:
    """Select an item proven to precede every other candidate, if unique."""
    for candidate_index, candidate in enumerate(items):
        if all(
            candidate_index == other_index
            or _strictly_precedes(candidate, other) is True
            for other_index, other in enumerate(items)
        ):
            return candidate
    return None


def entry_route_evidence(
    actions: list,
    harness: str,
    workspace: Path,
    *,
    task: str,
    task_route_paths: tuple[str, ...],
) -> dict:
    """Measure root-first, selector/start-here, then task-specific route reads."""
    observations = content_read_observations(actions, harness, workspace)
    reads = [
        item for item in observations
        if item.get("kind") in {"native_content_read", "shell_content_read"}
    ]
    consultations = [
        item for item in observations
        if item.get("kind") in {
            "native_content_read", "native_content_search", "shell_content_read",
            "shell_content_search", "shell_partial_content_read",
        }
    ]
    root_reads: dict[str, dict] = {}
    missing = []
    for path in sorted(ROOT_ENTRIES):
        candidates = [item for item in reads if item["path"] == path]
        first = _earliest_ordered_item(candidates)
        if first is None:
            missing.append(f"completed content read of {path}")
            if candidates:
                missing.append(f"orderable first-read position for {path}")
            continue
        root_reads[path] = first

    if len(root_reads) == len(ROOT_ENTRIES) and any(
        _strictly_precedes(root_read, item) is not True
        for item in consultations
        if item["path"] not in ROOT_ENTRIES
        for root_read in root_reads.values()
    ):
        missing.append("README.md and AGENTS.md are the first content sources consulted")

    helper_candidates = []
    if len(root_reads) == len(ROOT_ENTRIES):
        for action in actions:
            if not isinstance(action, dict) or action.get("tool") not in {"bash", "shell", "command_execution"}:
                continue
            command = action.get("command")
            if not isinstance(command, str) or not _read_succeeded(action, harness, workspace):
                continue
            parsed = parse_shell_command(command, harness)
            if parsed is None:
                continue
            if not all(classify_shell_segment(segment, workspace) is not None for segment in parsed.segments):
                continue
            sequence = result_sequence(action)
            start_sequence = action_sequence(action)
            if type(sequence) is not int or type(start_sequence) is not int:
                continue
            for segment_index, segment in enumerate(parsed.segments):
                if start_here_task(segment) != task:
                    continue
                candidate = {
                    "kind": "start_here_cli_selector",
                    "task": task,
                    "sequence": sequence,
                    "start_sequence": start_sequence,
                    "action": _native_action_reference(action, harness),
                    "segment_index": segment_index,
                    "operand_index": None,
                }
                if all(_strictly_precedes(root_read, candidate) is True for root_read in root_reads.values()):
                    helper_candidates.append(candidate)
    readable_candidates = []
    if len(root_reads) == len(ROOT_ENTRIES):
        for item in reads:
            if item["path"] != "docs/agents/start-here.md":
                continue
            candidate = {
                "kind": "readable_start_here_packet",
                "task": task,
                "sequence": item["sequence"],
                "start_sequence": item["start_sequence"],
                "action": item["action"],
                "segment_index": item.get("segment_index"),
                "operand_index": item.get("operand_index"),
            }
            if all(_strictly_precedes(root_read, candidate) is True for root_read in root_reads.values()):
                readable_candidates.append(candidate)
    route_candidates = [*helper_candidates, *readable_candidates]
    entry = _earliest_ordered_item(route_candidates)
    if entry is None:
        missing.append("successful task selector or completed readable docs/agents/start-here.md after root reads")

    task_reads: dict[str, dict] = {}
    if entry is not None:
        for path in task_route_paths:
            matches = [
                item for item in reads
                if item["path"] == path and _strictly_precedes(entry, item) is True
            ]
            first = _earliest_ordered_item(matches)
            if first is not None:
                task_reads[path] = first
            else:
                missing.append(f"completed task-specific route read of {path} after the entry route")
    else:
        missing.extend(f"completed task-specific route read of {path} after the entry route" for path in task_route_paths)

    observed_root = {
        path: {
            "sequence": item["sequence"],
            "action": item["action"],
            "segment_index": item.get("segment_index"),
            "operand_index": item.get("operand_index"),
        }
        for path, item in sorted(root_reads.items())
    }
    return {
        "contract_version": "entrypoint-first-v1",
        "task": task,
        "status": "pass" if not missing else "fail",
        "criteria": {
            "root_files": ["README.md", "AGENTS.md"],
            "root_files_first_content_sources": True,
            "entry_route": ["scripts/start_here.py --task <task>", "docs/agents/start-here.md"],
            "task_route_paths": list(task_route_paths),
            "injected_prompt_alone_satisfies_no_criterion": True,
        },
        "root_entry_reads": observed_root,
        "entry_route_observation": entry,
        "task_route_reads": task_reads,
        "content_read_observations": observations,
        "missing_evidence": list(dict.fromkeys(missing)),
    }


def suite_accesses(actions: list, harness: str, workspace: Path) -> list[int]:
    return [index for index, action in enumerate(actions) if isinstance(action, dict) and direct_suite_access(action, harness, workspace)]


def command_sha256_matches(action: dict) -> bool:
    command = action.get("command")
    if not isinstance(command, str) or action.get("command_truncated") is not False:
        return False
    try:
        encoded = command.encode("utf-8")
    except UnicodeEncodeError:
        return False
    return (
        action.get("command_sha256") == hashlib.sha256(encoded).hexdigest()
        and type(action.get("command_bytes")) is int
        and action.get("command_bytes") == len(encoded)
    )
