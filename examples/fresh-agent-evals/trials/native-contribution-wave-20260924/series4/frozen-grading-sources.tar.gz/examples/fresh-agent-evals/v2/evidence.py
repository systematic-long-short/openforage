"""Trace-only evidence predicates shared by the v2 grader and runner."""

from __future__ import annotations

import hashlib
import re
import shlex
from pathlib import Path

from commands import direct_suite_access, normalize_command, validator_modes

CALL_HASH_RE = re.compile(r"[0-9a-f]{64}\Z")
ROUTE_SOURCES = {
    "README.md", "AGENTS.md", "CLAUDE.md", "docs/agents/first-contribution.md",
    "docs/agents/start-here.md", "docs/agents/references/onboarding.json",
}
ROOT_ENTRIES = {"README.md", "AGENTS.md", "CLAUDE.md"}
TASK_SOURCES = {"docs/agents/first-contribution.md", "docs/agents/start-here.md", "docs/agents/references/onboarding.json"}


def action_sequence(action: dict) -> int | None:
    value = action.get("event_sequence")
    if type(value) is int:
        return value
    value = action.get("completion_sequence")
    return value if type(value) is int else None


def result_sequence(action: dict) -> int | None:
    value = action.get("completion_sequence")
    return value if type(value) is int else action_sequence(action)


def command_text(action: dict, harness: str) -> str | None:
    if harness == "codex" and action.get("tool") == "command_execution":
        if action.get("command_truncated") is not False:
            return None
    if action.get("command_truncated") is True:
        return None
    value = action.get("command")
    return value if isinstance(value, str) else None


def explicit_exit_code(action: dict, harness: str) -> int | None:
    if harness == "opencode":
        if action.get("tool") not in {"bash", "shell"}:
            return None
        if action.get("correlation_conflict", False) is not False:
            return None
        if not isinstance(action.get("native_tool_call_id_sha256"), str) or not CALL_HASH_RE.fullmatch(action["native_tool_call_id_sha256"]):
            return None
        outcome = action.get("outcome")
        if not isinstance(outcome, dict) or outcome.get("shell_exit_code_status") != "observed":
            return None
        if outcome.get("native_tool_status") not in {"completed", "error"}:
            return None
        value = outcome.get("shell_exit_code")
        return value if type(value) is int else None
    if harness == "codex":
        if action.get("tool") != "command_execution" or action.get("exit_code_status") != "observed":
            return None
        if action.get("native_status") not in {"completed", "failed", "error"}:
            return None
        if not isinstance(action.get("native_item_id"), str) or not isinstance(action.get("native_item_id_sha256"), str):
            return None
        if action.get("completion_sequence") is None or "item.completed" not in action.get("lifecycle_events", []):
            return None
        if "item.failed" in action.get("lifecycle_events", []) or action.get("native_status") in {"denied", "cancelled", "timeout"}:
            return None
        value = action.get("exit_code")
        return value if type(value) is int else None
    return None


def validator_observations(actions: list, harness: str, workspace: Path) -> list[dict]:
    results = []
    for action in actions:
        if not isinstance(action, dict):
            continue
        text = command_text(action, harness)
        if text is None:
            continue
        modes, error = validator_modes(text, workspace, harness)
        if modes is None:
            continue
        results.append({"action": action, "modes": modes, "exit_code": explicit_exit_code(action, harness), "parse_error": error})
    return results


def _safe_relative(value: str, workspace: Path) -> str | None:
    text = value.strip().strip("\"'")
    if text.startswith("<WORKSPACE>/"):
        text = text[len("<WORKSPACE>/"):]
    elif text.startswith(str(workspace.resolve()) + "/"):
        text = text[len(str(workspace.resolve()) + "/"):]
    elif text.startswith("/"):
        return None
    if text.startswith("./"):
        text = text[2:]
    path = Path(text)
    if not text or path.is_absolute() or "\\" in text or ".." in path.parts:
        return None
    return path.as_posix()


def _read_operands(command: str, harness: str, workspace: Path) -> tuple[set[str], bool]:
    normalized, _kind = normalize_command(command, harness)
    if normalized is None:
        return set(), False
    try:
        words = shlex.split(normalized, posix=True)
    except ValueError:
        return set(), False
    if not words:
        return set(), False
    tool = Path(words[0]).name
    args = words[1:]
    if tool in {"cat", "head", "tail", "less", "more"}:
        operands = [item for item in args if not item.startswith("-")]
    elif tool in {"grep", "rg", "egrep", "fgrep"}:
        nonoptions = [item for item in args if not item.startswith("-")]
        operands = nonoptions[1:]
    elif tool == "sed":
        operands, classified = _simple_sed_operands(args)
        if not classified:
            return set(), False
    else:
        return set(), True
    return {item for value in operands if (item := _safe_relative(value, workspace))}, True


def _simple_sed_operands(args: list[str]) -> tuple[list[str], bool]:
    """Recognize only a simple sed address/range followed by file operands."""
    scripts = []
    index = 0
    positional = False
    while index < len(args):
        token = args[index]
        if token == "--":
            index += 1
            positional = True
            break
        if token in {"-n", "-E", "-r", "--quiet", "--silent"}:
            index += 1
            continue
        if token in {"-e", "--expression"}:
            if index + 1 >= len(args):
                return [], False
            scripts.append(args[index + 1])
            index += 2
            continue
        if token.startswith("-"):
            return [], False
        scripts.append(token)
        index += 1
        break
    if len(scripts) != 1:
        return [], False
    if re.fullmatch(r"(?:\d+|\$)(?:,(?:\d+|\$))?[pP]?", scripts[0]) is None:
        return [], False
    operands = args[index:]
    if not positional:
        operands = [item for item in operands if not item.startswith("-")]
    return operands, True


def _read_succeeded(action: dict, harness: str) -> bool:
    if harness == "opencode":
        if action.get("tool") in {"bash", "shell"}:
            return explicit_exit_code(action, harness) == 0
        outcome = action.get("outcome")
        return isinstance(outcome, dict) and outcome.get("native_tool_status") == "completed"
    return explicit_exit_code(action, harness) == 0


def observed_route_sources(actions: list, harness: str, workspace: Path) -> tuple[set[str], bool, bool]:
    reads: set[str] = set()
    root_route_invoked = False
    route_reads_complete = True
    for action in actions:
        if not isinstance(action, dict):
            continue
        tool = str(action.get("tool", "")).casefold()
        value = action.get("command")
        if tool == "read" and isinstance(value, str):
            relative = _safe_relative(value, workspace)
            if relative in ROUTE_SOURCES and _read_succeeded(action, harness):
                reads.add(relative)
        elif tool in {"bash", "shell", "command_execution"} and isinstance(value, str):
            succeeded = _read_succeeded(action, harness)
            normalized, _kind = normalize_command(value, harness)
            if succeeded and normalized is None:
                route_reads_complete = False
                continue
            if not succeeded or normalized is None:
                continue
            try:
                words = shlex.split(normalized, posix=True)
            except ValueError:
                route_reads_complete = False
                continue
            if not words:
                route_reads_complete = False
                continue
            shell_tool = Path(words[0]).name
            operands, classified = _read_operands(value, harness, workspace)
            if shell_tool in {"cat", "head", "tail", "less", "more", "grep", "rg", "egrep", "fgrep", "sed"} and not classified:
                route_reads_complete = False
            reads.update(operands & ROUTE_SOURCES)
            if len(words) >= 2 and re.fullmatch(r"python(?:3(?:\.\d+)?)?", shell_tool) and words[1].removeprefix("./") == "scripts/start_here.py":
                args = words[2:]
                root_route_invoked |= ("--task" in args and "contribute" in args) or "--task=contribute" in args
    return reads, root_route_invoked, route_reads_complete


def suite_accesses(actions: list, harness: str, workspace: Path) -> list[int]:
    return [index for index, action in enumerate(actions) if isinstance(action, dict) and direct_suite_access(action, harness, workspace)]


def command_sha256_matches(action: dict) -> bool:
    command = action.get("command")
    if not isinstance(command, str) or action.get("command_truncated") is not False:
        return False
    encoded = command.encode("utf-8")
    return action.get("command_sha256") == hashlib.sha256(encoded).hexdigest() and action.get("command_bytes") == len(encoded)
