"""Harness routing registry and evidence-gated capability validation.

The validator checks consistency and presence, never the actual truth of an
observation. A static check cannot confirm that a fixture ran; it can only
confirm that a claimed verified entry carries a real test id, a calendar date,
a typed scope, an existing in-repository evidence artifact, and a passing
observed result, and that an aggregate ``verified`` entry does not combine
unrelated versions, surfaces, or operating systems.
"""

from __future__ import annotations

import json
from pathlib import Path

from .common import (
    is_calendar_date,
    is_real_string,
    passing_result_problem,
    read_text,
    rel,
    resolve_repo_artifact,
)

REGISTRY_REL = "src/openforage/skills/agent_runtime_integration/references/harnesses.json"
REGISTRY_STATUSES = {"documented-unverified", "discovery-only", "unresolved", "verified"}
CAPABILITY_STATUSES = {"verified", "unverified", "unresolved"}

REQUIRED_CAPABILITIES = {
    "distinct-session-identity",
    "separate-cli-invocation",
    "parent-independence",
    "native-goal-task-memory",
    "shell-execution",
    "workspace-read-write",
    "scheduler-wakeup-and-consumption",
    "pause",
    "resume",
    "stop",
    "crash-recovery",
    "duplicate-start-control",
    "exact-target-control",
    "terminal-triggers-stopped",
}

REGISTRY_REQUIRED_KEYS = {
    "product",
    "identity",
    "surface",
    "status",
    "verified_on",
    "sources",
    "native_controls",
    "separate_session_evidence",
    "scheduler_evidence",
    "lifecycle_evidence",
    "route",
}

VERIFIED_EVIDENCE_FIELDS = (
    "evidence_artifact",
    "test_id",
    "tested_at",
    "product_version",
    "scope",
    "observed_result",
)


def _check_verified_capability(report, where: str, root: Path, references_dir: Path, item) -> None:
    if not isinstance(item, dict):
        report.fail(f"{where}: verified capability entry must be an object")
        return
    capability = item.get("capability")
    if not isinstance(capability, str) or not capability.strip():
        report.fail(f"{where}: capability id is required")
    elif capability not in REQUIRED_CAPABILITIES:
        report.fail(f"{where}: unknown capability id {capability!r}")
    status = item.get("status")
    if not isinstance(status, str) or status not in CAPABILITY_STATUSES:
        report.fail(f"{where}: capability status {status!r} not in {sorted(CAPABILITY_STATUSES)}")
        return
    if status != "verified":
        return

    for field in VERIFIED_EVIDENCE_FIELDS:
        if field not in item:
            report.fail(
                f"{where}: verified capability {capability!r} is missing "
                f"required evidence field {field!r}"
            )
    artifact = item.get("evidence_artifact")
    if not is_real_string(artifact):
        report.fail(f"{where}: verified capability requires a real evidence_artifact path")
    elif resolve_repo_artifact(root, artifact, extra_roots=(references_dir,)) is None:
        report.fail(
            f"{where}: evidence artifact must exist inside the repository: {artifact!r}"
        )
    if not is_real_string(item.get("test_id")):
        report.fail(f"{where}: verified capability requires a real test_id")
    tested_at = item.get("tested_at")
    if not is_calendar_date(tested_at):
        report.fail(
            f"{where}: tested_at must be a real calendar date (YYYY-MM-DD): {tested_at!r}"
        )
    if not is_real_string(item.get("product_version")):
        report.fail(f"{where}: verified capability requires a real product_version")
    scope = item.get("scope")
    if not isinstance(scope, dict):
        report.fail(
            f"{where}: scope must be a typed object with surface, os, and lifecycle "
            f"(not {scope!r})"
        )
    else:
        for key in ("surface", "os", "lifecycle"):
            if not is_real_string(scope.get(key)):
                report.fail(f"{where}.scope: missing a real {key!r}")
    observed = item.get("observed_result")
    if not is_real_string(observed):
        report.fail(f"{where}: verified capability requires a real observed_result")
    else:
        problem = passing_result_problem(item)
        if problem:
            report.fail(f"{where}: {problem}")


def _check_verified_consistency(report, where: str, verified_items) -> None:
    """An aggregate verified claim must not mix versions/surfaces/OSes."""
    if len(verified_items) < 2:
        return
    for field in ("product_version",):
        values = {item.get(field) for item in verified_items}
        if len(values) > 1:
            report.fail(
                f"{where}: verified capabilities mix unrelated {field} values {sorted(map(str, values))}"
            )
    for key in ("surface", "os", "lifecycle"):
        values = {
            item["scope"].get(key)
            for item in verified_items
            if isinstance(item.get("scope"), dict)
        }
        if len(values) > 1:
            report.fail(
                f"{where}: verified capabilities mix unrelated scope.{key} values "
                f"{sorted(map(str, values))}"
            )


def check_registry(report, root: Path) -> None:
    registry_path = root / REGISTRY_REL
    references_dir = registry_path.parent
    if not registry_path.is_file():
        report.fail(f"adapter registry missing: {REGISTRY_REL}")
        return
    try:
        entries = json.loads(read_text(registry_path))
    except json.JSONDecodeError as exc:
        report.fail(f"{REGISTRY_REL}: invalid JSON: {exc}")
        return
    if not isinstance(entries, list) or not entries:
        report.fail(f"{REGISTRY_REL}: expected a non-empty JSON array")
        return

    products = set()
    routed: set[str] = set()
    for index, entry in enumerate(entries):
        where = f"{REGISTRY_REL}[{index}]"
        if not isinstance(entry, dict):
            report.fail(f"{where}: entry must be an object")
            continue
        missing = REGISTRY_REQUIRED_KEYS - set(entry)
        if missing:
            report.fail(f"{where}: missing keys {sorted(missing)}")
        product = entry.get("product")
        if isinstance(product, str) and product:
            if product in products:
                report.fail(f"{where}: duplicate product {product!r}")
            products.add(product)
        status = entry.get("status")
        if not isinstance(status, str) or status not in REGISTRY_STATUSES:
            report.fail(
                f"{where}: status {status!r} not in {sorted(REGISTRY_STATUSES)}; only "
                "per-capability verified entries with evidence are accepted"
            )
        verified_on = entry.get("verified_on")
        if verified_on is not None and not is_calendar_date(verified_on):
            report.fail(f"{where}: verified_on must be null or a real calendar date")

        capabilities = entry.get("verified_capabilities")
        verified_items: list[dict] = []
        capability_ids: set[str] = set()
        if capabilities is not None:
            if not isinstance(capabilities, list):
                report.fail(f"{where}: verified_capabilities must be a list")
            else:
                for cap_index, item in enumerate(capabilities):
                    spot = f"{where}.verified_capabilities[{cap_index}]"
                    _check_verified_capability(report, spot, root, references_dir, item)
                    if isinstance(item, dict):
                        capability = item.get("capability")
                        if isinstance(capability, str) and capability:
                            if capability in capability_ids:
                                report.fail(
                                    f"{spot}: duplicate capability id {capability!r}"
                                )
                            capability_ids.add(capability)
                        if item.get("status") == "verified":
                            verified_items.append(item)

        if status == "verified":
            if not is_calendar_date(verified_on):
                report.fail(f"{where}: a verified entry requires a real verified_on date")
            if not capabilities:
                report.fail(
                    f"{where}: a verified entry requires per-capability evidence entries"
                )
            missing_caps = REQUIRED_CAPABILITIES - capability_ids
            if missing_caps:
                report.fail(
                    f"{where}: a verified adapter must verify every required capability; "
                    f"missing {sorted(missing_caps)}"
                )
            _check_verified_consistency(report, where, verified_items)

        for key in ("sources", "native_controls"):
            if not isinstance(entry.get(key), list):
                report.fail(f"{where}: {key} must be a list")
        for key in (
            "identity",
            "surface",
            "separate_session_evidence",
            "scheduler_evidence",
            "lifecycle_evidence",
        ):
            if not isinstance(entry.get(key), str) or not entry.get(key).strip():
                report.fail(f"{where}: {key} must be a non-empty string")
        route = entry.get("route")
        if not isinstance(route, str) or not route.startswith("references/"):
            report.fail(f"{where}: route must be a 'references/...' path")
            continue
        target = references_dir / route[len("references/"):]
        if not target.is_file():
            report.fail(f"{where}: route target does not exist: {route}")
        else:
            routed.add(target.name)

    for page in sorted(references_dir.glob("*.md")):
        if page.name not in routed:
            report.fail(
                f"{rel(root, page)}: routing page is not referenced by any registry entry"
            )
