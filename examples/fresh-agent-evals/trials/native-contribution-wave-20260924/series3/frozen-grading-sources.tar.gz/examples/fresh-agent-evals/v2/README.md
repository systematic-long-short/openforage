# Finished-contribution trials v2

This is the preferred current first-contribution suite. It tests a **finished,
reviewable documentation correction**, not a plan: the subject discovers the
repository route, runs a baseline check, edits a seeded fixture defect, records
typed facts in `trial-output/completion.json`, and runs a relevant validator
again. The human summary and rationale are retained separately and are never
graded for research quality or magic wording.

## Cases and disclosure

`cases.json` defines one primary task and one distinct held-out task. The
primary fixture is shared unchanged by OpenCode and Codex; the held-out fixture
is reserved for an independent later check and is not used by native model-trial
subjects unless explicitly selected with `--include-heldout`; mechanical
selfchecks and preflight may exercise the fixture. The task gives the output
path, full JSON Schema, and isolation boundaries, but not the defective page,
validator command, expected fact values, or repair recipe.

The public checkout contains `oracle.json`, grader code, cases, and fixtures.
Prepared workspaces retain the full public validation closure so an authentic
`all` check does not fail because eval sources were removed. The task forbids
direct inspection of case/oracle/answer/grader material; validator execution
may read its own test sources. The access audit checks recorded native events
and commands. This is instruction-isolated, not a pristine blind evaluation or
an OS sandbox, and an incomplete trace leaves access and action-count metrics
unknown.

## Frozen named series

The checked-in `series.json` is the **historical, pre-native series-1 draft**;
it has no native model trials and is preserved byte-for-byte. Ordinary `all`
validation and selfchecks do not replay that archive. An explicit
`--archived-series1-drift-check` reports whether its old input closure still
matches; it is not a current run selection.

```bash
python examples/fresh-agent-evals/v2/freeze.py --archived-series1-drift-check
```

After final review, create one new named manifest for the selected series using
a caller-chosen NEW UNIQUE `<series-id>` and a new output path. `--create` needs
that unused path; `--check` and a runner's `--series-manifest` may select an
existing manifest, including an archived series. The manifest freezes only the
case/schema/oracle definitions, v2 grading and runner helpers, reused v1
outcome/trace helpers, canonical route facts, the dependent validator modules,
and the fixture source pages. It does not freeze the whole checkout. Every
runner and grader requires an explicit selected manifest and refuses drift in
that closure. Per-trial input file maps and snapshot hashes identify the
prepared public source snapshot, including unrelated documentation at that
time; these do not make ordinary repository selfchecks fail after later edits.
Selected manifest bytes are recorded separately by their own hash.

```bash
PYTHONDONTWRITEBYTECODE=1 .venv-docs/bin/python examples/fresh-agent-evals/v2/freeze.py \
  --create --series-id <series-id> \
  --output examples/fresh-agent-evals/v2/series/<series-id>.json
PYTHONDONTWRITEBYTECODE=1 .venv-docs/bin/python examples/fresh-agent-evals/v2/freeze.py \
  --check --series-manifest examples/fresh-agent-evals/v2/series/<series-id>.json
```

Manifest creation refuses an existing path. Grader changes require a new named
series; a regrade uses `--regrade-label` and a separate verdict path. Trial
records, raw streams, and verdicts are exclusive-create artifacts; use a new
`--run-id` for each invocation.

## Explicit native runs

Run the same primary case in separate fresh workspaces, one native subject at
a time, after the implementation session exits. Supply a caller-selected model
and a harness-specific variant/reasoning effort; the public runner has no model
default. Run OpenCode first; use its recorded `snapshot_sha256` as Codex's
`--expected-snapshot-sha256` pin. The CLI gates on the locally observed OpenCode `1.18.31` or Codex
`0.156.1` version before launching.

```bash
PYTHONDONTWRITEBYTECODE=1 .venv-docs/bin/python examples/fresh-agent-evals/v2/runner.py \
  --harness opencode --case first-finished-contribution-primary \
  --series-manifest examples/fresh-agent-evals/v2/series/<series-id>.json \
  --model <provider/model> --variant <caller-selected-variant> --run-id opencode-primary-1

PYTHONDONTWRITEBYTECODE=1 .venv-docs/bin/python examples/fresh-agent-evals/v2/runner.py \
  --harness codex --case first-finished-contribution-primary \
  --series-manifest examples/fresh-agent-evals/v2/series/<series-id>.json \
  --model <provider/model> --reasoning-effort <caller-selected-effort> \
  --expected-snapshot-sha256 <snapshot-sha256-from-opencode-trial> --run-id codex-primary-1
```

The runner records each workspace's complete initial file map and snapshot
digest. After both successful primary trials, compare them without launching a
harness:

```bash
PYTHONDONTWRITEBYTECODE=1 .venv-docs/bin/python examples/fresh-agent-evals/v2/comparison.py \
  --opencode-trial .tmp/native-contribution-wave/runs/opencode-primary-1/trial.json \
  --codex-trial .tmp/native-contribution-wave/runs/codex-primary-1/trial.json
```

The comparison refuses different selected manifests, source identities,
prepared file maps, or prepared snapshot digests, so different source inputs
cannot be attributed to a harness difference. It also reports sanitized
requested model/variant/reasoning selectors side by side; these are argv
requests, not proof of the backend-served model.

OpenCode uses `run --pure --dir W --model M --variant V --agent build --format
json`; the runner injects a wildcard-deny profile, allows local read/edit/shell
and `todowrite`, explicitly denies external-directory, web/network, nested
`task`, interactive `question`, and mode-switching `plan_enter`/`plan_exit`
actions, and checks the exact effective named-agent matrix before launch. Local
`todowrite` remains available for todo planning. The question and mode-switching
restrictions apply only to this single-turn contribution fixture; normal
background adapters continue inheriting native configuration. Clarification
observations therefore describe this restricted fixture and are not an estimate
for unrestricted sessions. The runner also checks that project `.opencode` and
`node_modules` trees remain absent. Shell is available, so these permission and
trace checks do not prove that the host is unable to reach a network through
every possible command.

Codex uses `--no-daemon --ask-for-approval never --model M --cd W --sandbox
workspace-write -c model_reasoning_effort=E exec --json --ignore-user-config`.
The runner inherits the configured auth/rules environment without recording
its paths or contents; it does not use `--ignore-rules`, `--last`, or a sandbox
bypass. `workspace-write` is the native selected sandbox boundary; trace checks
are additional observations, not a claim about host-wide isolation.

The runner records sanitized allowlisted actions, event identities, explicit
native outcomes, file digests, and a sanitized verdict. It retains the
caller-requested model selector and variant/reasoning value only when their
shape is safe, labels them as requests (the backend-served model is not
observed), and stores a digest plus unknown reason otherwise. Raw argv,
auth/provider environment, private configuration, raw streams, and absolute
workspace paths are not archived; raw stdout/stderr stay in ignored
`.tmp/native-contribution-wave/` scratch.
Codex shell wrappers are normalized only when the exact argv is a single
`bash -lc SCRIPT`; the inner validator must itself be standalone. A compound,
piped, truncated, refused, or exit-code-missing command cannot pass.

## Evidence and offline checks

The grader correlates declared baseline/final commands to native call/item IDs,
actual statuses and explicit exit codes, then checks final artifacts against
workspace path/digest diffs. It independently runs the unchanged
`truthfulness` and `links` validators against the final workspace. The
primary correction is checked by AST equivalence of the seeded Python example,
preserved surrounding source, and the real validator; harmless quote/spacing
changes and additive explanation are accepted, while deleting the example or
changing unrelated code is not. The held-out link contract is bounded to its
source context and an existing canonical target; no held-out subject run is
automatic. The
baseline failure and final success are separate observed outcomes. Missing or
unclassifiable events keep setup/clarification totals unknown. Contribution
completion time is reported only as elapsed-at-verification upper bound unless
an exact completion time is observable; first meaningful action has its own
metric. Structured fact mismatches count as unsupported claims. Prose is shown
only in a labeled human-review section. Structured command fields are
workspace-relative; absolute host paths are rejected.

```bash
PYTHONDONTWRITEBYTECODE=1 .venv-docs/bin/python examples/fresh-agent-evals/v2/runner.py --selfcheck
# After creating the caller-selected series manifest shown above:
PYTHONDONTWRITEBYTECODE=1 .venv-docs/bin/python examples/fresh-agent-evals/v2/freeze.py \
  --check --series-manifest examples/fresh-agent-evals/v2/series/<series-id>.json
```

The v2 selfcheck is explicitly synthetic; it checks schema typing, anti-forgery,
manifest drift, no-overwrite evidence, alternate prose, denied/missing results,
Codex/OpenCode event normalization, path safety, snapshot isolation, and an
independent validator run. It launches no harness or model. These regressions
do not count as real trials. The original v1 cases, grader, records, and
verdicts remain preserved as historical evidence under the parent directory.
