"""Strict standalone command and direct-suite-access recognition."""

from __future__ import annotations

import re
import shlex
from pathlib import Path

from schema import VALIDATOR_MODES

PYTHON_RE = re.compile(r"python(?:3(?:\.\d+)?)?\Z")
SHELL_META = set(";&|<>`$(){}!\n\r\0")
V2_PATH_RE = re.compile(r"(?:^|[/\s])examples/fresh-agent-evals(?:/|\b)")
RESERVED_NAMES = {
    "cases.json", "oracle.json", "answer.json", "answers.json", "grader.py",
    "grade.py", "manifest.py", "series.json",
}
RESERVED_NAME_RE = re.compile(
    r"(?:^|[/\\\s'\"])(?:cases\.json|oracle\.json|answers?\.json|grader\.py|grade\.py|manifest\.py|series\.json)(?:$|[/\\\s'\"])"
)


def _shlex(value: str) -> list[str] | None:
    if not isinstance(value, str) or not value.strip() or any(char in value for char in SHELL_META):
        return None
    try:
        return shlex.split(value, posix=True)
    except ValueError:
        return None


def unwrap_codex_shell(command: str) -> tuple[str | None, str]:
    """Unwrap only one exact `bash -lc SCRIPT` argv, never a compound script."""
    words = _shlex(command)
    if not words:
        return None, "command is empty, malformed, or contains shell control syntax"
    if Path(words[0]).name not in {"bash", "sh"}:
        return command.strip(), "direct"
    if (
        len(words) == 3
        and Path(words[0]).name in {"bash", "sh"}
        and words[1] == "-lc"
        and words[2].strip()
    ):
        inner = words[2].strip()
        if _shlex(inner) is None:
            return None, "wrapped shell script is compound or malformed"
        return inner, "exact-shell-wrapper"
    return None, "shell wrapper is not one exact login-shell invocation"


def normalize_command(command: str, harness: str) -> tuple[str | None, str]:
    if harness == "codex":
        return unwrap_codex_shell(command)
    if harness == "opencode":
        if _shlex(command) is None:
            return None, "OpenCode command is compound or malformed"
        return command.strip(), "direct"
    return None, "unknown harness command format"


def validator_modes(command: str, workspace: Path, harness: str) -> tuple[list[str] | None, str | None]:
    """Return modes only for a full standalone validator invocation in workspace."""
    normalized, _kind = normalize_command(command, harness)
    if normalized is None:
        return None, "command is not a standalone invocation"
    try:
        words = shlex.split(normalized, posix=True)
    except ValueError:
        return None, "command cannot be tokenized"
    if len(words) < 3 or not PYTHON_RE.fullmatch(Path(words[0]).name):
        return None, "command does not begin with a Python validator invocation"
    if words[1].removeprefix("./") != ".github/scripts/validate_agent_docs.py":
        return None, "command does not name the repository validator"
    modes: list[str] = []
    index = 2
    while index < len(words):
        token = words[index]
        if token in {"--root", "--record-dir"}:
            index += 1
            if index >= len(words):
                return None, "validator option is missing its value"
            value = words[index]
            if token == "--root" and value not in {".", "./"}:
                return None, "validator root must be workspace-relative; absolute paths are not archived"
            if token == "--record-dir" and (value.startswith("/") or ".." in Path(value).parts):
                return None, "validator record directory escapes the workspace"
        elif token.startswith("-"):
            return None, "validator command contains an unsupported option"
        elif token in VALIDATOR_MODES:
            if token in modes:
                return None, "validator mode is duplicated"
            modes.append(token)
        else:
            return None, "validator command contains an unknown argument"
        index += 1
    if not modes:
        return None, "validator command selects no validation mode"
    if "all" in modes and len(modes) != 1:
        return None, "all cannot be combined with individual validator modes"
    return modes, None


def is_relevant_modes(modes: list[str] | None) -> bool:
    return isinstance(modes, list) and ("all" in modes or "truthfulness" in modes)


def _broad_suite_search(command: str, harness: str) -> bool:
    normalized, _kind = normalize_command(command, harness)
    if normalized is None:
        return False
    try:
        words = shlex.split(normalized, posix=True)
    except ValueError:
        return False
    if not words:
        return False
    tool = Path(words[0]).name
    args = words[1:]
    recursive = tool == "rg" or tool in {"grep", "egrep", "fgrep"} and any(
        option in args for option in ("-r", "-R", "--recursive")
    ) or tool == "ls" and any(option in args for option in ("-R", "--recursive"))
    if not recursive and tool != "find":
        return False
    positional = [item for item in args if not item.startswith("-")]
    if tool in {"rg", "grep", "egrep", "fgrep"}:
        # The first positional argument is the pattern; remaining ones are scopes.
        scopes = positional[1:]
    elif tool == "find":
        scopes = positional[:1] or ["."]
    else:
        scopes = positional or ["."]
    return not scopes or any(
        scope in {".", "./", "examples", "./examples"}
        or scope.startswith("examples/fresh-agent-evals")
        for scope in scopes
    )


def direct_suite_access(action: dict, harness: str, workspace: Path) -> bool:
    """Flag observed direct case/oracle/grader paths; validator execution is exempt."""
    tool = action.get("tool")
    command = action.get("command")
    path = action.get("path")
    if tool in {"bash", "shell", "command_execution"} and isinstance(command, str):
        modes, _error = validator_modes(command, workspace, harness)
        if modes is not None:
            return False
        if _broad_suite_search(command, harness):
            return True
    candidates = [item for item in (command, path, action.get("file_path")) if isinstance(item, str)]
    for value in candidates:
        if V2_PATH_RE.search(value):
            return True
        if Path(value.strip()).name in RESERVED_NAMES or RESERVED_NAME_RE.search(value):
            return True
    return False
